namespace eValve.auth {
  'use strict';

  export interface ICredentials {
    username: string;
    password: string;
  }

  angular
    .module('eValve.auth', [])
    .run(initModule);

  initModule.$inject = ['routerHelper'];
  function initModule(routerHelper) {
    routerHelper.configureStates(getStates(), 'login');
  }

  function getStates() {
    return [
      {
        /* Page de login */
        state: 'login',
        config: {
          url: '/login',
          views: {
            '': {
              templateUrl: 'app/auth/login.html',
              controller: 'LoginController as login'
            }
          },
          resolve: {
            mustBeAnonymous: function ($q, $rootScope) {
              return angular.isDefined($rootScope.user)
                ? $q.reject('ALREADY_LOGGED_IN')
                : $q.resolve();
            }
          }
        }
      },
      {
        /* Page de création de compte */
        state: 'newaccount',
        config: {
          url: '/newaccount',
          views: {
            '': {
              templateUrl: 'app/auth/newaccount.html',
              controller: 'AccountController as account'
            }
          },
          resolve: {
            mustBeAnonymous: function ($q, $rootScope) {
              return angular.isDefined($rootScope.user)
                ? $q.reject('ALREADY_LOGGED_IN')
                : $q.resolve();
            }
          }
        }
      }
    ];
  }

}
