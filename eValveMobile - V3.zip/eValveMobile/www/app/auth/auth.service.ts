namespace eValve.auth {
  'use strict';

  export interface IAuth {
    checkExistingUsers(): ng.IPromise<boolean>;
    createUser(credentials: ICredentials, isAdmin?: boolean): ng.IPromise<any>;
    isUsernameAvailable(username: string): ng.IPromise<boolean>;
    login(credentials: ICredentials): ng.IPromise<any>;
    logout(): void;
  }

  export class Auth implements IAuth {
    static $inject: Array<string> = ['$q', '$rootScope', 'vanne', 'db', 'park'];
    constructor(
      private $q: ng.IQService,
      private $rootScope: eValve.core.IAppRootScope,
      private vanne: eValve.vanne.IVanne,
      private db: eValve.core.IDb,
      private park: eValve.park.IParkService
    ) { }

    /**
     * Vérifie la validité des informations et logue l'utilisateur si OK
     * @param {ICredentials} credentials - Objet contenant le login et le mot de passe
     * @returns {Promise} Promise du résultat de l'authentification
     */
    login(credentials: ICredentials): ng.IPromise<any> {
      return this.db
        .getUserByUsername(credentials.username)
        .then((user: eValve.park.IUser) => {
          if (user.password != credentials.password) {
            throw 'ERROR_CREDENTIALS';
          }
          this.park.loggedUser = user;
        })
        .catch(error => {
          throw 'ERROR_CREDENTIALS';
        });
    }

    /**
     * Crée un nouvel utilisateur dans la base de données
     * @param {ICredentials} credentials Username et mot de passe
     * @param {boolean} [isAdmin] Indique si l'utilisateur doit être admin
     * @returns {Promise} Promise de la création de l'utilisateur
     */
    createUser({ username, password }: ICredentials, isAdmin?: boolean): ng.IPromise<any> {
      let isAdminPromise = typeof isAdmin === 'undefined'
        ? this.checkExistingUsers().then(users => !users) // Si il y a des utilisateurs, pas de création d'admin
        : this.$q.resolve(isAdmin);
      return isAdminPromise
        .then((adminResult: boolean) => {
          return this.db.storeUser({
            username,
            password,
            isAdmin: adminResult,
            userType: 1,
            valves: new Map<string, number>(),
            connectionCodes: {}
          });
        });
    }

    /**
     * Vérifie si des utilisateurs existent en base de données
     * @returns {Promise<boolean>} Promise avec vrai si il y a des utilisateurs, faux autrement
     */
    checkExistingUsers(): ng.IPromise<boolean> {
      return this.db
        .getUsers()
        .then((users: { username: string, isAdmin: boolean }[]) => users.length != 0);
    }

    /**
     * Vérifie si un username est déjà pris
     * @param {string} username Username à vérifier
     * @returns {Promise<boolean>} Promise vraie si username disponible, fausse autrement
     */
    isUsernameAvailable(username: string): ng.IPromise<boolean> {
      return this.db
        .getUsers()
        .then((users: { username: string, isAdmin: boolean }[]) => {
          let usernameExists = users
            .map(user => user.username.toLowerCase())
            .includes(username.toLowerCase());

          return !usernameExists;
        });
    }

    /**
     * Logue out l'utilisateur
     */
    logout() {
      delete this.$rootScope.user;
      this.vanne.selectedValveSerial = null;
    }
  }

  angular
    .module('eValve.auth')
    .service('auth', Auth);
}
