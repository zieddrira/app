namespace eValve.auth {
  'use strict';

  export class LoginController {
    model: any;
    fields: AngularFormly.IFieldArray;

    static $inject: Array<string> = ['auth', '$state', '$ionicPopup', '$scope', '$ionicHistory', '$ionicPlatform'];
    constructor(
      private auth: eValve.auth.IAuth,
      private $state: ng.ui.IStateService,
      private $ionicPopup: ionic.popup.IonicPopupService,
      private $scope: ng.IScope,
      private $ionicHistory: ionic.navigation.IonicHistoryService,
      private $ionicPlatform: ionic.platform.IonicPlatformService
    ) {
      this.checkExistingUsers();
      this.$scope.$on('$ionicView.beforeEnter', () => this.setLoginForm());

      this.$scope.$on('$ionicView.loaded', () => {
        /**
         * Lors du chargement initial de l'application, on enlève manuellement le splashcreen
         * Comme ça on est sûr que l'application a bien été chargée à 100%, il n'y a pas d'écran "moche"
         * https://calendee.com/2015/03/03/polish-app-launch-with-cordova-splashscreen-plugin/
         */
        this.$ionicPlatform.ready(() => {
          if (navigator && navigator.splashscreen) {
            navigator.splashscreen.hide();
          }
        });
      });
    }

    /**
     * Fonction appelée lors de la soumission du formulaire de login
     */
    login() {
      // this.$state.go('dashboard');
      this.auth.login(this.model)
        .then(() => {
          // this.model = {};
          this.setLoginForm();

          /* Initialise l'historique à partir du dashboard (vue suivante) */
          this.$ionicHistory.nextViewOptions({
            historyRoot: true
          });

          this.$state.go('dashboard');
        })
        .catch(() => {
          this.model = {};
          this.$ionicPopup.alert({
            title: 'Erreur d\'authentification',
            template: 'Identifiant ou mot de passe incorrects',
            okType: 'button-assertive'
          });
        });
    }

    /**
     * Initialise le formulaire de login
     */
    setLoginForm() {
      this.model = {};
      this.fields = [
        {
          key: 'username',
          type: 'floating-input',
          templateOptions: {
            type: 'text',
            placeholder: `Nom d'utilisateur`,
            label: `Nom d'utilisateur`,
            required: true
          }
        },
        {
          key: 'password',
          type: 'floating-input',
          templateOptions: {
            type: 'password',
            placeholder: 'Mot de passe',
            label: 'Mot de passe',
            required: true
          }
        }
      ];
    }

    /**
     * Vérifie si des utilisateurs existent. Si non, propose de créer un compte.
     */
    checkExistingUsers() {
      this.auth
        .checkExistingUsers()
        .then(result => {
          if (result) {
            /* Si des utilisateurs existe on reste sur la page de login */
            this.setLoginForm();
          } else {
            this.$ionicPopup
              .confirm({
                title: `Pas d'utilisateurs`,
                template: `Il n'y a pas encore d'utilisateur enregistré sur l'application. Voulez-vous en créer un ?`,
                cancelText: 'Annuler',
                okText: 'Créer un compte'
              })
              .then(popupResult => {
                if (popupResult) {
                  /* Si le résultat est vrai on redirige vers la création de compte */
                  this.$state.go('newaccount');
                }
              });
          }
        });
    }

  }

  angular
    .module('eValve.auth')
    .controller('LoginController', LoginController);
}
