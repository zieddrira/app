namespace eValve.auth {
  'use strict';

  export class AccountController {
    fields: any;
    model: any;

    static $inject: Array<string> = ['auth', '$state', '$ionicPopup', '$scope'];
    constructor(
      private auth: eValve.auth.IAuth,
      private $state: ng.ui.IStateService,
      private $ionicPopup: ionic.popup.IonicPopupService,
      private $scope: ng.IScope
    ) {
      this.$scope.$on('$ionicView.beforeEnter', () => this.setAccountForm());
    }

    /**
     * Crée l'utilisateur et redirige sur la page de login
     */
    create() {
      this.auth
        .createUser(this.model)
        .then(() =>
          this.$ionicPopup.alert({
            title: 'Créer un compte :',
            template: 'Le compte a bien été créé',
            okText: 'OK',
            okType: 'button-positive'
          }))
        .then(() => this.$state.go('login'))

        .catch(error => {
          this.$ionicPopup.alert({
            title: 'Erreur lors de la création',
            template: JSON.stringify(error),
            okType: 'buton-assertive'
          });
        });
    }

    /**
     * Initialise le formulaire de création de compte
     */
    setAccountForm() {
      this.model = {};
      this.fields = [
        {
          key: 'username',
          type: 'floating-input',
          templateOptions: {
            type: 'text',
            placeholder: `Nom d'utilisateur`,
            label: `Nom d'utilisateur`,
            required: true,
            pattern: '[a-zA-Z0-9]+',
            onKeydown: function (value, options) {
              options.validation.show = false;
            },
            onBlur: function (value, options) {
              options.validation.show = null;
            }
          },
          validation: {
            messages: {
              pattern: '"Uniquement des lettres et des chiffres"',
            }
          },
          asyncValidators: {
            uniqueUsername: {
              expression: ($viewValue, $modelValue, scope) => {
                let value = $viewValue || $modelValue;
                // scope.options.templateOptions.loading = true;

                return this.auth
                  .isUsernameAvailable(value)
                  .then(result => {
                    if (!result) {
                      throw new Error(`Nom d'utilisateur non disponible`);
                    }
                  });
                // .finally(() => scope.options.templateOptions.loading = false)
              },
              message: '"Nom d\'utilisateur non disponible"'
            }
          },
          modelOptions: {
            updateOn: 'blur'
          }
        },
        {
          key: 'password',
          type: 'floating-input',
          templateOptions: {
            type: 'password',
            placeholder: 'Mot de passe',
            label: 'Mot de passe',
            required: true
          }
        },
        {
          key: 'confirmPassword',
          type: 'floating-input',
          templateOptions: {
            type: 'password',
            placeholder: 'Confirmation du mot de passe',
            label: 'Confirmation du mot de passe',
            required: true
          },
          validators: {
            equalPasswords: {
              expression: ($viewValue, $modelValue) => {
                let value = $modelValue || $viewValue;
                return this.model.password == value;
              },
              message: '"Le mot de passe ne correspond pas"'
            }
          },
          extras: {
            validateOnModelChange: true
          }
        }
      ];
    }
  }

  angular
    .module('eValve.auth')
    .controller('AccountController', AccountController);
}
