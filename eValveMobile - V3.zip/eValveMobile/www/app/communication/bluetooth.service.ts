namespace eValve.communication {
  'use strict';

  // declare let ble;

  interface INotification {
    activated: boolean;
    lastValue: ArrayBuffer;
  }

  export interface IBluetooth {
    connect(deviceId: string): ng.IPromise<any>;
    disconnect(): ng.IPromise<any>;
    getLastNotificationValue(characteristic: string): ArrayBuffer;
    isConnected(): ng.IPromise<any>;
    isEnabled(): ng.IPromise<void>;
    read(serviceUUID: string, characteristicUUID: string, deviceId?: string): ng.IPromise<any>;
    startNotification(serviceUUID: string, characteristicUUID: string, deviceId?: string): void;
    stopNotification(serviceUUID: string, characteristicUUID: string, deviceId?: string): ng.IPromise<any>;
    startScan(services?: any[], seconds?: number): ng.IPromise<any>;
    stopScan(): ng.IPromise<any>;
    toggleNotifications(characteristic: string, deactivate?: boolean): void;
    write(data: Uint8Array, serviceUUID: string, characteristicUUID: string, deviceId?: string): ng.IPromise<any>;
  }

  export class Bluetooth implements IBluetooth {
    private _bufferWritten: ArrayBuffer;
    private _connectedId: string;
    private _keepAlive: ng.IPromise<void>;
    private _notifications: { [id: string]: INotification } = {};

    static $inject: Array<string> = ['$ionicPlatform', '$cordovaBLE', '$q', '$rootScope', '$log', '$timeout', 'BLE_VARS'];
    constructor(
      private $ionicPlatform: ionic.platform.IonicPlatformService,
      private $cordovaBLE: any,
      private $q: ng.IQService,
      private $rootScope: ng.IRootScopeService,
      private $log: ng.ILogService,
      private $timeout: ng.ITimeoutService,
      private BLE_VARS: any
    ) {
      [<string>this.BLE_VARS.data, <string>this.BLE_VARS.vanne_ack]
        .forEach(value => {
          this._notifications[value] = {
            activated: false,
            lastValue: null
          };
        });
    }

    /**
     * Vérifie si le ble est activé et affiche une popup si désactivé
     * @returns {Promise}
     */
    isEnabled(): ng.IPromise<void> {
      return this.$ionicPlatform
        .ready()
        .then(() => this.$cordovaBLE.isEnabled())
        .then(() => this.$log.debug('Bluetooth enabled'))
        .catch(() => {
          this.$log.error('Bluetooth disabled');
          return this.$q.reject();
        });
    }

    /**
     * Renvoie une promise qui échoue si non connecté
     * @returns {Promise}
     */
    isConnected(): ng.IPromise<any> {
      if (!this._connectedId) {
        return this.$q.reject();
      }

      return this.$cordovaBLE
        .isConnected(this._connectedId)
        .catch(error => {
          this._connectedId = null;
          return this.$q.reject(error);
        });
    }

    /**
     * Lance le scan bluetooth pour détecter les vannes
     * @param {Object[]} [services] - Liste des services à découvrir
     * @param {Number} [seconds] - Durée du scan en secondes
     * returns {Promise}
     */
    startScan(services?: any[], seconds?: number): ng.IPromise<any> {
      return this.$cordovaBLE.scan(services || [], seconds || 10);
    }

    /**
     * Arrête le scan de vannes
     */
    stopScan(): ng.IPromise<any> {
      // let deferred = this.$q.defer();
      return this.$cordovaBLE
        .stopScan()
        .then(() => this.$log.debug('Scan stopped'))
        .catch(error => {
          this.$log.debug('Error stopping scan: ', JSON.stringify(error));
          throw error;
        });

      // ble.stopScan(
      //   () => {
      //     this.$log.debug('Scan stopped');
      //     deferred.resolve();
      //   },
      //   () => {
      //     this.$log.debug('Error stopping scan');
      //     deferred.reject();
      //   }
      // );

      // return deferred.promise;
    }

    /**
     * Lance la connexion au périphérique passé en paramètre
     * @param {String} deviceId - UUID ou addresse MAC du périphérique
     * returns {Promise}
     */
    connect(deviceId: string): ng.IPromise<any> {
      return this.$cordovaBLE
        .connect(deviceId)
        .then(result => {
          this._connectedId = deviceId;
          this.resetKeepAlive();

          return this.$timeout(3000)
            .then(() => {
              this.$log.debug('Timeout connection ended');
              let deferred = this.$q.defer();

              if (ionic.Platform.isAndroid()) {
                /**
                 * Dans le cas d'un device android, on doit aller récupérer manuellement le deviceId dans le Generic Access Service "1800"
                 * https://github.com/don/cordova-plugin-ble-central/issues/229
                 * https://developer.bluetooth.org/gatt/characteristics/Pages/CharacteristicViewer.aspx?u=org.bluetooth.characteristic.gap.device_name.xml
                 */

                this
                  .read('1800', '2a00')
                  .then(buffer => {
                    /* On appelle replace() pour supprimer les possibles bits nulls à la fin */
                    result.name = String.fromCharCode.apply(null, new Uint8Array(buffer)).replace(/\0/g, '');
                    deferred.resolve(result);
                  })
                  .catch(deferred.reject);

              } else {
                deferred.resolve(result);
              }

              return deferred.promise;
            });
        });
    }

    /**
     * Déconnecte l'application et arrête le keepAlive
     * @returns {Promise}
     */
    disconnect(): ng.IPromise<any> {
      if (!this._connectedId) {
        return this.$q.resolve();
      }

      this.stopKeepAlive();
      return this.$timeout(() => {
        return this.$cordovaBLE
          .disconnect(this._connectedId)
          .finally(() => {
            this._connectedId = null;
          });
      }, 3000);
    }

    /**
     * Lit une caractéristique d'un périphérique
     * @param {String} serviceUUID - UUID du service
     * @param {String} characteristicUUID - UUID de la caractéristique
     * @param {String} [deviceId] - UUID ou addresse MAC du périphérique
     * @returns {Promise}
     */
    read(serviceUUID: string, characteristicUUID: string, deviceId?: string): ng.IPromise<any> {
      return this.$cordovaBLE
        .read(deviceId || this._connectedId, serviceUUID, characteristicUUID)
        // .then(result => {
        //   this.$log.debug(result);
        //   this.$log.debug(bytesToString(result));
        //   return result;
        // })
        .catch(error => {
          this.$log.error(error);
          throw error;
        });
    }

    /**
     * Ecrit une caractéristique d'un périphérique
     * @param {Uint8Array} data - Données à écrire
     * @param {String} serviceUUID - UUID du service
     * @param {String} characteristicUUID - UUID de la caractéristique
     * @param {String} [deviceId] - UUID ou addresse MAC du périphérique
     * @returns {Promise}
     */
    write(data: Uint8Array, serviceUUID: string, characteristicUUID: string, deviceId?: string): ng.IPromise<any> {
      this.$log.debug('Write: ' + Array.prototype.slice.call(data));
      this._bufferWritten = data.buffer as ArrayBuffer;

      return this.$cordovaBLE
        .write(deviceId || this._connectedId, serviceUUID, characteristicUUID, data.buffer)
        .then(() => this.resetKeepAlive())

        .catch(error => {
          this.$log.error(error);
          let errorObject = {
            message: error,
            code: 12
          };

          throw errorObject;
        });
    }

    /**
     * S'abonne à une caractéristique donnée
     * @param {String} serviceUUID - UUID du service
     * @param {String} characteristicUUID - UUID de la caractéristique
     * @param {String} [deviceId] - UUID ou addresse MAC du périphérique
     */
    startNotification(serviceUUID: string, characteristicUUID: string, deviceId?: string) {
      this.$log.debug('Starting notifications: ' + characteristicUUID);
      this.$cordovaBLE.startNotification(deviceId || this._connectedId, serviceUUID, characteristicUUID,
        result => {
          this.$log.debug(`ble:notify:${characteristicUUID}:${Array.prototype.slice.call(new Uint8Array(result))}`);

          if (this._bufferWritten && this._bufferWritten == result) {
            this.$log.debug('Same buffer than written data, ignoring');
          } else {
            this.$rootScope.$emit('ble:notify:' + characteristicUUID, result);
          }

          if (this._notifications[characteristicUUID].activated) {
            this._notifications[characteristicUUID].lastValue = result;
          }
        },

        error => {
          this.$log.debug(error);
        });
    }

    /**
     * Stoppe l'abonnement à une caractéristique donnée
     * @param {String} serviceUUID - UUID du service
     * @param {String} characteristicUUID - UUID de la caractéristique
     * @param {String} [deviceId] - UUID ou addresse MAC du périphérique
     * @returns {Promise}
     */
    stopNotification(serviceUUID: string, characteristicUUID: string, deviceId?: string): ng.IPromise<any> {
      return this.$cordovaBLE.stopNotification(deviceId || this._connectedId, serviceUUID, characteristicUUID);
    }

    /**
     * Change l'état d'écoute des notifications sur la caractéristique spécifiée
     * @param {String} characteristic
     * @param {Boolean} deactivate
     */
    toggleNotifications(characteristic: string, deactivate?: boolean) {
      let charDetails = this._notifications[characteristic];
      this.$log.debug('Toggling BLE notifications listening : ', !deactivate);
      charDetails.lastValue = null;
      charDetails.activated = !deactivate;
    }

    /**
     * Récupère la dernière valeur stockée en état d'écoute pour la caractéristique
     * @param {String} characteristic
     * @returns {ArrayBuffer}
     */
    getLastNotificationValue(characteristic: string): ArrayBuffer {
      let value = this._notifications[characteristic].lastValue;
      this._notifications[characteristic].lastValue = null;

      return value;
    }

    /**
     * Réinitialise un timeout d'une minute qui envoie un message si pas d'échange avec la vanne
     */
    private resetKeepAlive() {
      this.stopKeepAlive();
      this._keepAlive = this.$timeout(() => {
        this.$log.debug('Sending keepAlive...');
        this.write((new Uint8Array(20)), this.BLE_VARS.service, this.BLE_VARS.data);
      }, 60 * 1000);
    }

    /**
     * Arrête le keepAlive de connexion si présent
     */
    private stopKeepAlive() {
      this._keepAlive && this.$timeout.cancel(this._keepAlive);
    }

  }

  angular
    .module('eValve.communication')
    .service('bluetooth', Bluetooth);
}
