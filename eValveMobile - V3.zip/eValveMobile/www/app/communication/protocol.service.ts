namespace eValve.communication {
  'use strict';

  export interface IProtocol {
    connectedValveProtocolVersion: number;
    littleEndian: boolean;

    connect(deviceId: string): ng.IPromise<any>;
    disconnect(sameTarget?: boolean): ng.IPromise<any>;
    initProtocol(connectionCode: string, retry?: number): ng.IPromise<number>;
    rawToDataView(cmd: string, array: any[]): DataView;
    readData(cmd: string, multiple?: boolean): ng.IPromise<any>;
    sendCommand(cmd: string, data?: any[], raw?: boolean): ng.IPromise<any>;
    toggleReception(newVal: boolean, multiple?: boolean): void;
  }

  export class Protocol implements IProtocol {
    private _commands: ICommands;
    private _connectionInitialized: boolean = false;
    private _isPopupDisplayed: boolean = false;
    private _popup: any;
    private _protocolVersion: number = null;

    private BASE_COMMANDS: ICommands = {
      'INIT': {
        type: '0x00',
        dataLength: 18,
        dataStruct: [4, 1, 1, 1, 1, 10],
        dataStrings: { 5: true },
        response: 'V_INIT'
      },
      'V_INIT_0': {
        type: '0x00',
        dataLength: 18,
        dataStruct: [4, 1, 1, 1, 1, 10],
        dataStrings: { 5: true }
      },
      'V_INIT_1': {
        type: '0x80',
        dataLength: 19,
        dataStruct: [4, 1, 1, 1, 1, 10, 1],
        dataStrings: { 5: true }
      }
    };

    littleEndian: boolean = true;

    static $inject: Array<string> = ['$rootScope', '$log', 'transport', 'bluetooth', 'ERROR_CODES',
      '$q', '$ionicPopup', '$ionicLoading', '$timeout', 'utils', '$http'];
    constructor(
      private $rootScope: ng.IRootScopeService,
      private $log: ng.ILogService,
      private transport: eValve.communication.ITransport,
      private bluetooth: eValve.communication.IBluetooth,
      private ERROR_CODES: eValve.communication.IErrors,
      private $q: ng.IQService,
      private $ionicPopup: ionic.popup.IonicPopupService,
      private $ionicLoading: ionic.loading.IonicLoadingService,
      private $timeout: ng.ITimeoutService,
      private utils: eValve.core.IUtils,
      private $http: ng.IHttpService
    ) {
      Object.freeze(this.BASE_COMMANDS);
    }

    get connectedValveProtocolVersion(): number { return this._protocolVersion; }

    /**
     * Crée une commande, l'envoie et retourne la réponse si applicable
     * @param {String} cmd - Représentation string de la commande
     * @param {Array} [data] - Tableau contenant les données de la commande
     * @param {Boolean} [raw] - Indique si la réponse doit être retournée brute
     * @returns {Promise} Promise de l'envoi ou de la réponse si applicable
     */
    sendCommand(cmd: string, data?: any[], raw?: boolean): ng.IPromise<any> {
      let command = this.createCommand(cmd, data);
      this.$log.debug('Created command: ' + command);

      if (cmd != 'Q_HISTO') {
        this.$ionicLoading.show();
      }

      return this.sendAndReceive(cmd, command)
        .then(() => {
          /* Si la commande attend une réponse, on réceptionne les données */
          if (this._commands[cmd].response) {
            return this.readData(this._commands[cmd].response);
          }
        })

        .catch(error => {
          let message;
          if (error.code && error.code == 12) {
            message = 'Vérifiez que la connexion est bien active et essayez de vous reconnecter';
          } else {
            message = error.message || error;
          }

          if (!this._isPopupDisplayed && cmd != 'INIT') {
            this._isPopupDisplayed = true;

            this._popup = this.$ionicPopup.alert({
              title: 'Erreur de communication',
              okType: 'button-assertive',
              template: message
            }).then(() => {
              this._isPopupDisplayed = false;

              /* Si erreur de communication 'brute', reset et renvoi page scan */
              if (error.code && error.code == 12) {
                this._connectionInitialized = false;
                this.bluetooth.disconnect();
                this.$rootScope.$emit('communication:reset');
                this.$ionicLoading.hide();
              }
            });
          }

          throw error;
        })

        .then((array: any) => {
          this._popup && this._popup.close && this._popup.close();

          if (!this._commands[cmd].response) {
            return;
          }

          return raw ? array : this.arrayToData(this._commands[cmd].response, array);
        })

        .finally(() => {
          if (cmd != 'Q_HISTO') {
            this.$ionicLoading.hide();
          }
        });
    }

    /**
     * Récupère et traite les données écrites par la vanne
     * @param {String} cmd
     * @param {Boolean} [multiple] - Indique si on doit maintenir la réception de données active
     * @returns {Promise}
     */
    readData(cmd: string, multiple?: boolean): ng.IPromise<any> {
      let deferred = this.$q.defer();
      let successListener: Function;
      let errorListener: Function;
      let receptionTimeout: ng.IPromise<void>;

      this.toggleReception(true, multiple);

      successListener = this.$rootScope.$on('ble:read:success',
        (event, data: number[]) => {
          /* On annule le timeout de réception */
          receptionTimeout && this.$timeout.cancel(receptionTimeout);

          successListener();
          errorListener && errorListener();

          try {
            if (cmd == 'V_INIT') {
              /* Si INIT, on checke quelle version de V_INIT est retournée */
              try {
                /* this.checkReceiveMessage() lève une exception si la validation échoue */
                this.checkReceivedMessage('V_INIT_0', data);
                this._protocolVersion = 0;
              } catch (error) {
                this.checkReceivedMessage('V_INIT_1', data);
              }
            } else {
              this.checkReceivedMessage(cmd, data);
            }

            deferred.resolve(data);
          } catch (error) {
            deferred.reject(error);
          }
        });

      errorListener = this.$rootScope.$on('ble:read:error',
        (event, error) => {
          /* On annule le timeout de réception */
          receptionTimeout && this.$timeout.cancel(receptionTimeout);

          errorListener();
          successListener();

          this.toggleReception(false);
          deferred.reject(error);
        });


      let timeout = cmd == 'V_INIT' ? 5000 : 30000;
      receptionTimeout = this.$timeout(
        /* Si on ne reçoit pas de données au bout de 5 (init) ou 30 secondes, on rejette */
        () => deferred.reject(this.ERROR_CODES['receive']['timeout']),
        timeout
      );

      return deferred.promise;
    }

    /**
     * Retourne la dataView associée aux données d'une frame
     * @param {String} cmd - Représentation string de la commande
     * @param {Array} array - Tableau des données brutes
     * @returns {DataView} DataView sur les données brutes
     */
    rawToDataView(cmd: string, array: any[]): DataView {
      let typedArray = new Uint8Array(this._commands[cmd].dataLength);

      typedArray.set(array.slice(2, -2));
      return new DataView(typedArray.buffer);
    }

    /**
     * Stoppe les notifications, le keepAlive, envoie la trame disconnect et se déconnecte
     * @param {boolean} [sameTarget] Indique si la cible est identique à la vanne à déconnecter
     * @returns {Promise} promise de la déconnexion
     */
    disconnect(sameTarget?: boolean): ng.IPromise<any> {
      this._connectionInitialized = false;

      return this.bluetooth.isConnected()
        .catch(() => {
          /* Si pas connecté, on retourne directement */
          throw { disconnected: true };
        })
        .then(() => {
          if (sameTarget) {
            /* S'il s'agit de réinitialiser la connexion à une vanne, on n'envoie pas la trame de disconnect */
            return;
          }

          /* Si connecté, envoi trame déconnexion */
          return this.sendCommand('DISCONNECT');
        })

        .then(() => {
          /* Arrêt des notifications et déconnexion */
          this.$ionicLoading.show();

          /* Transport des données */
          this.bluetooth.stopNotification('01234567-89AB-CDEF-0123-456789ABCDEF', '00000000-0000-0000-0000-000000000001');
          /* Ack des requêtes par la vanne */
          this.bluetooth.stopNotification('01234567-89AB-CDEF-0123-456789ABCDEF', '00000000-0000-0000-0000-000000000002');

          return this.bluetooth.disconnect();
        })
        .then(result => {
          this.$ionicLoading.hide();
          return result;
        })

        .catch(error => {
          if (error.disconnected) {
            return error;
          }

          throw error;
        });
    }

    /**
     * Etablit et initialise une connexion à une vanne
     * @param {String} deviceId - Adresse mac ou UUID de la vanne
     * @returns {Promise} Promise de la connexion
     */
    connect(deviceId: string): ng.IPromise<any> {
      // let connexionInfos;
      this.$ionicLoading.show();

      return this
        .bluetooth.connect(deviceId);
      // .then(result => {
      //   connexionInfos = result;
      //   /* Instanciation du protocole */
      //   return this.initConnection(connectionCode);
      // })

      // .catch(error => {
      //   /* Si on a une différence de timestamp, on répercute dans les infos de connexion */
      //   if (error.code == 26) {
      //     connexionInfos.vanneTimestamp = error.vanneTimestamp;
      //   } else {
      //     throw error;
      //   }
      // })

      // .then(() => {
      //   /* On retourne les infos de la vanne connectée */
      //   return connexionInfos;
      // });
    }

    /**
     * Active ou désactive le flag receiving
     * @param {Boolean} newVal - Nouvelle valeur du flag
     * @param {Boolean} [multiple] - Indique si on doit maintenir la réception de données active
     */
    toggleReception(newVal: boolean, multiple?: boolean) {
      this.transport.toggleReception(newVal, multiple);
    }

    /**
     * Initialise le protocole bluetooth sur la vanne connectée
     * @param {String} connectionCode Code de connexion à la vanne
     * @param {Number} [retry]
     * @returns {Promise}
     */
    initProtocol(connectionCode: string, retry?: number): ng.IPromise<number> {
      retry = retry || 0;
      this._commands = Object.assign({}, this.BASE_COMMANDS);

      /* Abonnement à la caractéristique de transport des données */
      this.bluetooth.startNotification('01234567-89AB-CDEF-0123-456789ABCDEF', '00000000-0000-0000-0000-000000000001');
      /* Abonnement à la caractéristique d'ack des requêtes par la vanne */
      this.bluetooth.startNotification('01234567-89AB-CDEF-0123-456789ABCDEF', '00000000-0000-0000-0000-000000000002');

      let currentDate = new Date();
      let timestamp = Math.floor(currentDate.getTime() / 1000);

      let privateKey = [0x4F, 0x4E, 0x59, 0x58];
      let bcdSeconds = this.utils.numberToBcd(currentDate.getUTCSeconds());
      let bcdMinutes = this.utils.numberToBcd(currentDate.getUTCMinutes());
      let maskOne = [bcdSeconds, bcdSeconds, bcdMinutes, bcdMinutes];
      let maskTwo = [
        this.utils.numberToBcd(currentDate.getUTCHours()),
        this.utils.numberToBcd(currentDate.getUTCDate()),
        this.utils.numberToBcd(parseInt(currentDate.getUTCFullYear().toString().slice(-2))),
        0x00
      ];

      let authKey = privateKey.map((value, index) => (value & maskOne[index]) + maskTwo[index]);
      let initFrame = (<any[]>[timestamp].concat(authKey)).concat(connectionCode);

      return this.sendCommand('INIT', initFrame)
        .catch(error => {
          if (++retry < 2) {
            // errorPopup && errorPopup.close();
            this.$ionicLoading.show();
            return this.$timeout(() => {
              this.$log.error('Init failed, trying again...');
              return this.initProtocol(connectionCode, retry);
            }, 2000 /* * retry */);
          }

          /* Si erreur de timeout, alors on considère que l'authentification a échoué */
          if (error.code && error.code == 23) {
            throw this.ERROR_CODES['receive']['auth'];
          }

          throw error;
        })

        .then((response: any[] | number) => {
          if (typeof response == 'number') {
            /**
             * Cas où la récursion a été utilisée dans le catch avec un retry sur this.initProtocol
             * => response == protocolVersion
             */
            return response;
          }

          if (this._connectionInitialized) {
            this.$log.info('Connection already initialized');
            return;
          }

          let areTimestampsEquals = true;
          let ok = response.every((value, index) => {
            if (index == 0 && timestamp != value) {
              areTimestampsEquals = false;
              return true;
            }

            if (index < 3) {
              /* On ne checke que les valeurs présentes dans INIT, pas au-delà (cas protocole V1+) */
              return value == initFrame[index];
            } else {
              return true;
            }
          });

          if (!ok) {
            this.$log.error('La trame d\'authentification retournée ne correspond pas à celle envoyée');
            throw this.ERROR_CODES['receive']['auth'];
          }

          /* Vérification de la présence de la version de protocole */
          if (response.length == 7) {
            this._protocolVersion = response[6];
          }

          this._connectionInitialized = true;
          this.$log.debug('Connection initialized');

          /* Si les timestamps ne correspondent pas, on lève l'erreur correspondante pour demander confirmation */
          if (!areTimestampsEquals) {
            this.$log.warn(this.ERROR_CODES['receive']['timestamp'].message);
            let error = this.ERROR_CODES['receive']['timestamp'];
            (<any>error).vanneTimestamp = response[0] * 1000; // Le timestamp reçu est en secondes
            throw error;
          }

          return this._protocolVersion;
        });
    }

    /**
     * Envoie le message en paramètre et réessaye plusieurs fois si pas de réponse
     * @param {String} cmd - Nom de la commande
     * @param {Array} message - Message à envoyer
     * @param {Number} [retry] - Nombre de retry actuels
     * @returns {Promise}
     */
    private sendAndReceive(cmd: string, message: any[], retry?: number): ng.IPromise<any> {
      retry = retry || 0;

      return this.transport
        .sendData(message)
        .catch((error: IError | any) => {
          this.$log.error(error);

          if (error.code && error.code > 20 && error.code < 30 && retry < 3) {
            /* Codes entre 20 et 30 : erreurs de réception */
            this.$log.debug('Trying again, retry: ' + retry);
            return this.sendAndReceive(cmd, message, ++retry);
          }

          // if (cmd != 'INIT') {
          //   $ionicPopup.alert({
          //     title: 'Erreur de communication',
          //     okType: 'button-assertive',
          //     template: error.message
          //   });
          // }

          // return $q.reject(error);
          throw error;
        });
    }

    /**
     * Crée une commande à envoyer à la vanne
     * @param {String} cmd
     * @param {Array} [data]
     * @returns {Array}
     */
    private createCommand(cmd: string, data?: any[]): Array<any> {
      let cmdType = this.getType(cmd);
      let dataBuffer = this.dataToBuffer(cmd, data);
      let byteLength = this.getLength(cmd);

      let beginBuffer = new ArrayBuffer(2);
      let beginView = new DataView(beginBuffer);
      beginView.setUint8(0, byteLength);
      beginView.setUint8(1, cmdType);

      let endBuffer = this.getChecksumBuffer(cmd, dataBuffer, byteLength);

      let command = new Uint8Array(byteLength);
      command.set(new Uint8Array(beginBuffer));
      command.set(new Uint8Array(dataBuffer), beginBuffer.byteLength);
      command.set(new Uint8Array(endBuffer), beginBuffer.byteLength + dataBuffer.byteLength);

      return Array.prototype.slice.call(command);
    }

    /**
     * Calcule et retourne le checksum de la trame
     * @param {String} cmd
     * @param {ArrayBuffer} data
     * @param {Number} length
     * @returns {Number}
     */
    private calcChecksum(cmd: string, data: ArrayBuffer, length: number): number {
      let typedArray = new Uint8Array(data);
      let normalArray = Array.prototype.slice.call(typedArray);
      let dataSum = normalArray.length && this.calcArraySum(normalArray) || 0;

      return dataSum + parseInt(this._commands[cmd].type) + length;
    }

    /**
     * Calcule et retourne la somme des éléments dans un tableau
     * @param {Array} array - Tableau à parcourir
     * @returns {Number} Somme des éléments du tableau
     */
    private calcArraySum(array: number[]): number {
      return array.length && array.reduce((previousValue, currentValue) => {
        return previousValue + currentValue;
      }) || 0;
    }

    /**
     * Retourne le checksum calculé sous forme de buffer
     * @param {String} cmd
     * @param {ArrayBuffer} data
     * @param {Number} length
     * @returns {ArrayBuffer}
     */
    private getChecksumBuffer(cmd: string, data: ArrayBuffer, length: number): ArrayBuffer {
      let checksum = this.calcChecksum(cmd, data, length);

      let buffer = new ArrayBuffer(2);
      let dataView = new DataView(buffer);
      dataView.setUint16(0, checksum, this.littleEndian);

      return buffer;
    }

    /**
     * Retourne la longueur en octets de la trame
     * @param {String} cmd
     * @returns {Number}
     */
    private getLength(cmd: string): number {
      let dataLength = this._commands[cmd].dataLength || 0;
      this.$log.debug('Command length: ' + dataLength);
      return dataLength + 1 + 1 + 2;
      // checksum = checksum || '0000';
      // let paramsLength = (cmdType + data + checksum).length / 2;
      // return completeHexaString((paramsLength + 1).toString(16));
    }

    /**
     * Récupère le code hexa d'une commande à partir de son nom
     * @param {String} cmd
     * @returns {Number}
     */
    private getType(cmd: string): number {
      return parseInt(this._commands[cmd].type);
    }

    /**
     * Transforme la donnée suivant le type de trame
     * @param {String} cmd
     * @param {Array} data
     * @returns {ArrayBuffer}
     */
    private dataToBuffer(cmd: string, data: any[]): ArrayBuffer {
      let cmdDetails = this._commands[cmd];
      if (!cmdDetails.dataLength) {
        return new ArrayBuffer(0);
      }

      let byteOffset = 0,
        buffer = new ArrayBuffer(cmdDetails.dataLength),
        dataView = new DataView(buffer);

      this.getFullStruct(cmdDetails)
        .forEach((value, index) => {
          if (cmdDetails.dataStrings && cmdDetails.dataStrings[index]) {
            /* Caractères ASCII */
            for (let i = 0; i < value; i++) {
              dataView.setUint8(byteOffset + i, data[index].charCodeAt(i));
            }

          } else {
            switch (value) {
              case 1:
                dataView.setUint8(byteOffset, data[index] || 0);
                break;
              case 2:
                dataView.setUint16(byteOffset, data[index] || 0, this.littleEndian);
                break;
              case 4:
                dataView.setUint32(byteOffset, data[index] || 0, this.littleEndian);
                break;
              default:
                /* Cas par défaut : caractères ASCII */
                for (let i = 0; i < value; i++) {
                  dataView.setUint8(byteOffset + i, data[index].charCodeAt(i));
                }
            }
          }

          byteOffset += value;
        });

      this.$log.debug('dataTypedArray:' + Array.prototype.slice.call(new Uint8Array(buffer)));
      return buffer;
    }

    /**
     * Parse un tableau de bytes suivant la structure d'une commande
     * @param {String} cmd
     * @param {Array} array
     * @returns {Promise<Array>}
     */
    private arrayToData(cmd: string, array: any[]): ng.IPromise<any[]> {
      let parsedData = [];
      let byteOffset = 0;
      let cmdDetails: ICommand;
      let deferred = this.$q.defer();

      /**
       * Cas spécifique à INIT où la trame de réponse peut varier :
       * 'V_INIT' sera de type 0x00 si version protocole == 0
       * 'V_INIT' sera de type 0x80 si version protocole > 0
       */
      if (cmd == 'V_INIT') {
        let filename: string;
        if (this._protocolVersion == 0) {
          cmd = 'V_INIT_0';
          filename = 'protocol_v0.json';
        } else {
          cmd = 'V_INIT_1';
          filename = 'protocol_v1.json';
        }

        /* Récupération du protocole correspondant */
        this.$http.get(`app/communication/${filename}`).then(({data}) => {
          Object.assign(this._commands, data);
          deferred.resolve();
        });

      } else {
        deferred.resolve();
      }

      let dataView = this.rawToDataView(cmd, array);
      cmdDetails = this._commands[cmd];

      this.getFullStruct(cmdDetails)
        .forEach((value, index) => {
          if (cmdDetails.dataStrings && cmdDetails.dataStrings[index]) {
            /* Caractères ASCII */
            parsedData.push(String.fromCharCode.apply(this, (array.slice(2 + byteOffset, 2 + byteOffset + value))));
          } else {
            switch (value) {
              case 1:
                parsedData.push(dataView.getUint8(byteOffset));
                break;
              case 2:
                parsedData.push(dataView.getUint16(byteOffset, this.littleEndian));
                break;
              case 4:
                parsedData.push(dataView.getUint32(byteOffset, this.littleEndian));
                break;
              default:
                /* Cas par défaut : caractères ASCII */
                parsedData.push(String.fromCharCode.apply(this, (array.slice(2 + byteOffset, 2 + byteOffset + value))));
            }
          }

          byteOffset += value;
        });

      this.$log.debug('Parsed data: ' + parsedData);
      return deferred.promise.then(() => parsedData);
    }

    /**
     * Retourne la structure complète des données d'un message
     * @param {Object} cmdDetails
     * @returns {Array}
     */
    private getFullStruct(cmdDetails: eValve.communication.ICommand): number[] {
      let fullStruct = [];

      if (cmdDetails.dataRepeat) {
        cmdDetails.dataStruct.forEach((value, index) => {
          if (typeof value === 'number') {
            fullStruct.push(value);
          } else {
            for (let i = 0; i < cmdDetails.dataRepeat[index]; i++) {
              fullStruct = fullStruct.concat(value);
            }
          }
        });
      } else {
        fullStruct = cmdDetails.dataStruct;
      }

      return fullStruct;
    }

    /**
     * Effectue les étapes de validation du message reçu
     * @param {String} cmd - Identifiant du message attendu
     * @param {Array} array - Message
     * @returns {Promise} - Promise rejetée si test échoué
     */
    private checkReceivedMessage(cmd: string, array: number[]): number[] | IError {
      let results = [
        {
          check: 'type',
          value: this.checkMessageType(cmd, array)
        }, {
          check: 'length',
          value: this.checkMessageLength(cmd, array)
        }, {
          check: 'checksum',
          value: this.checkMessageChecksum(array)
        }
      ];

      for (let index = 0; index < results.length; index++) {
        let result = results[index];
        if (!result.value) {
          throw this.ERROR_CODES['parsing'][result.check];
        }
      }

      return array;
    }

    /**
     * Vérifie le type du message reçu et le compare au type attendu
     * @param {String} cmd - Identifiant du message attendu
     * @param {Array} array - Message
     * @returns {Boolean}
     */
    private checkMessageType(cmd: string, array: number[]): boolean {
      let isTypeOk = parseInt(this._commands[cmd].type) == array[1];
      this.$log.debug('Type check: ' + isTypeOk);
      return isTypeOk;
    }

    /**
     * Indique si la longueur du message en paramètre correspond à celle attendue
     * @param {String} cmd - Identifiant du message attendu
     * @param {Array} array - Message
     * @returns {Boolean}
     */
    private checkMessageLength(cmd: string, array: number[]): boolean {
      let isLengthOk = this.getLength(cmd) == array[0];
      this.$log.debug('Length check: ' + isLengthOk);
      return isLengthOk;
    }

    /**
     * Vérifie le checksum fourni par rapport à celui calculé
     * @param {Array} array - Message
     * @returns {Boolean}
     */
    private checkMessageChecksum(array: number[]): boolean {
      let length = array[0];
      let dataSum = this.calcArraySum(array.slice(2, -2));

      let buffer = (new Uint8Array(array)).buffer;
      let parsedChecksum = (new DataView(buffer, length - 2)).getUint16(0, this.littleEndian);

      let isChecksumOk = length + array[1] + dataSum == parsedChecksum;
      this.$log.debug('Checksum check: ' + isChecksumOk);

      return isChecksumOk;
    }

  }

  angular
    .module('eValve.communication')
    .service('protocol', Protocol);
}
