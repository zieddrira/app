namespace eValve.communication {
  'use strict';

  export interface ICommand {
    type: string;
    dataLength?: number;
    dataStruct?: any[];
    dataStrings?: { [id: number]: boolean };
    dataRepeat?: { [id: number]: number };
    response?: string;
    timeout?: number;
  }

  export interface ICommands {
    [id: string]: ICommand;
  }

  export interface IError {
    code: number;
    message: string;
  }

  export interface IErrors {
    [id: string]: { [id: string]: IError };
  }

  const ERROR_CODES: IErrors = {
    /* 1x : Erreurs BLE lors de l'envoi de message */
    send: {
      retry: {
        code: 11,
        message: 'La vanne ne répond pas à l\'envoi de la commande.'
      }
    },

    /* 2x : Erreurs BLE lors de la réception d'une réponse */
    receive: {
      ack: {
        code: 21,
        message: 'Mauvais indicateur de réception côté vanne'
      },
      length: {
        code: 22,
        message: 'La longueur du message reçu ne correspond pas à celle indiquée'
      },
      timeout: {
        code: 23,
        message: 'Malgré plusieurs essais, la vanne ne répond pas dans le temps imparti.'
      },
      counter: {
        code: 24,
        message: 'Erreur dans le compteur des frames reçues'
      },
      auth: {
        code: 25,
        message: 'Erreur lors de l\'authentification'
      },
      timestamp: {
        code: 26,
        message: 'L\'écart entre le timestamp de la vanne et celui de l\'application est supérieur à la valeur maximale configurée'
      }
    },

    /* 3x : Erreurs de parsing du message reçu */
    parsing: {
      type: {
        code: 31,
        message: 'Le type de message reçu ne correspond pas à celui attendu.'
      },
      length: {
        code: 32,
        message: 'La longueur du message ne correspond pas à celle attendue.'
      },
      checksum: {
        code: 33,
        message: 'Le checksum envoyé ne correspond pas à celui calculé.'
      }
    }
  };

  angular
    .module('eValve.communication', [])
    // .constant('COMMANDS', COMMANDS)
    .constant('ERROR_CODES', ERROR_CODES)
    .constant('BLE_VARS', {
      service: '01234567-89AB-CDEF-0123-456789ABCDEF',
      data: '00000000-0000-0000-0000-000000000001',
      app_ack: '00000000-0000-0000-0000-000000000003',
      vanne_ack: '00000000-0000-0000-0000-000000000002'
    });
}
