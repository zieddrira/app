namespace eValve.communication {
  'use strict';

  export interface ITransport {
    // receiveData(cmdTimeout?: number): ng.IPromise<any>;
    sendData(data: any[], frameCount?: number, retry?: number): ng.IPromise<any>;
    toggleReception(newVal: boolean, multiple?: boolean): void;
  }

  export class Transport implements ITransport {
    private _dataListener: Function;
    private _globalCounter: number = 0;
    private _multipleMessages: boolean = false;
    private _receivedFrames: Uint8Array[] = [];
    private _receiving: boolean = false;
    private _receiveTimeout: ng.IPromise<any>;

    static $inject: Array<string> = ['$rootScope', 'bluetooth', 'BLE_VARS', 'ERROR_CODES', '$timeout', '$q', '$log'];
    constructor(
      private $rootScope: ng.IRootScopeService,
      private bluetooth: eValve.communication.IBluetooth,
      private BLE_VARS: any,
      private ERROR_CODES: eValve.communication.IErrors,
      private $timeout: ng.ITimeoutService,
      private $q: ng.IQService,
      private $log: ng.ILogService
    ) {
      this.$rootScope.$on('ble:notify:' + BLE_VARS.data, (event, result) => this.onNotification(event, result));
    }

    /**
     * Active ou désactive le flag receiving
     * @param {Boolean} newVal - Nouvelle valeur du flag
     * @param {Boolean} [multiple] - Indique si on doit maintenir la réception de données active
     */
    toggleReception(newVal: boolean, multiple?: boolean) {
      this._receiving = newVal;
      this._multipleMessages = multiple || false;
    }

    /**
     * @deprecated La réception des données se fait maintenant via onNotification
     *
     * Récupère les données envoyées par la vanne sur la caractéristique d'échange
     * @param {Number} [cmdTimeout] - Timeout custom de la commande à réceptionner (ms)
     * @returns {Promise}
     */
    receiveData(cmdTimeout?: number): ng.IPromise<any> {
      let data = [],
        frameCount = 0,
        deferred = this.$q.defer(),
        timeout = this.vanneTimeout(deferred, cmdTimeout),
        countStack = [],
        dataStack = [];

      this.$log.debug('Begin receiving data...');
      this._dataListener = this.$rootScope.$on('ble:notify:' + this.BLE_VARS.data,
        (event, result) => {
          let receivedData = this.bufferToTypedArray(result);
          this.$log.debug('Received frame: ' + this.typedArrayToArray(receivedData));

          let count = receivedData[receivedData.byteLength - 1];
          this.$timeout.cancel(timeout);

          /* Si le compte de la frame ne correspond pas au nôtre, on n'écrit pas de ack */
          if (countStack.length && (count & 0x7F) > (countStack[countStack.length - 1] + 1)) {
            return deferred.reject(this.ERROR_CODES['receive']['ack']);
          } else {
            countStack.push(count);
            dataStack.push(receivedData);
          }

          this.bluetooth
            .write(new Uint8Array([count]), this.BLE_VARS.service, this.BLE_VARS.app_ack)
            .then(() => {
              let dataToCompute = dataStack.shift();
              let countToCompute = countStack.shift();

              if ((countToCompute & 0x7F) != frameCount) {
                this.$log.debug(`Starting error timeout (countToCompute = ${countToCompute}, frameCount = ${frameCount})`);
                timeout = this.vanneTimeout(deferred, cmdTimeout);
                return;
              }

              data = data.concat(this.typedArrayToArray(dataToCompute).slice(0, -1));
              frameCount++;
              this.$log.debug('Data parsed');

              /* Si dernière frame, on retourne la donnée complète */
              if (countToCompute & 0x80) {
                this._dataListener();
                timeout && this.$timeout.cancel(timeout);
                this.$log.debug('Received data:' + data);

                if (!this.checkReceivedLength(data)) {
                  deferred.reject(this.ERROR_CODES['receive']['length']);
                } else {
                  deferred.resolve(data);
                }

              } else {
                this.$log.debug('Message not complete, starting next frame timeout...');
                timeout = this.vanneTimeout(deferred, cmdTimeout);
              }
            });
        });

      return deferred.promise;
    }

    /**
     * Ecrit sur la caractéristique de donnée en plusieurs fois si besoin
     * @param {Array} data
     * @param {Number} [frameCount]
     * @param {Number} [retry]
     * @returns {Promise}
     */
    sendData(data: any[], frameCount?: number, retry?: number): ng.IPromise<any> {
      let dataToSend;
      retry = retry || 0;

      if (!angular.isDefined(frameCount)) {
        frameCount = 0;
        this.bluetooth.toggleNotifications(this.BLE_VARS.vanne_ack);
      }

      if (data.length > 19) {
        dataToSend = data.slice(0, 19);
      } else {
        dataToSend = data;
        frameCount = frameCount | 0x80;
      }

      let frame = new Uint8Array(dataToSend.length + 1);
      frame.set(dataToSend);
      frame.set([frameCount], frame.byteLength - 1);

      return this.bluetooth
        .write(frame, this.BLE_VARS.service, this.BLE_VARS.data)
        .then(() => {
          this.$log.debug('Frame sent: ' + this.typedArrayToArray(frame));
          this.$log.debug('Frame count: ' + frameCount);

          let notifValue = this.bluetooth.getLastNotificationValue(this.BLE_VARS.vanne_ack);
          if (notifValue != null && this.bufferToTypedArray(notifValue)[0] == frameCount) {
            this.$log.debug('Ack already received: ' + frameCount);
            return this.sendNextFrame(data, frameCount);
          } else {
            return this.$timeout(() => {
              notifValue = this.bluetooth.getLastNotificationValue(this.BLE_VARS.vanne_ack);

              if (notifValue != null && this.bufferToTypedArray(notifValue)[0] == frameCount) {
                this.$log.debug('Ack finally received: ' + frameCount);
                return this.sendNextFrame(data, frameCount);
              } else {
                this.$log.debug('Ack timeout or invalid');
                if (++retry < 3) {
                  this.$log.debug('Sending retry < 3, sending again...');
                  return this.sendData(data, frameCount, retry);
                } else {
                  this.$log.debug('Sending retry == 3, throwing error...');
                  return this.$q.reject(this.ERROR_CODES['send']['retry']);
                }
              }
            }, 200);
          }
        });
    }

    /**
     * Appelée lors de la réception de données
     * @param {Object} event - Evénement angular
     * @param {ArrayBuffer} result - Trame BLE reçue
     */
    private onNotification(event: any, result: ArrayBuffer) {
      this._receiveTimeout && this.$timeout.cancel(this._receiveTimeout);
      let fullMessageData: Array<Uint8Array>;
      let receivedData = this.bufferToTypedArray(result);
      let ack = receivedData[receivedData.byteLength - 1];
      let counterCopy = this._globalCounter++;

      if (!this._receiving) {
        return;
      }

      this.$log.debug(`Received frame: ${this.typedArrayToArray(receivedData)}, global counter: ${counterCopy}`);
      this._receivedFrames.push(receivedData);
      if (ack & 0x80) {
        fullMessageData = this._receivedFrames.splice(0, this._receivedFrames.length);
      }

      this.sendDataAck(ack, counterCopy);

      if (ack & 0x80) {
        if (!this._multipleMessages) {
          this._receiving = false;
        }

        this._receiveTimeout && this.$timeout.cancel(this._receiveTimeout);

        let counter = 0,
          parsedData: number[] = [];

        let messageOk = fullMessageData.every(value => {
          if (counter == (value[value.byteLength - 1] & 0x7F) + 1) {
            this.$log.debug('Frame already parsed (same counter)');
            /* Si le compteur de la trame est le même que précédemment, on ignore */
            return true;
          } else if (counter++ != (value[value.byteLength - 1] & 0x7F)) {
            /* Si différent que précédemment et différent de la valeur attendue, erreur */
            return false;
          }

          Array.prototype.push.apply(parsedData, this.typedArrayToArray(value).slice(0, -1));
          return true;
        });

        if (!messageOk && this._multipleMessages && fullMessageData.length == 1) {
          return;
        }

        if (messageOk) {
          if (this.checkReceivedLength(parsedData)) {
            this.$rootScope.$emit('ble:read:success', parsedData);
          } else {
            this._receivedFrames = [];
            this.$rootScope.$emit('ble:read:error', this.ERROR_CODES['receive']['length']);
          }
        } else {
          this._receivedFrames = [];
          this.$rootScope.$emit('ble:read:error', this.ERROR_CODES['receive']['counter']);
        }
      }
    }

    /**
     * Envoie le ack de réception de données et réessaye 3 fois si nécessaire
     * @param {Number} ack - Valeur du compteur à retourner
     * @param {Number} counter - Compteur du nombre de frames échangées
     * @param {Number} [retry] - Nombre de retry passés
     * @returns {Promise} Promise complétée après l'envoi ou l'échec
     */
    private sendDataAck(ack: number, counter: number, retry?: number): ng.IPromise<void> {
      retry = retry || 0;

      return this.bluetooth
        .write(new Uint8Array([ack]), this.BLE_VARS.service, this.BLE_VARS.app_ack)
        .then(() => {
          if (!this._receiving) {
            return;
          }

          if (retry++ < 3) {
            this._receiveTimeout && this.$timeout.cancel(this._receiveTimeout);
            this._receiveTimeout = this.$timeout(() => {
              this.$log.debug(`Ack timeout n° ${retry} for ack ${ack}, global counter: ${counter}`);
              if (this._receiving) {
                return this.sendDataAck(ack, counter, retry);
              }
            }, 200);

          } else {
            this._receiving = false;
            this._receivedFrames = [];

            this.$log.debug('Vanne timeout !');
            this.$rootScope.$emit('ble:read:error', this.ERROR_CODES['receive']['timeout']);
          }
        });
    }

    /**
     * Incrémente le compteur de frames et envoie la suivante
     * @param {Array} data
     * @param {Number} frameCount
     * @returns {Promise} Promise de l'envoi des données
     */
    private sendNextFrame(data: any[], frameCount: number): ng.IPromise<any> {
      frameCount++;
      let remainingData = data.length > 19 ? data.slice(19) : [];
      if (remainingData.length) {
        return this.sendData(remainingData, frameCount);
      } else {
        this.bluetooth.toggleNotifications(this.BLE_VARS.vanne_ack, true);
        return this.$q.resolve();
      }
    }

    /**
     * Rejette une promise si le timeout est écoulé (2 secondes par défaut)
     * @param {Deferred} deferred
     * @param {Number} [time] - Durée du timeout en millisecondes
     * @returns {Promise}
     */
    private vanneTimeout(deferred: ng.IDeferred<any>, time?: number): ng.IPromise<void> {
      return this.$timeout(() => {
        this.$log.debug('Vanne timeout !');
        this._dataListener && this._dataListener();

        deferred.reject(this.ERROR_CODES['receive']['timeout']);
      }, time || 10000);
    }

    /**
     * Compare la longueur du message reçu avec celle annoncée
     * @param {Array} data
     * @returns {Boolean}
     */
    private checkReceivedLength(data: any[]): boolean {
      return data.length == data[0];
    }

    /**
     * Retourne un buffer converti sous forme de TypedArray
     * @param {ArrayBuffer} buffer
     * @returns {Uint8Array}
     */
    private bufferToTypedArray(buffer: ArrayBuffer): Uint8Array {
      return new Uint8Array(buffer);
    }

    /**
     * Transforme un TypedArray en Array classique
     * @param {Uint8Array} typedArray
     * @returns {Array}
     */
    private typedArrayToArray(typedArray: Uint8Array): Array<any> {
      return Array.prototype.slice.call(typedArray);
    }

  }

  angular
    .module('eValve.communication')
    .service('transport', Transport);
}
