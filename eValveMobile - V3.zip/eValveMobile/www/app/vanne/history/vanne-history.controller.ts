namespace eValve.vanne {
  'use strict';

  export class HistoryController {
    private _datePopup: ionic.popup.IonicPopupPromise;
    private _displayedSection: number;

    positions = ['Ouverte', 'Fermée', 'Débit limité'];
    historyLevels = ['Journée', 'Semaine', 'Mois', 'Année'];

    displayedDate: string;
    history: IFullHistory;
    historyPositions: Array<{ view: number, day: Date }>;
    isTempExternSensorOk: (data: IValve) => boolean;
    popupDate: { view: number, day: Date };
    vanneErrors: Array<{ [id: string]: string }>;
    vanneProtocol: number;

    chosenDate = {
      view: 0, // Vue jour
      day: <Date>null
    };

    chartConfig = {
      // loading: 'Chargement...',
      credits: { enabled: false },

      options: {
        /* Config highcharts de base, correspondant à l'api */
        chart: {
          type: 'column',
          zoomType: 'x'
        },
        colors: ['#009ed2', '#000000', '#888888'],
        plotOptions: {
          column: {
            stacking: 'normal',
            dataLabels: {
              enabled: true,
              color: (Highcharts.theme && Highcharts.theme.dataLabelsColor) || 'white',
              style: {
                textShadow: '0 0 3px black'
              },
              formatter: function () {
                if (!this.percentage) {
                  return;
                }

                return Math.round(this.percentage) + '%';
              }
            },
            events: {
              /* Clic sur un point du graphe */
              click: (event) => {
                this.$log.debug('Timestamp selected: ' + JSON.stringify(event.point.x));
                this.historyPositions.push(angular.copy(this.chosenDate));

                this.chosenDate.view--;
                this.chosenDate.day = new Date(event.point.x);
                this.onDateChange(this.chosenDate);

                this.getHistory(this.chosenDate.day, this.chosenDate.view);
              },
              /* Clic sur un élément de la légende (désactivation) */
              legendItemClick: function () {
                return false;
              }
            }
          }
        },
        scrollbar: {
          enabled: false
        },
        yAxis: {
          title: { text: 'Volume total (L)' },
          stackLabels: {
            enabled: true
          }
        }
      },

      title: { text: null },
      xAxis: {
        type: 'datetime',
        currentMin: 0,
        currentMax: 6
      },
      series: []
    };

    static $inject: Array<string> = ['vanne', '$scope', '$ionicPopup', '$cordovaDatePicker',
      'VANNE_CONSTS', '$ionicLoading', '$log', '$filter', '$ionicScrollDelegate', '$timeout'];
    constructor(
      private vanne: IVanne,
      private $scope: ng.IScope,
      private $ionicPopup: ionic.popup.IonicPopupService,
      private $cordovaDatePicker: ngCordova.IDatePickerService,
      private VANNE_CONSTS: any,
      private $ionicLoading: ionic.loading.IonicLoadingService,
      private $log: ng.ILogService,
      private $filter: ng.IFilterService,
      private $ionicScrollDelegate: ionic.scroll.IonicScrollDelegate,
      private $timeout: ng.ITimeoutService
    ) {
      this.vanneErrors = this.VANNE_CONSTS.vanneErrors;
      this.isTempExternSensorOk = this.vanne.isSelectedValveTempExternSensorOk;

      // this.$scope.$on('$ionicView.beforeEnter', () => {
      this.vanneProtocol = this.vanne.selectedValveProtocolVersion;

      if (this.chosenDate.day && this.chosenDate.day.getTime() == new Date().setHours(0, 0, 0, 0)) {
        /* Si l'historique est positionné sur le jour actuel, on rafraîchit au chargement */
        this.getHistory(this.chosenDate.day, 0);
      }
      // });

      this.$scope.$on('$ionicView.beforeLeave', () => {
        /* On réactive le scroll en quittant l'historique */
        this.$ionicScrollDelegate.freezeAllScrolls(false);
      });
    }

    /**
     * Affiche la popup de sélection de la date
     */
    openDatePopup() {
      this.popupDate = angular.copy(this.chosenDate);

      this._datePopup = this.$ionicPopup.show({
        title: 'Sélection directe',
        templateUrl: 'app/vanne/history/vanne-history.popup.html',
        scope: this.$scope,
        buttons: [
          { text: 'Annuler' },
          {
            text: 'Valider',
            type: 'button-positive',
            onTap: (e) => {
              if (this.popupDate.view == null || !this.popupDate.day) {
                this._datePopup.close();
                return this.$ionicPopup
                  .alert({
                    title: 'Erreur de sélection',
                    template: 'Vous devez sélectionner une date et une vue',
                    okType: 'button-assertive'
                  })
                  .then(() => this.openDatePopup());
              }

              this.historyPositions = [];
              this.chosenDate = this.popupDate;
              this.onDateChange(this.chosenDate);

              this.getHistory(this.chosenDate.day, this.chosenDate.view);
            }
          }
        ]
      });
    }

    /**
     * Affiche un datepicker natif pour sélectionner le jour
     */
    showDatePicker() {
      let today = new Date();
      today.setHours(0, 0, 0, 0);

      let dateOptions = {
        date: this.popupDate.day || today,
        maxDate: today,
        // allowFutureDates: false, //iOS only
        mode: 'date',
        locale: 'fr_fr'
      };

      this.$cordovaDatePicker
        .show(dateOptions)
        .then((settedDate: Date) => this.onDateSelect(settedDate));
    }

    /**
     * Appelée lors de la sélection d'une date via le datepicker, récupère les données correspondantes
     * @param {Date} date - Date sélectionnée
     */
    onDateSelect(date: Date) {
      if (!date) {
        return;
      }

      this.popupDate.day = date;
    }

    /**
     * Récupère l'historique auprès de la vanne ou de la bdd pour la date sélectionnée
     * @param {Date} date - Date de l'historique souhaité
     * @param {Number} view - Vue demandée de l'historique
     */
    getHistory(date: Date, view: number) {
      let granularity: number;
      this.chartConfig.series = [];

      switch (view) {
        case 0:
          /* Vue journée */
          granularity = 15;
          break;
        case 1:
          /* Vue semaine */
          granularity = 1440;
          break;
        case 2:
          /* Vue mois */
          granularity = 10080;
          break;
        case 3:
          /* Vue année */
          granularity = 43200;
          break;
        default:
      }

      this.$ionicLoading.show();
      let begin = new Date().getTime();
      this.vanne
        .getHistory(date, granularity)
        .catch(error => {
          // $log.error(error);
          this.$ionicPopup.alert({
            title: 'Pas de données',
            template: 'Il n\'y a pas de données enregistrées pour cette période. Veuillez vous connecter à la vanne.',
            okType: 'button-assertive'
          });
        })
        .then((history: IFullHistory | void) => {
          this.history = null;

          if (!this.isHistoryValid(history)) {
            return;

          } else {
            if (!history.length) {
              this.$ionicLoading.hide();
              return this.$ionicPopup.alert({
                title: 'Pas de données',
                template: 'Il n\'y a pas de données disponibles pour cette période sur la vanne.',
                okType: 'button-assertive'
              });
            }

            if (this.isHistoryComputed(view, history)) {
              this.loadHistoryIntoChart(history);
              this.history = history;
              // } else if (this.vanne.selectedValveProtocolVersion == 1) {
              //   this.history = history.map((value, index, array) => {
              //     if (value.action == 0xA0) {
              //       let nextValue = array[index + 1];
              //       while (nextValue && nextValue.frameType != HistoryType.Asynchronous) {
              //         /* On cherche la prochaine valeur asynchrone de l'historique */
              //         nextValue = array[array.indexOf(nextValue) + 1];
              //       }

              //       if (nextValue) {
              //         /* Si applicable, calcul du volume écoulé suite à une action dûe au capteur 1 */
              //         value.volumeDueToSensor1 = nextValue.index - value.index;
              //       }
              //     }

              //     return value;
              //   });
            } else {
              this.history = history;
            }
          }
        })

        .finally(() => {
          this.$log.info('Time: ' + (new Date().getTime() - begin));
          this.$ionicLoading.hide();
        });
    }

    /**
     * Charge l'historique récupéré dans le graphe. Il s'agit forcément d'un historique computé, pas journalier.
     * @param {Array<IHistoryComputedElement>} [history] - Historique à parser
     */
    loadHistoryIntoChart(history: Array<IHistoryComputedElement>) {
      history = history || <Array<IHistoryComputedElement>>this.history;
      let initialSeries = [
        { name: 'Ouvert', id: 0x01, data: [] },
        { name: 'Fermé', id: 0x02, data: [] },
        { name: 'Limité', id: 0x03, data: [] }
      ];

      this.chartConfig.series = history.reduce((series, historyValue) => {
        return series.map(serie => {
          serie.data.push([historyValue.timestamp, historyValue.detailedVolumes[serie.id]]);
          return serie;
        });
      }, initialSeries);

      this.$timeout(() => {
        let openHistory = this.chartConfig.series[0].data;

        let highcharts = this.chartConfig.getHighcharts();
        highcharts.xAxis[0].setExtremes(openHistory[0][0], (openHistory[6] && openHistory[6][0]) || openHistory[openHistory.length - 1][0]);
      });

      // this.chartConfig.loading = false;
    }

    /**
     * Recule l'historique à la vue précédente
     */
    revertHistory() {
      if (!this.historyPositions.length) {
        return;
      }

      this.chosenDate = this.historyPositions.pop();
      this.onDateChange(this.chosenDate);

      this.getHistory(this.chosenDate.day, this.chosenDate.view);
    }

    /**
     * Met à jour la date affichée et active/désactive le scroll en fonction de la vue
     * @param {Object} newDate - Nouvel objet date avec jour et vue
     */
    onDateChange(newDate: { day: Date, view: number }) {
      if (!newDate || !newDate.day || newDate.view == null) {
        return;
      }

      switch (newDate.view) {
        case 0:
          this.displayedDate = this.$filter('date')(newDate.day, 'dd/MM/yyyy');
          break;
        case 1:
          this.displayedDate = 'Semaine du ' + this.$filter('date')(newDate.day, 'dd/MM/yyyy');
          this.$ionicScrollDelegate.freezeAllScrolls(true);
          break;
        case 2:
          this.displayedDate = this.$filter('date')(newDate.day, 'MMMM yyyy');
          this.$ionicScrollDelegate.freezeAllScrolls(true);
          break;
        case 3:
          this.displayedDate = this.$filter('date')(newDate.day, 'yyyy');
          this.$ionicScrollDelegate.freezeAllScrolls(true);
          break;
        default:
      }
    }

    /**
     * Détermine l'événement dont les stats sont affichées dans la vue
     * @param {Number} index - Index de l'événement
     */
    toggleEvent(index: number) {
      if (this.isEventDisplayed(index)) {
        this._displayedSection = null;
      } else {
        this._displayedSection = index;
      }
    }

    /**
     * Indique si l'événement de l'index en paramètre est sélectionné
     * @param {Number} index - Index de l'événement
     * @returns {Boolean}
     */
    isEventDisplayed(index: number): boolean {
      setTimeout(() => this.$ionicScrollDelegate.resize(), 100);
      return this._displayedSection === index;
    }

    /**
     * Vérifie que l'historique passé en paramètre est bien différent de null ou undefined
     * @param {Object} history
     * @returns {Boolean}
     */
    private isHistoryValid(history: IFullHistory | void): history is IFullHistory {
      return !!history;
    }

    /**
     * Détermine si l'historique est computé ou pas en fonction de la vue associée
     * @param {Number} view
     * @param {Object[]} history
     * @returns {Boolean}
     */
    private isHistoryComputed(view: number, history: IFullHistory): history is IHistoryComputedElement[] {
      return view != 0;
    }

  }

  actionText.$inject = ['vanne'];
  function actionText(vanne: IVanne) {
    return (value: number) => {
      return vanne.getLabelForInitiator(value);
    };
  }

  angular
    .module('eValve.vanne')
    .controller('HistoryController', HistoryController)
    .filter('actionText', actionText);
}
