namespace eValve.vanne {
  'use strict';

  export class VannePurgesController {
    private _displayedPurge: IPurgeAuto;

    batteryCharge: number = 0;
    days: Array<string>;
    frequencies: Array<string>;
    parsedInhibitionUnit: string;
    parsedTempoUnit: string;
    prog: IValveProgram;
    progUnits: {
      tempo: { [id: string]: { code: number, unit: string } },
      inhibition: { [id: string]: { code: number, unit: string } }
    };
    purgesChanged: boolean;
    purgePositions: { [id: string]: { code: number, value: string } };
    purgesWatch: Function;
    settings: { units: IPurgeUnits, inhibitions: { auto: IPurgeInhibition, manual: IPurgeInhibition, sensor: IPurgeInhibition } };
    tempParsedInhibitionUnit: string;
    purgesErrors: IPurgeCheck[] = [];

    static $inject: Array<string> = ['vanne', 'calendar', '$scope', '$log', '$ionicPopup', '$q', 'VANNE_CONSTS', 'ERROR_CODES'];
    constructor(
      private vanne: IVanne,
      private calendar: eValve.core.ICalendar,
      private $scope: ng.IScope,
      private $log: ng.ILogService,
      private $ionicPopup: ionic.popup.IonicPopupService,
      private $q: ng.IQService,
      private VANNE_CONSTS: any,
      private ERROR_CODES: eValve.communication.IErrors
    ) {
      this.days = calendar.days;
      this.frequencies = calendar.frequencies;

      this.progUnits = VANNE_CONSTS.progUnits;
      this.purgePositions = VANNE_CONSTS.purgePositions;

      $scope.$on('$ionicView.beforeEnter', () => this.getProg());
    }

    /**
     * Détermine la purge dont les détails sont affichés sur la vue
     * @param {IPurgeAuto} purge
     */
    togglePurge(purge: IPurgeAuto) {
      if (this.isPurgeDisplayed(purge)) {
        this._displayedPurge = null;
      } else {
        this._displayedPurge = purge;
      }
    }

    /**
     * Indique si la purge en paramètre est sélectionnée
     * @param {IPurgeAuto} purge
     * @returns {Boolean}
     */
    isPurgeDisplayed(purge: IPurgeAuto): boolean {
      return this._displayedPurge === purge;
    }

    /**
     * Récupère les programmes de purge de la borne ou les programmes par défaut le cas échéant
     */
    getProg() {
      this.prog = null;

      this.vanne
        .getProg()
        .catch(response => {
          /* On arrive ici si le prog est en bdd mais que la communication avec la vanne a échoué */
          if (response.error.code == this.ERROR_CODES['receive']['timeout'].code) {
            this.$ionicPopup.alert({
              title: 'Programme non synchronisé',
              okType: 'button-assertive',
              template: 'Le programme affiché est celui contenu sur le téléphone, pas sur la vanne'
            });

            return response.prog;
          }
        })
        .then((prog: IValveProgram) => this.initVm(prog));
    }

    /**
     * Synchronise les purges avec la vanne
     */
    sync() {
      if (!this.purgesChanged) {
        return;
      }

      let deferred = this.$q.defer();
      if (this.prog.inhibitions.auto.active) {
        this.$ionicPopup
          .confirm({
            title: 'Purges auto inhibées',
            template: 'Les purges automatiques sont actuellement inhibées, vous pouvez les réactiver via le menu en haut à droite.',
            cancelText: 'Annuler'
          })
          .then((result: boolean) => {
            if (result) {
              deferred.resolve();
            } else {
              deferred.reject();
            }
          });
      } else {
        deferred.resolve();
      }

      deferred
        .promise
        .then(() => {
          /* On recherche les différentes programmations qui produisent des erreurs (volume ou tempo = 0) */
          /* Attribution d'un ID pour les purges, et sélection des purges auto actives qui sont en erreur */
          this.purgesErrors = this.prog.auto;
          this.purgesErrors.forEach((purge: IPurgeCheck) => purge.id = this.purgesErrors.indexOf(purge) + 1);
          this.purgesErrors = this.purgesErrors.filter((purgeAuto: IPurgeCheck) =>
            purgeAuto.isActive && (!purgeAuto.volume || !purgeAuto.tempo || purgeAuto.volume === 0 || purgeAuto.tempo === 0 ||
              !purgeAuto.parsedStartDate)
          );

          if (!this.prog.manual.tempo || !this.prog.manual.volume || this.prog.manual.volume === 0 || this.prog.manual.tempo === 0) {
            this.purgesErrors.push(this.prog.manual);
          }

          if (this.purgesErrors.length > 0) {
            this.$ionicPopup.show({
              title: 'Résultat de l\'action :',
              templateUrl: 'app/vanne/purges/vanne-purges.error.html',
              scope: this.$scope,
              buttons: [{
                text: 'OK',
                type: 'button-assertive'
              }]
            })
              .finally(() => this.purgesErrors = []);
            return this.prog;
          } else {
            /* On update les valeurs des dates de purge et on supprime les propriétés parsées */
            this.prog.auto.forEach((value: IPurgeAuto) => {
              value.startDate = (value.parsedStartDate && value.parsedStartDate.getTime()) || new Date().getTime();
              value.parsedStartDate && delete value.parsedStartDate;
            });

            return this.vanne.saveProg(this.prog);
          }
        })
        .then((prog: IValveProgram) => this.initVm(prog))
        .then(() => {
          if (this.purgesErrors.length === 0) {
            this.$ionicPopup.alert({
              title: 'Programmation enregistrée',
              template: 'Les purges ont bien été enregistrées sur la vanne'
            });
          }
        })
        .catch(error => {
          this.$log.error(error);
          // TODO
        });
    }

    /**
     * Initialise le vm et les valeurs parsées
     * @param {IValveProgram} prog - Programme de la vanne
     */
    initVm(prog: IValveProgram) {
      this.prog = angular.copy(prog);

      if (Object.keys(this.prog).length == 0) {
        /* Si le programme est vide, c'est qu'il n'y a rien sur la vanne */
        this.$ionicPopup.alert({
          title: 'Pas de programme',
          template: 'Il n\'y a pas de programme sur la vanne actuellement'
        });

        if (this.vanne.selectedValveSerial == this.vanne.connectedValveSerial) {
          /* On crée un nouveau programme vierge */
          this.prog = {
            auto: [],
            manual: {
              'volume': 1,
              'tempo': 0x01,
              'position': 0x00
            },
            units: {
              'tempo': 0x02,
              'inhibition': 0x00
            },
            inhibitions: {
              'auto': {
                'active': false,
                'value': 0
              },
              'manual': {
                'active': false,
                'value': 0
              },
              'sensor': {
                'active': false,
                'value': 0
              }
            }
          };

          let startDate = new Date().getTime();
          for (let index = 0; index < 10; index++) {
            this.prog.auto && this.prog.auto.push({
              'tempo': 0,
              'volume': 0,
              'activeFrequency': 0,
              'isActive': false,
              'position': 0x00,
              'startDate': startDate
            });
          }

        } else {
          /* Si pas connectée, on ne remplit rien et on ne watche rien */
          return;
        }
      }

      this.parsedTempoUnit = this.unitToString(this.progUnits.tempo, this.prog.units.tempo);
      this.parsedInhibitionUnit = this.unitToString(this.progUnits.inhibition, this.prog.units.inhibition);

      /* On génère les dates au bon format */
      this.prog.auto.forEach((value, index) => {
        value.parsedStartDate = (value.startDate && new Date(value.startDate)) || new Date();
      });

      /* Modification du volume et de la temp de la purge manuelle si elle vaut déjà 0 pour éviter un message d'erreur par défaut */
      if (this.prog.manual.volume === 0) {
        this.prog.manual.volume = 1;
      }
      if (this.prog.manual.tempo === 0x00) {
        this.prog.manual.tempo = 0x01;
      }

      this.purgesWatch && this.purgesWatch();

      let originalPurges = angular.copy(this.prog);
      this.purgesWatch = this.$scope.$watch(() => { return this.prog; }, (newVal: IValveProgram) => {
        this.purgesChanged = !angular.equals(newVal, originalPurges);

        let monthlyPurges = newVal.auto && newVal.auto.reduce((previousValue: number, currentValue: IPurgeAuto) => {
          if (!currentValue.isActive) { return previousValue; }

          let sum = currentValue.activeFrequency == 0 ? 4 : 1;
          return previousValue + sum;
        }, 0);

        if (monthlyPurges <= 28) {
          this.batteryCharge = 0;
        } else if (monthlyPurges > 28 && monthlyPurges < 40) {
          this.batteryCharge = 1;
        } else if (monthlyPurges == 40) {
          this.batteryCharge = 2;
        }

      }, true);
    }

    /**
     * Affiche la popup des paramètres du programme
     */
    openSettingsPopup() {
      /* Copie des paramères du prog dans une variable temporaire */
      this.settings = {
        units: angular.copy(this.prog.units),
        inhibitions: angular.copy(this.prog.inhibitions)
      };

      this.tempParsedInhibitionUnit = this.parsedInhibitionUnit;

      this.$ionicPopup.show({
        title: 'Paramètres du programme',
        templateUrl: 'app/vanne/purges/vanne-purges.settings.html',
        scope: this.$scope,
        buttons: [
          { text: 'Annuler' },
          {
            text: 'Sauver',
            type: 'button-positive',
            onTap: (e) => {
              /* Si validé, enregistrement des paramètres dans le prog */
              angular.merge(this.prog, this.settings);
              this.parsedInhibitionUnit = this.tempParsedInhibitionUnit;
              this.parsedTempoUnit = this.unitToString(this.progUnits.tempo, this.prog.units.tempo);
            }
          }
        ]
      });
    }

    /**
     * Appelée lors d'un changement d'unité pour l'inhibition, met à jour la string
     */
    updateInhibitionUnit() {
      this.tempParsedInhibitionUnit = this.unitToString(this.progUnits.inhibition, this.settings.units.inhibition);
    }

    /**
     * Renvoie la string correspondant à l'unité en paramètre
     * @param {Object} dico - Objet contenant les valeurs possibles
     * @param {Number} value - Valeur à rechercher
     * @returns {String} String correspondant à la valeur cherchée
     */
    private unitToString(dico: any, value: number): string {
      for (let key in dico) {
        if (dico.hasOwnProperty(key)) {
          let tempo = dico[key];
          if (tempo.code == value) {
            return tempo.unit;
          }
        }
      }
    }

  }

  angular
    .module('eValve.vanne')
    .controller('VannePurgesController', VannePurgesController);
}
