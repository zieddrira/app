namespace eValve.vanne {
  'use strict';

  type TempExtViewModel = IValveTempExt & { topThresholdActivated?: boolean };

  export class VanneTemperatureController {
    actions: Array<{ code: number, label: string }>;
    actionError: boolean = false;
    configChanged: boolean;
    selectedAction: { code: number, label: string };
    tempAction: number;
    tempExt: TempExtViewModel;
    thresholdsErrors: IThresholdError[] = [];
    seuils: ICourbes = {
      one:
      { desc: false, asc: false },
      two:
      { desc: false, asc: false },
      mixed: false
    };
    positions = {
      'open': { code: 0x01, label: 'Position Ouverte' },
      'closed': { code: 0x02, label: 'Position Fermée' },
      'limited': { code: 0x03, label: 'Position Débit limité' }
    };

    private _configWatch: Function;
    private _originalConfig: TempExtViewModel;
    private _parsedBottomPosition: string;
    private _parsedTopPosition: string;
    private _devWidth: number;
    private _devHeight: number;
    private ratioGraph: number;

    static $inject: Array<string> = ['vanne', '$scope', '$log', 'VANNE_CONSTS', '$ionicPopup',
      '$ionicScrollDelegate', '$window'];
    constructor(
      private vanne: IVanne,
      private $scope: ng.IScope,
      private $log: ng.ILogService,
      private VANNE_CONSTS: any,
      private $ionicPopup: ionic.popup.IonicPopupService,
      private $ionicScrollDelegate: ionic.scroll.IonicScrollDelegate,
      private $window: any
    ) {
      this.actions = this.VANNE_CONSTS.EOFActions;
      this.tempExt = <TempExtViewModel>{};

      this.$scope.$on('$ionicView.beforeEnter', () => {
        this.vanne
          .getTempExt()
          .then(tempExt => this.initValues(tempExt));

        /* Gestion affichage */
        this._devHeight = $window.innerHeight;
        this._devWidth = $window.innerWidth;
        /* Tant pis si il y a une scrollbar sur les petits écrans, au moins le graphe rentre en entier et les champs sont alignés */
        this.ratioGraph = (this._devWidth / this._devHeight) - 0.07;
      });
    }

    /* Getters et Setters pour gérer le - manquant sur les champs type="number" */
    get bottomThresholdValue() {
      return this._parsedBottomPosition;
    }

    get topThresholdValue() {
      return this._parsedTopPosition;
    }

    set bottomThresholdValue(value) {
      this._parsedBottomPosition = value.match(/^(-?\d*)$/) ? value : '';
      this.tempExt.bottomThreshold.value = (this._parsedBottomPosition == '' || this._parsedBottomPosition == '-' ? 0 : parseInt(value));
    }

    set topThresholdValue(value) {
      this._parsedTopPosition = value.match(/^(-?\d*)$/) ? value : '';
      this.tempExt.topThreshold.value = (this._parsedTopPosition == '' || this._parsedTopPosition == '-' ? 0 : parseInt(value));
    }

    get isSecondThresholdActive() {
      // if (this.tempExt.topThreshold.value == this.VANNE_CONSTS.minTemp) {}
      return this.tempExt.topThresholdActivated;
    }

    set isSecondThresholdActive(value: boolean) {
      /* Cas Actif => Inactif */
      if (this.tempExt.topThresholdActivated) {
        /* Recherche de la position fermée et mise à jour de la courbe correspondante */
        if (this.tempExt.bottomPosition == this.positions.closed.code) {
          this.updateCourbe(false, true, false, false, false);
        } else if (this.tempExt.middlePosition == this.positions.closed.code) {
          this.updateCourbe(true, false, false, false, false);
        } /* Quand on désactive le 2ème seuil et que la 3ème position était fermée */ else {
          /* Inversement des positions 1 et 3 et mise à jour de la courbe */
          this.tempExt.topPosition = this.tempExt.bottomPosition;
          this.tempExt.bottomPosition = this.positions.closed.code;
          this.updateCourbe(false, true, false, false, false);
        }
      } /* Cas Inactif => Actif */ else {
        /* Recherche de la position fermée et mise à jour de la courbe correspondante */
        if (this.tempExt.bottomPosition == this.positions.closed.code) {
          this.updateCourbe(false, false, false, true, false);
          /* Gestion cas particulier chgmt position 2 quand le 3ème est caché */
          if (this.tempExt.middlePosition == this.tempExt.topPosition) {
            if (this.tempExt.middlePosition == this.positions.limited.code) {
              this.tempExt.middlePosition = this.positions.open.code;
            } else {
              this.tempExt.middlePosition = this.positions.limited.code;
            }
          }
        } else if (this.tempExt.middlePosition == this.positions.closed.code) {
          this.updateCourbe(false, false, false, false, true);
        }
      }

      this.tempExt.topThresholdActivated = value;
    }

    get position1() {
      return this.tempExt.bottomPosition ? this.tempExt.bottomPosition : null;
    }

    set position1(position) {
      if (this.isSecondThresholdActive) {
        this.updatePosition('bottomPosition', position);
      } else {
        /* Cas position F => X */
        if (this.tempExt.bottomPosition == this.positions.closed.code) {
          this.tempExt.middlePosition = this.positions.closed.code;
          this.updateCourbe(true, false, false, false, false);
        }

        /* Cas position X => F */
        if (position == this.positions.closed.code) {
          this.tempExt.middlePosition = this.tempExt.bottomPosition;
          this.updateCourbe(false, true, false, false, false);
        }
      }

      this.tempExt.bottomPosition = position;
      this.managePositionStates();
    }

    get position2() {
      return this.tempExt.middlePosition ? this.tempExt.middlePosition : null;
    }

    set position2(position) {
      if (this.isSecondThresholdActive) {
        this.updatePosition('middlePosition', position);
      } else {
        /* Cas position F => X */
        if (this.tempExt.middlePosition == this.positions.closed.code) {
          this.tempExt.bottomPosition = this.positions.closed.code;
          this.updateCourbe(false, true, false, false, false);
        }

        /* Cas position X => F */
        if (position == this.positions.closed.code) {
          this.tempExt.bottomPosition = this.tempExt.middlePosition;
          this.updateCourbe(true, false, false, false, false);
        }
      }

      this.tempExt.middlePosition = position;
      this.managePositionStates();
    }

    get position3() {
      return this.tempExt.topPosition ? this.tempExt.topPosition : null;
    }

    /* Cas avec 2nd seuil par défaut */
    set position3(position) {
      this.updatePosition('topPosition', position);
      this.tempExt.topPosition = position;
      this.managePositionStates();
    }

    /**
     * Met à jour la structure qui gère l'affichage des courbes
     *
     * @param {boolean} oneDesc - 1 seuil : courbe descendante ( pos2 F | pos1 X )
     * @param {boolean} oneAsc - 1 seuil : courbe ascendante ( pos2 X | pos1 F )
     * @param {boolean} twoDesc - 2 seuils : courbe descendante ( pos3 F | pos2 X | pos1 X )
     * @param {boolean} twoAsc - 2 seuils : courbe ascendante ( pos3 X | pos2 X | pos1 F )
     * @param {boolean} mixed - 2 seuils : courbe mixte ( pos3 X | pos2 F | pos1 X )
     */
    updateCourbe(oneDesc: boolean, oneAsc: boolean, twoDesc: boolean, twoAsc: boolean, mixed: boolean) {
      this.seuils = {
        one:
        { desc: oneDesc, asc: oneAsc },
        two:
        { desc: twoDesc, asc: twoAsc },
        mixed: mixed
      };
    }

    /**
     * Bouton réinitialisation des données
     */
    resetValues() {
      this.isSecondThresholdActive = false;
      this.bottomThresholdValue = '1';
      this.tempExt.bottomThreshold.range = 1;

      this.tempExt.bottomPosition = this.positions.open.code;
      this.tempExt.middlePosition = this.positions.closed.code;
      this.tempExt.failureAction = 0x01;

      this.updateCourbe(true, false, false, false, false);
    }

    /**
     * Initialise les données de la vue courante
     *
     * @param {TempExtViewModel} tempExt
     */
    initValues(tempExt: TempExtViewModel) {
      if (Object.keys(tempExt).length == 0) {
        this.$ionicPopup.alert({
          title: 'Pas d\'information disponible',
          template: 'Les informations de configuration de température n\'ont jamais été récupérées.'
        });
        return;
      };

      this.tempExt = <TempExtViewModel>{};

      if (tempExt.topThreshold.value == this.VANNE_CONSTS.minTemp) {
        this.isSecondThresholdActive = false;
        tempExt.topThreshold.value = 0;
        this._parsedTopPosition = '0';
      } else {
        this.isSecondThresholdActive = true;
        this._parsedTopPosition = tempExt.topThreshold.value.toString();
      }

      if (tempExt.bottomThreshold.value == this.VANNE_CONSTS.minTemp) {
        tempExt.bottomThreshold.value = 0;
        this._parsedBottomPosition = '0';
      } else {
        this._parsedBottomPosition = tempExt.bottomThreshold.value.toString();
      }

      if (!this.isSecondThresholdActive) {
        if (tempExt.middlePosition == this.positions.closed.code) {
          this.updateCourbe(true, false, false, false, false);
        } else {
          this.updateCourbe(false, true, false, false, false);
        }
      } else {
        switch (this.positions.closed.code) {
          case tempExt.topPosition:
            this.updateCourbe(false, false, true, false, false);
            break;
          case tempExt.middlePosition:
            this.updateCourbe(false, false, false, false, true);
            break;
          case tempExt.bottomPosition:
            this.updateCourbe(false, false, false, true, false);
            break;
          default:
            break;
        }
      }

      this.tempExt = Object.assign(tempExt, { topThresholdActivated: this.isSecondThresholdActive });

      /* Reset le watch qui vérifie si la config a changé */
      this._configWatch && this._configWatch();

      this._originalConfig = angular.copy(this.tempExt);
      this._configWatch = this.$scope.$watch(() => { return this.tempExt; }, (newVal: TempExtViewModel) => {
        if (!newVal.topThresholdActivated && !this._originalConfig.topThresholdActivated) {
          /* Si le seuil haut n'est pas activé et ne l'était pas initialement, on ne cherche pas à comparer les valeurs correspondantes */
          this.configChanged =
            !angular.equals(newVal.bottomPosition, this._originalConfig.bottomPosition) ||
            !angular.equals(newVal.bottomThreshold, this._originalConfig.bottomThreshold) ||
            !angular.equals(newVal.failureAction, this._originalConfig.failureAction) ||
            !angular.equals(newVal.failureCountdown, this._originalConfig.failureCountdown) ||
            !angular.equals(newVal.markedAsConnected, this._originalConfig.markedAsConnected) ||
            !angular.equals(newVal.middlePosition, this._originalConfig.middlePosition);
        } else {
          this.configChanged = !angular.equals(newVal, this._originalConfig);
        }
      }, true);
    }

    /**
     * Renvoie un objet contenant les keys et values des autres positions
     *
     * @param {string} currentPosition - key de la position actuelle modifiée
     * @returns {keys: values}
     */
    getOtherPositions(currentPosition: string): {} {
      let positions = {
        bottomPosition: this.tempExt.bottomPosition,
        middlePosition: this.tempExt.middlePosition,
        topPosition: this.tempExt.topPosition
      };

      /* Renvoi des positions différentes de la position modifiée */
      let otherPositions = {};
      for (let key in positions) {
        if (key != currentPosition) {
          otherPositions[key] = positions[key];
        }
      }

      return otherPositions;
    }

    /**
     * Vérifie que les positions top et bottom ont la même valeur et renvoie la valeur
     *
     * @returns {boolean, value}
     */
    checkSamePositions() {
      let result = { sameValue: false, value: null };

      if (this.tempExt.bottomPosition === this.tempExt.topPosition) {
        result = { sameValue: true, value: this.tempExt.bottomPosition };
      }
      return result;
    }

    /**
     * Mets à jour les autres positions par rapport à la position modifiée et sa nouvelle valeur
     *
     * @param {string} currentPosition - key de la position actuelle modifiée
     * @param {number} newPosition - valeur de la nouvelle position
     */
    updatePosition(currentPosition: string, newPosition: number) {
      let otherPositions = this.getOtherPositions(currentPosition);
      let preventSwitch = false;

      /* Gestion cas particulier position milieu fermée */
      if (this.tempExt.middlePosition == this.positions.closed.code) {
        let checkValues = this.checkSamePositions();

        /* Si la position que l'on veut modifier est celle du milieu on gère le cas particulier */
        if (currentPosition == 'middlePosition') {
          if (checkValues.sameValue) {
            preventSwitch = true;
            if (checkValues.value == newPosition) {
              let otherValue = checkValues.value == this.positions.open.code ? this.positions.limited.code : this.positions.open.code;
              this.tempExt.bottomPosition = otherValue;
            }
            this.tempExt.topPosition = this.positions.closed.code;
          }
        } /* Sinon on empêche l'inversement de valeur car plusieurs cas sont possibles */ else {
          if (newPosition != this.positions.closed.code) {
            preventSwitch = true;
          } else {
            /* Gestion du cas particulier quand on veut passer en position fermée */
            if (checkValues.sameValue) {
              let otherValue = checkValues.value == this.positions.open.code ? this.positions.limited.code : this.positions.open.code;

              for (let key in otherPositions) {
                if (otherPositions[key] != newPosition) {
                  this.tempExt[key] = otherValue;
                }
              }
            }
          }
        }
      }

      if (!preventSwitch) {
        /* Recherche de la position qui contient la valeur de la nouvelle position et inversement */
        for (let key in otherPositions) {
          if (otherPositions[key] == newPosition) {
            this.tempExt[key] = this.tempExt[currentPosition];
          }
        }
      }
    }

    /**
     * Gère l'état des courbes postUpdate quand il y a deux seuils
     */
    managePositionStates() {
      if (this.isSecondThresholdActive) {
        if (this.tempExt.bottomPosition == this.positions.closed.code) {
          this.updateCourbe(false, false, false, true, false);
        } else if (this.tempExt.middlePosition == this.positions.closed.code) {
          this.updateCourbe(false, false, false, false, true);
        } else if (this.tempExt.topPosition == this.positions.closed.code) {
          this.updateCourbe(false, false, true, false, false);
        }
      }
    }

    /**
     *  Affiche la popup de gestion du capteur défaillant
     */
    showGestionDefautCapteur() {
      /* Copie des paramétrages dans une variable temporaire */
      this.tempAction = this.tempExt.failureAction;

      this.$ionicPopup.show({
        title: 'Gestion défaut capteur',
        templateUrl: 'app/vanne/temperature/vanne-temperature.settings.html',
        scope: this.$scope,
        buttons: [
          { text: 'Annuler' },
          {
            text: 'Sauver',
            type: 'button-positive',
            onTap: (e) => {
              /* Si validé, enregistrement des paramètres */
              this.tempExt.failureAction = this.tempAction;
            }
          }
        ]
      });
    }

    getLowestValue(threshold: IThreshold): number {
      return threshold.value - threshold.range;
    }

    getBiggestValue(threshold: IThreshold): number {
      return threshold.value + threshold.range;
    }

    /**
     * Vérifie les erreurs d'un seuil simple : Valeur / Portée
     *
     * @param {number} id - Identifiant d'un seuil (1 : seuil bas ou 2 : seuil haut)
     * @param {IThreshold} threshold : seuil à vérifier
     * @returns {IThresholdError} : retourne le seuil en erreur avec l'erreur détectée
     */
    checkSingleThreshold(id: number, threshold: IThreshold): IThresholdError {
      let min = -30, max = 97;
      let erroredThreshold: IThresholdError = {
        id: id, value: null, range: null, isInverted: false, isOverlapping: false,
        isRangeError: false, isRangeOverflow: false, isValueError: false, isPositionError: false
      };

      /* Vérification des valeurs saisies */
      if (threshold.value == undefined || threshold.value <= min || threshold.value > max
        || !Number.isInteger(threshold.value)) {
        erroredThreshold.isValueError = true;
        angular.merge(erroredThreshold, threshold.value);
      }
      if (threshold.range == undefined || threshold.range < 0 || threshold.range > max
        || !Number.isInteger(threshold.range)) {
        erroredThreshold.isRangeError = true;
        angular.merge(erroredThreshold, threshold.range);
      }
      if (!erroredThreshold.isValueError && !erroredThreshold.isRangeError) {
        let lowestValue = this.getLowestValue(threshold);
        let biggestValue = this.getBiggestValue(threshold);
        if (lowestValue <= min || biggestValue > max) {
          erroredThreshold.isRangeOverflow = true;
        }
      }
      if (!this.tempExt.middlePosition || !this.tempExt.bottomPosition) {
        erroredThreshold.isPositionError = true;
      }
      return erroredThreshold;
    }

    /**
     * Check les seuils saisis
     */
    checkThresholds() {
      /* Vérification du seuil 1 */
      let erroredThreshold1: IThresholdError = this.checkSingleThreshold(1, this.tempExt.bottomThreshold);
      if (erroredThreshold1.isValueError || erroredThreshold1.isRangeError || erroredThreshold1.isRangeOverflow) {
        this.thresholdsErrors.push(erroredThreshold1);
      }

      if (this.isSecondThresholdActive) {
        let erroredThreshold2: IThresholdError;
        /* Vérification du seuil 2 */
        erroredThreshold2 = this.checkSingleThreshold(2, this.tempExt.topThreshold);

        /* Vérification des deux seuils */
        let lowestValueThreshold2 = this.getLowestValue(this.tempExt.topThreshold);
        let biggestValueThreshold1 = this.getBiggestValue(this.tempExt.bottomThreshold);
        /* Gestion cas inversion des seuils */
        if (this.tempExt.bottomThreshold.value >= this.tempExt.topThreshold.value) {
          erroredThreshold2.isInverted = true;
        }
        /* Gestion cas chevauchement des seuils */
        if (!erroredThreshold2.isInverted && biggestValueThreshold1 > lowestValueThreshold2) {
          erroredThreshold2.isOverlapping = true;
        }

        if (!this.tempExt.topPosition || !this.tempExt.middlePosition || !this.tempExt.bottomPosition) {
          erroredThreshold2.isPositionError = true;
        }

        if (erroredThreshold2.isRangeError || erroredThreshold2.isValueError || erroredThreshold2.isRangeOverflow
          || erroredThreshold2.isOverlapping || erroredThreshold2.isInverted || erroredThreshold2.isPositionError) {
          this.thresholdsErrors.push(erroredThreshold2);
        }
      }
    }

    /**
     * Synchronise la configuration avec la vanne
     */
    sync() {
      if (!this.configChanged) {
        return;
      }

      if (this.tempExt.markedAsConnected) {
        this.checkThresholds();
      }

      if (this.thresholdsErrors.length > 0) {
        return this.$ionicPopup
          .show({
            title: 'Résultat de l\'action :',
            templateUrl: 'app/vanne/temperature/vanne-temperature.error.html',
            scope: this.$scope,
            buttons: [{
              text: 'OK',
              type: 'button-assertive',
            }]
          })
          .finally(() => {
            this.thresholdsErrors = [];
          });
      }

      if (!this.isSecondThresholdActive) {
        /* Passage de la valeur du seuil 2 à -30 pour indiquer désactivé */
        this.tempExt.topThreshold.value = this.VANNE_CONSTS.minTemp;
      }

      this.vanne
        .saveTempExt(this.tempExt)
        .then(savedTemp => this.initValues(savedTemp))
        .then(() => this.vanne.getState())
        .then(state => {
          if (state.defaults && state.defaults[1].length && state.defaults[1].includes(32)) {
            return this.$ionicPopup.alert({
              title: 'Erreur',
              template: 'Le capteur externe est mal branché ou défaillant',
              okType: 'button-assertive'
            });
          } else {
            return this.$ionicPopup.alert({
              title: 'Paramètres enregistrés',
              template: 'Les paramètres du capteur externe de température ont bien été enregistrés'
            });
          }
        });
    }
  }

  angular
    .module('eValve.vanne')
    .controller('VanneTemperatureController', VanneTemperatureController);
}
