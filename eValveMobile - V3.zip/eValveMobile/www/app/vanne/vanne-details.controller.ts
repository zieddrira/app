namespace eValve.vanne {
  'use strict';

  export class VanneDetailsController {
    details: IValve;
    vanneErrors: Array<{ [id: string]: string }>;

    static $inject: Array<string> = ['$scope', 'vanne', 'protocol', '$q', '$log', '$stateParams', 'VANNE_CONSTS'];
    constructor(
      private $scope: ng.IScope,
      private vanne: IVanne,
      private protocol: eValve.communication.IProtocol,
      private $q: ng.IQService,
      private $log: ng.ILogService,
      private $stateParams: ng.ui.IStateParamsService,
      private VANNE_CONSTS: any
    ) {
      this.vanneErrors = this.VANNE_CONSTS.vanneErrors;

      this.$scope.$on('$ionicView.beforeEnter', () => {
        this.vanne.selectedValveSerial = $stateParams['valveSerial'];
        this.details = <IValve>{};

        /* Récupération de l'état puis de la config pour le k */
        this.sync()
          .then(() => this.vanne.getConfig())
          .then((details: IValve) => {
            this.details = details;
          });
      });
    }

    get parsedInitiator() { return this.vanne.getLabelForInitiator(); }
    get parsedPosition() { return this.vanne.getLabelForPosition(); }

    get isTempExternSensorOk(): boolean | undefined {
      if (!this.details) {
        return;
      }

      return this.vanne.isSelectedValveTempExternSensorOk(this.details);
    }

    /**
     * Requête l'état auprès de la vanne, met à jour la bdd et le retourne
     * @returns {Promise} Promise de l'état sauvé en bdd
     */
    sync(): ng.IPromise<void> {
      return this.vanne
        .getState()
        .then((details: IValve) => {
          this.details = details;
        })
        .catch(error => {
          // TODO
        });
    }

  }

  angular
    .module('eValve.vanne')
    .controller('VanneDetailsController', VanneDetailsController);
}
