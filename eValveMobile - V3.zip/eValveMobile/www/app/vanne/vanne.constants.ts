namespace eValve.vanne {
  'use strict';

  const VANNE_CONSTS = {
    progUnits: {
      tempo: {
        'minutes': { code: 0x00, unit: 'minutes' },
        'hours': { code: 0x01, unit: 'heures' },
        'days': { code: 0x02, unit: 'jours' }
      },
      inhibition: {
        'minutes': { code: 0x00, unit: 'minutes' },
        'hours': { code: 0x10, unit: 'heures' },
        'days': { code: 0x20, unit: 'jours' },
        'months': { code: 0x30, unit: 'mois' },
        'years': { code: 0x40, unit: 'années' }
      }
    },

    minTemp: -30,

    purgePositions: {
      'open': { code: 0x00, value: 'Ouverte' },
      'limited': { code: 0x80, value: 'Débit limité' }
    },

    positionInitiators: [
      { code: 0x00, label: 'Action directe locale' },
      { code: 0x10, label: 'Action directe distante' },
      { code: 0x20, label: 'Début de purge manuelle locale' },
      { code: 0x30, label: 'Début de purge manuelle distante' },
      { code: 0x40, label: 'Début de purge programmée' },
      { code: 0x50, label: 'Fin de purge (volume)' },
      { code: 0x60, label: 'Fin de purge (tempo)' },
      { code: 0x70, label: 'Fin de purge (défaut)' },
      { code: 0x80, label: 'Maintenance auto' },
      { code: 0x90, label: 'Maintenance périphérique' },
      { code: 0xA0, label: 'Actionnement capteur 1' },
      { code: 0xB0, label: 'Actionnement capteur 2' },
      { code: 0xC0, label: 'Actionnement capteur 3' },
      { code: 0xD0, label: 'Actionnement capteur 4' }
    ],

    maintenanceFreqs: [
      { code: 0x00, label: 'Désactivée' },
      { code: 0x1C, label: '1x/semaine' },
      { code: 0x54, label: '1x/3semaines' },
      { code: 0xFC, label: '1x/9semaines' }
    ],

    EOFActions: [
      { code: 0x00, label: 'Maintien en position' },
      { code: 0x01, label: 'Ouverture' },
      { code: 0x02, label: 'Fermeture' },
      { code: 0x03, label: 'Débit limité' }
    ],

    k: [
      { code: 0x00, value: 1 },
      { code: 0x01, value: 2.5 },
      { code: 0x02, value: 10 },
      { code: 0x04, value: 100 },
      { code: 0x08, value: 1000 }
    ],

    vanneErrors: [
      {
        0x01: 'Erreur magnétique, 2 capteurs à effet Hall sont activés en même temps',
        0x02: 'Pas de capteur à effet Hall activé',
        0x04: 'Couple faible',
        0x08: 'Couple fort',
        0x10: 'Couple de blocage',
        0x20: 'Position ouverte après action aveugle',
        0x40: 'Position fermée après action aveugle',
        0x60: 'Débit limité après action aveugle',
        0x80: 'Timeout de l\'action dépassé (25 s.)'
      },
      {
        0x01: 'Coupure câble vanne-cyble',
        0x02: 'Sens écoulement inverse',
        0x04: 'Débit nul',
        0x08: 'Erreur lors de l\'advertising',
        0x10: 'Action non conforme',
        0x20: 'Erreur sur le capteur de température externe'
      }
    ]
  };

  angular
    .module('eValve.vanne')
    .constant('VANNE_CONSTS', VANNE_CONSTS);
}
