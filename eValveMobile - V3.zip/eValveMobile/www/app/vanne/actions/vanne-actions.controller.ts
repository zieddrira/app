namespace eValve.vanne {
  'use strict';

  export class VanneActionsController {
    details: IValve;
    purgePositions: { [id: string]: { code: number, value: string } };
    selectedAction: number = null;
    stringPurgePosition: string;
    stringTempoUnit: string;
    tempoUnits: { [id: string]: { code: number, unit: string } };
    updating: boolean;
    vanneErrors: Array<{ [id: string]: string }>;
    actionError: boolean = false;
    errorParametragePurge: boolean = false;
    errorActionPurgeVanneOuverte: boolean = false;
    errorActionPurgeVanneDebitLimite: boolean = false;

    actions = {
      open: {
        value: 0x01,
        label: 'Ouvrir'
      },
      limit: {
        value: 0x03,
        label: 'Débit limité'
      },
      close: {
        value: 0x02,
        label: 'Fermer'
      },
      purge: {
        value: 0x05,
        label: 'Purger'
      },
      maintain: {
        value: 0x04,
        label: 'Maintenance'
      },
      sleep: {
        value: 0x00,
        label: 'Mode stockage'
      }
    };

    purgeParams: IPurgeManual & { unit: number } = {
      volume: 1000,
      position: 0x00,
      tempo: 60,
      unit: 0x00
    };

    static $inject: Array<string> = ['$scope', 'vanne', '$ionicPopup', '$log', 'VANNE_CONSTS'];
    constructor(
      private $scope: ng.IScope,
      private vanne: IVanne,
      private $ionicPopup: ionic.popup.IonicPopupService,
      private $log: ng.ILogService,
      private VANNE_CONSTS: any
    ) {
      this.tempoUnits = this.VANNE_CONSTS.progUnits.tempo;
      this.purgePositions = this.VANNE_CONSTS.purgePositions;
      this.vanneErrors = this.VANNE_CONSTS.vanneErrors;

      this.$scope.$on('$ionicView.beforeEnter', () => {
        this.vanne
          .getVanneDetails()
          .then((details: IValve) => {
            this.details = details;
          });

        this.vanne
          .getManualPurge()
          .then((purge: IPurgeManual & { unit: number }) => {
            this.purgeParams = purge;
            this.stringPurgePosition = purge.position.toString();
            this.stringTempoUnit = purge.unit.toString();
          })
          .catch(error => {
            this.$ionicPopup.alert({
              okType: 'button-assertive',
              template: 'Les paramètres de purge manuelle n\'ont pas pu être récupérés',
              title: 'Une erreur est survenue'
            });
          });
      });
    }

    get parsedPosition() { return this.vanne.getLabelForPosition(); }

    sync() {
      if (this.selectedAction == null) {
        return;
      }

      this.updating = true;

      /* Cas de la sélection de la purge avec volume ou temps à 0 */
      if (this.selectedAction === this.actions.purge.value && (!this.purgeParams.volume
        || !this.purgeParams.tempo || this.purgeParams.volume === 0 || this.purgeParams.tempo === 0)) {
        this.actionError = true;
        this.errorParametragePurge = true;
      }

      /* Cas d'une action purge sur une vanne non-fermée */
      /* Attention : On se base sur l'état de la vanne dans l'application;
         il peut arriver des cas où les capteurs de la vanne ne fonctionnent pas correctement (aimant)
         et donc la position de la vanne réelle peut-être différente de la position de la vanne dans l'application.
       */
      if (this.selectedAction === this.actions.purge.value) {
        let positions = ['Ouverte', 'Fermée', 'Débit limité'];

        switch (this.parsedPosition) {
          case positions[0]:
            this.actionError = true;
            this.errorActionPurgeVanneOuverte = true;
            break;
          case positions[2]:
            this.actionError = true;
            this.errorActionPurgeVanneDebitLimite = true;
            break;
          default: ;
        }
      }

      /* Gestion des erreurs */
      if (this.actionError) {
        this.$ionicPopup.show({
          title: 'Résultat de l\'action :',
          templateUrl: 'app/vanne/actions/vanne-actions.error.html',
          scope: this.$scope,
          buttons: [{
            text: 'OK',
            type: 'button-assertive',
          }]
        })
          .finally(() => {
            this.actionError = false;
            this.errorParametragePurge = false;
            this.errorActionPurgeVanneOuverte = false;
            this.errorActionPurgeVanneDebitLimite = false;
          });

        this.updating = false;
        this.selectedAction = null;
      } else {
        this.vanne
          .sendAction(this.selectedAction, this.purgeParams)
          .then(result => {
            this.details.rawDefault = this.vanne.arrayToNumber(result);
            this.details.defaults = this.vanne.parseVanneErrors(this.details.rawDefault);

            this.$ionicPopup.show({
              title: 'Résultat de l\'action :',
              templateUrl: 'app/vanne/actions/vanne-actions.result.html',
              scope: this.$scope,
              buttons: [{
                text: 'OK',
                type: this.details.defaults ? 'button-assertive' : 'button-positive',
              }]
            });

            // /* L'action s'est bien déroulée */
            // if ((result[1] & 0x10) == 0) {
            //   if (this.selectedAction == 0) {
            //     this.details.storageMode = true;
            //   } else if (this.selectedAction <= 0x03) {
            //     this.details.position = this.selectedAction;
            //   } else if (this.selectedAction == 0x05) {
            //     this.details.position = (this.purgeParams.position & 0x80) ? 0x03 : 0x01;
            //   }
            // } else if (result[1] & 0x01 || (this.selectedAction == 0x05 && (/*(result[1] & 0x02) || */(result[1] & 0x04)))) {
            //   /* Si coupure cable vanne-cyble ou purge et compteur à l'envers / débit nul */
            //   this.details.position = 0x02;
            // }
          })
          .then(() => {
            return this.vanne.getState();
            /* On sauvegarde la nouvelle position de la vanne */
            // return vanne.save(this.details);
          })
          .then((result: IValve) => {
            this.details = result;
            // $log.info("Action saved");
            // this.details._rev = result.rev; // Met à jour avec les metadatas de la bdd (notamment numéro de révision)
          })
          .catch(error => {
            // TODO ?
          })

          .finally(() => {
            this.updating = false;
            this.selectedAction = null;
          });
      }
    }
  }

  angular
    .module('eValve.vanne')
    .controller('VanneActionsController', VanneActionsController);
}
