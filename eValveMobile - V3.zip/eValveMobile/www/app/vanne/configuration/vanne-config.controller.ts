namespace eValve.vanne {
  'use strict';

  export class VanneConfigController {
    private _configWatch: Function;
    private _parsedStartDate: Date;
    private _displayedSection: number;
    private _originalConfig: IValve;

    actions: Array<{ code: number, label: string }>;
    configChanged: boolean;
    details: IValve;
    functions = ['Maintenance', 'Purges', 'Capteurs', 'Communication'];
    k: Array<{ code: number, value: number }>;
    maintenanceFrequencies: Array<{ code: number, label: string }>;
    validActivationCode: boolean;
    validSerial: boolean;

    static $inject: Array<string> = ['vanne', '$scope', '$log', 'VANNE_CONSTS', '$ionicPopup',
      '$ionicScrollDelegate', 'park', '$q', '$stateParams'];
    constructor(
      private vanne: IVanne,
      private $scope: ng.IScope,
      private $log: ng.ILogService,
      private VANNE_CONSTS: any,
      private $ionicPopup: ionic.popup.IonicPopupService,
      private $ionicScrollDelegate: ionic.scroll.IonicScrollDelegate,
      private park: eValve.park.IParkService,
      private $q: ng.IQService,
      private $stateParams: ng.ui.IStateParamsService
    ) {
      this.actions = VANNE_CONSTS.EOFActions;
      this.maintenanceFrequencies = VANNE_CONSTS.maintenanceFreqs;
      this.k = VANNE_CONSTS.k;

      $scope.$on('$ionicView.beforeEnter', () => this.getConfig());
    }

    get parsedStartDate() { return this._parsedStartDate; }
    set parsedStartDate(date) {
      this.configChanged = this.configChanged
        || date.getTime() != new Date(this.details.maintenance.startDate).getTime()
        ? true : false;
      this._parsedStartDate = date;
    }

    /**
     * Récupère la config de la vanne depuis la bdd
     */
    getConfig() {
      this.vanne
        .getConfig()
        .then((vanne: IValve) => this.initVm(vanne));
    }

    /**
     * Détermine la section dont les infos sont affichées dans la vue
     * @param {Number} id - Id de la section
     */
    toggleParamSection(id: number) {
      if (this.isSectionDisplayed(id)) {
        this._displayedSection = null;
      } else {
        this._displayedSection = id;
      }
    }

    /**
     * Indique si la section en paramètre est sélectionnée
     * @param {Number} id
     * @returns {Boolean}
     */
    isSectionDisplayed(id: number): boolean {
      setTimeout(() => this.$ionicScrollDelegate.resize(), 100);
      return this._displayedSection === id;
    }

    /**
     * Synchronise la configuration avec la vanne
     */
    sync() {
      if (!this.configChanged) {
        return;
      }

      this.details.maintenance.startDate = this.parsedStartDate.getTime();
      this.vanne
        .saveConfig(this.details)
        .then((details: IValve) => {
          let codePromise = this.$q.resolve(details);

          if (this._originalConfig.connectionCode != details.connectionCode) {
            /* Si le code de connexion a changé on modifie l'entrée spécifique dans la BDD */
            codePromise = this.park
              .saveConnectionCode(details.serialNumber, details.connectionCode)
              .catch(error => this.$log.error(error))
              .then(() => details);
          }

          return codePromise;
        })
        .then((details: IValve) => this.initVm(details))
        .catch(error => this.$log.error(error));
    }

    /**
     * Initialise le vm et les valeurs parsées
     * @param {IValve} details - Détails de la vanne
     */
    initVm(details: IValve) {
      if (Object.keys(details).length == 0 || !details.maintenance) {
        this.$ionicPopup.alert({
          title: 'Pas de paramètres',
          template: 'Les paramètres de la vanne n\'ont jamais été récupérés.'
        });

        return;
      };

      this.validSerial = false;
      for (let i = 0; i < details.serialNumber.length; i++) {
        if (parseInt(details.serialNumber[i]) != 0) {
          this.validSerial = true;
          break;
        }
      }

      this.validActivationCode = details.connectionCode[0] != '0' ? true : false;

      this.details = angular.copy(details);
      this.parsedStartDate = (this.details.maintenance.startDate && new Date(this.details.maintenance.startDate)) || new Date();

      /* Reset le watch qui vérifie si la config a changé */
      this._configWatch && this._configWatch();

      this._originalConfig = angular.copy(this.details);
      this._configWatch = this.$scope.$watch(() => { return this.details; }, (newVal: IValve) => {
        this.configChanged = !angular.equals(newVal, this._originalConfig);
      }, true);
    }

  }

  angular
    .module('eValve.vanne')
    .controller('VanneConfigController', VanneConfigController);
}
