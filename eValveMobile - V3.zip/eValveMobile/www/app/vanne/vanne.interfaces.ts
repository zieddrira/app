namespace eValve.vanne {
  'use strict';

  export enum PurgeFrequency { Weekly, Monthly }
  export enum deviceFunction { eValve }

  export interface IPurge {
    position: number;
    tempo: number;
    volume: number;
  }

  export interface IPurgeAuto extends IPurge {
    activeFrequency: PurgeFrequency;
    isActive: boolean;
    parsedStartDate?: Date;
    startDate: number;
  }

  export interface IPurgeManual extends IPurge {
    _rev?: string;
  }

  export interface IPurgeCheck extends IPurge {
    _rev?: string;
    id?: number;
    isActive?: boolean;
    parsedStartDate?: Date;
  }

  export interface IPurgeInhibition {
    active: boolean;
    value: number;
  }

  export interface IPurgeUnits {
    _rev?: string;
    inhibition: number;
    tempo: number;
  }

  export interface IValveProgram {
    _rev?: string;
    auto: IPurgeAuto[];
    id?: number;
    inhibitions: { auto: IPurgeInhibition, manual: IPurgeInhibition, sensor: IPurgeInhibition };
    manual: IPurgeManual;
    programmer?: string;
    units: IPurgeUnits;
  }

  export interface IValveState {
    action: number;
    battery: number;
    currentIndex: number;
    defaults: any[];
    position: number;
    rawDefault: number;
    serialNumber: string;
    storageMode: boolean;
    temperature: number;
    tension: number;
    sensor1: number;
  }

  export interface IValveConfig {
    connectionCode: string;
    endOfLife: {
      action: number,
      functionStates: [boolean, boolean, boolean, boolean]
    };
    hardware: string;
    initialIndex: number;
    k: number;
    maintenance: { frequency: number, startDate: number };
    serialNumber: string;
    software: string;
    timeMaxOffset: number;
  }

  export interface IValveGeoloc {
    altitude: string;
    comments: string;
    deviceFunction: deviceFunction;
    installationDate: number;
    latitude: string;
    longitude: string;
    meterSerial: string;

    city: string;
    street: string;
    streetNumber: string;
    zipCode: string;

    _id?: string;
    _rev?: string;
  }

  export interface IValveTempExt {
    _rev?: string;

    markedAsConnected: boolean;
    bottomPosition: number;
    middlePosition: number;
    topPosition: number;
    bottomThreshold: IThreshold;
    topThreshold: IThreshold;
    failureAction: number;
    failureCountdown?: number;
  }

  export interface IValve extends IValveState, IValveConfig {
    _rev?: string;
    protocolVersion?: number;
    // macAddress?: string;
  }

  export interface IValveInit {
    _rev?: string;
    macAddress: string;
    serialNumber: string;
  }

  export interface IThreshold {
    value: number;
    range: number;
  }

  export interface IThresholdError extends IThreshold {
    id: number;
    isValueError?: boolean;
    isRangeError?: boolean;
    isRangeOverflow?: boolean;
    isInverted?: boolean;
    isOverlapping?: boolean;
    isPositionError?: boolean;
  }

  export interface ICourbes {
    one: { desc: boolean, asc: boolean };
    two: { desc: boolean, asc: boolean };
    mixed: boolean;
  }

  interface IBaseStats {
    lastDuration: number;
    meanDuration: number;
    nbKo: number;
    nbOk: number;
  }

  export interface IValveStats {
    _rev?: string;
    closing: IBaseStats & { totalDuration: number };
    lastActionResult: number;
    limited: IBaseStats & { meanFlowRate: number, totalDuration: number };
    maintenance: IBaseStats;
    messages: { nbBadFrames: number, nbMessages: number };
    opening: IBaseStats & { meanFlowRate: number, totalDuration: number };
    parsedLastActionResult?: string;
    purges: {
      lastStop: number,
      lastVolume: number,
      meanVolume: number,
      nbCountdown: number,
      nbLimited: number
      nbOpened: number,
      nbTempo: number,
      timeSinceLast: number,
      totalDuration: number,
      totalVolume: number,
    };
    system: {
      ledDuration: number,
      lastUpgrade: { date: number, user: string, parsedDate?: string },
      motor: { totalDuration: number, nbActuation: number }
      nbProgUpgrades: number,
      nbReset: number,
    };
    timeSinceAction: number;
    sensors: {
      limitedVolumeDueToSensor1: number;
      openedVolumeDueToSensor1: number;
    };
  }

  export enum HistoryType { Synchronous, Asynchronous }

  export interface IHistorySyncElement {
    action: number;
    battery: number;
    captors: [number, number, number, number];
    defaults: any[];
    frameType: HistoryType;
    index: number;
    position: number;
    prog: number;
    rawDefault: number;
    storage: boolean;
    temperature: number;
    tension: number;
    timestamp: number;
    sensor1: number;
  }

  export interface IHistoryAsyncElement {
    action: number;
    defaults: any[];
    frameType: HistoryType;
    index: number;
    overlap: number;
    position: number;
    rawDefault: number;
    storage: boolean;
    timestamp: number;
  }

  export interface IHistoryComputedElement {
    detailedVolumes: { 0x01: number, 0x02: number, 0x03: number };
    timestamp: number;
    totalVolume: number;
  }

  export type IDailyComputedElement = (IHistorySyncElement | IHistoryAsyncElement) & { volumeDueToSensor1: number };
  export type IFullHistory = IDailyComputedElement[] | IHistoryComputedElement[];
}
