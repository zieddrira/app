namespace eValve.vanne {
  'use strict';

  export class VanneController {
    connectedValveSerial: string;
    selectedValveSerial: string;

    static $inject: Array<string> = ['vanne', '$scope'];
    constructor(
      private vanne: IVanne,
      private $scope: ng.IScope
    ) {
      $scope.$watch(() => { return this.vanne.selectedValveSerial; }, (newVal: string) => {
        this.selectedValveSerial = newVal;
      });

      $scope.$watch(() => { return this.vanne.connectedValveSerial; }, (newVal: string) => {
        this.connectedValveSerial = newVal;
      });
    }
  }

  angular
    .module('eValve.vanne')
    .controller('VanneController', VanneController);
}
