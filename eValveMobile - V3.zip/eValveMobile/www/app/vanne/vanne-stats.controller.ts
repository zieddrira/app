namespace eValve.vanne {
  'use strict';

  export class VanneStatsController {
    private _displayedSection: number;
    private _displayedSubSection: number;
    private _purgeStops = {
      0x01: 'Volume',
      0x02: 'Temporisation',
      0x03: 'Action manuelle',
      0x04: 'Coupure câble',
      0x05: 'Débit nul',
      0x06: 'Compteur à l\'envers',
      0xFF: 'Défaut autre'
    };

    sections = {
      messages: {
        title: 'Communication',
        values: {
          nbBadFrames: 'Mauvaises trames',
          nbMessages: 'Messages reçus',
          // nbBadFramesRadio: 'Messages radio non conformes',
          // nbMessagesRadio: 'Messages radio'
        }
      },
      maintenance: {
        title: 'Maintenance',
        values: {
          nbOk: 'Maintenances OK',
          nbKo: 'Maintenances KO',
          lastDuration: 'Dernière durée (s)',
          meanDuration: 'Durée moyenne (s)'
        }
      },
      opening: {
        title: 'Ouverture',
        values: {
          nbOk: 'Ouvertures OK',
          nbKo: 'Ouvertures KO',
          lastDuration: 'Dernière durée (s)',
          meanDuration: 'Durée moyenne (s)',
          totalDuration: 'Durée cumulée (min)',
          meanFlowRate: 'Débit moyen (l/h)'
        }
      },
      closing: {
        title: 'Fermeture',
        values: {
          nbOk: 'Fermetures OK',
          nbKo: 'Fermetures KO',
          lastDuration: 'Dernière durée (s)',
          meanDuration: 'Durée moyenne (s)',
          totalDuration: 'Durée cumulée (min)',
        }
      },
      limited: {
        title: 'Débit limité',
        values: {
          nbOk: 'Débit limité OK',
          nbKo: 'Débit limité KO',
          lastDuration: 'Dernière durée (s)',
          meanDuration: 'Durée moyenne (s)',
          totalDuration: 'Durée cumulée (min)',
          meanFlowRate: 'Débit moyen (l/h)'
        }
      },
      purges: {
        title: 'Purges',
        values: {
          totalVolume: 'Volume total purgé (m3)',
          meanVolume: 'Volume moyen (L)',
          lastVolume: 'Volume dernière (L)',
          nbCountdown: 'Arrêts par décompte',
          nbTempo: 'Arrêts par tempo.',
          lastStop: 'Raison dernier arrêt',
          timeSinceLast: 'Temps depuis dernière purge (min)',
          totalDuration: 'Temps total de purges (h)',
          nbOpened: 'Purges en position ouverte',
          nbLimited: 'Purges en débit limité'
        }
      },
      system: {
        title: 'Système',
        values: {
          nbReset: 'Nombre de resets',
          ledDuration: 'Durée allumage LED (min)',
          nbProgUpgrades: 'Upgrades programmes',
          lastUpgrade: {
            title: 'Dernier upgrade',
            values: {
              parsedDate: 'Date',
              user: 'Utilisateur'
            }
          },
          motor: {
            title: 'Moteur',
            values: {
              totalDuration: 'Durée actionnement (s)',
              nbActuation: 'Actionnements'
            }
          },
          // version: 'Version soft vanne'
        }
      }
    };

    stats: IValveStats;

    static $inject: Array<string> = ['vanne', '$scope', '$ionicPopup', '$ionicScrollDelegate'];
    constructor(
      private vanne: IVanne,
      private $scope: ng.IScope,
      private $ionicPopup: ionic.popup.IonicPopupService,
      private $ionicScrollDelegate: ionic.scroll.IonicScrollDelegate
    ) {
      $scope.$on('$ionicView.beforeEnter', () => {
        this.stats = null;

        if (this.vanne.selectedValveProtocolVersion == 1) {
          Object.assign(this.sections, {
            sensors: {
              title: 'Capteurs externes',
              values: {
                limitedVolumeDueToSensor1: 'Volume total DL capteur 1 (m3)',
                openedVolumeDueToSensor1: 'Volume total ouvert capteur 1 (m3)'
              }
            }
          });
        }

        this.sync();
      });
    }

    /**
     * Force le refresh des stats à partir de la vanne (si connectée)
     */
    sync() {
      this.vanne
        .getStats(null, true)
        .then((stats: IValveStats) => this.initVm(stats));
    }

    /**
     * Initialise le vm et les valeurs parsées
     * @param {IValveStats} stats - Statistiques de la vanne
     */
    initVm(stats: IValveStats) {
      if (Object.keys(stats).length == 0) {
        this.$ionicPopup.alert({
          title: 'Pas de statistiques',
          template: 'Aucune statistique n\'a été récupérée sur la vanne.'
        });

        return;
      };

      if (stats.system.lastUpgrade.date) {
        let d = new Date(stats.system.lastUpgrade.date);
        stats.system.lastUpgrade.parsedDate =
          ('0' + d.getDate()).slice(-2) + '/' + ('0' + (d.getMonth() + 1)).slice(-2) + '/' + d.getFullYear();
      }
      stats.purges.lastStop = this._purgeStops[stats.purges.lastStop];
      stats.parsedLastActionResult = ['Terminée', 'En cours', 'Echec'][stats.lastActionResult];

      this.stats = stats;
    }

    /**
     * Détermine la section dont les stats sont affichées dans la vue
     * @param {number} id - Id de la section
     * @param {Boolean} isSubSection - true si sous-section
     */
    toggleStatSection(id: number, isSubSection: boolean) {
      if (this.isSectionDisplayed(id, isSubSection)) {
        isSubSection ? this._displayedSubSection = null : this._displayedSection = null;
      } else {
        isSubSection ? this._displayedSubSection = id : this._displayedSection = id;
      }
    }

    /**
     * Indique si la section en paramètre est sélectionnée
     * @param {number} id
     * @param {Boolean} isSubSection - true si sous-section
     * @returns {Boolean}
     */
    isSectionDisplayed(id: number, isSubSection: boolean): boolean {
      setTimeout(() => this.$ionicScrollDelegate.resize(), 100);
      return (isSubSection ? this._displayedSubSection === id : this._displayedSection === id);
    }

    /**
     * Indique si la valeur testée est un objet, et donc une section de stats
     * @param {Object} value
     * @returns {Boolean}
     */
    isSubSection(value): boolean {
      return angular.isObject(value);
    }

  }

  angular
    .module('eValve.vanne')
    .controller('VanneStatsController', VanneStatsController);
}
