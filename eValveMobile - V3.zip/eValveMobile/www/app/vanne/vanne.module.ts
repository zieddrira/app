namespace eValve.vanne {
  'use strict';

  angular
    .module('eValve.vanne', [])
    .run(initModule);

  initModule.$inject = ['routerHelper'];
  function initModule(routerHelper) {
    routerHelper.configureStates(getStates());
  }

  function getStates() {
    return [
      {
        /* Initialisation du code de connexion et du numéro de série */
        state: 'initVanne',
        config: {
          cache: false,
          url: '/vanne/init',
          views: {
            '': {
              templateUrl: 'app/vanne/init-vanne.html',
              controller: 'InitVanneController as vm'
            }
          }
        }
      },
      {
        /* First Tabs */
        state: 'vanne',
        config: {
          asbtract: true,
          cache: false,
          url: '/vanne/{valveSerial}',
          views: {
            '': {
              templateUrl: 'app/vanne/vanne.html',
              controller: 'VanneController as vanne'
            }
          }
        }
      },
      {
        /* Détails */
        state: 'vanne.details',
        config: {
          url: '/details',
          views: {
            'vanne-details': {
              templateUrl: 'app/vanne/vanne-details.html',
              controller: 'VanneDetailsController as vm'
            }
          }
        }
      },
      {
        /* Actions */
        state: 'vanne.actions',
        config: {
          url: '/actions',
          views: {
            'vanne-actions': {
              templateUrl: 'app/vanne/actions/vanne-actions.html',
              controller: 'VanneActionsController as vm'
            }
          }
        }
      },
      {
        /* Historique */
        state: 'vanne.history',
        config: {
          url: '/history',
          cache: false,
          views: {
            'vanne-history': {
              templateUrl: 'app/vanne/history/vanne-history.html',
              controller: 'HistoryController as vm'
            }
          }
        }
      },
      {
        /* Purge */
        state: 'vanne.purges',
        config: {
          url: '/purges',
          views: {
            'vanne-purges': {
              templateUrl: 'app/vanne/purges/vanne-purges.html',
              controller: 'VannePurgesController as vm'
            }
          }
        }
      },
      {
        /* Statistiques */
        state: 'vanne.stats',
        config: {
          url: '/stats',
          views: {
            'vanne-stats': {
              templateUrl: 'app/vanne/vanne-stats.html',
              controller: 'VanneStatsController as vm'
            }
          }
        }
      },
      {
        /* Second Tabs */
        state: 'vanneConfig',
        config: {
          asbtract: true,
          cache: false,
          url: '/vanne/{valveSerial}',
          views: {
            '': {
              templateUrl: 'app/vanne/vanne-tabs.html',
              controller: 'VanneController as vanne'
            }
          }
        }
      },
      {
        /* Configuration Système */
        state: 'vanneConfig.config',
        config: {
          url: '/config',
          views: {
            'vanne-config': {
              templateUrl: 'app/vanne/configuration/vanne-config.html',
              controller: 'VanneConfigController as vm'
            }
          }
        }
      },
      {
        /* Configuration seuils de température */
        state: 'vanneConfig.temperature',
        config: {
          url: '/temperature',
          views: {
            'vanne-temperature': {
              templateUrl: 'app/vanne/temperature/vanne-temperature.html',
              controller: 'VanneTemperatureController as vm'
            }
          }
        }
      },
    ];
  }
}
