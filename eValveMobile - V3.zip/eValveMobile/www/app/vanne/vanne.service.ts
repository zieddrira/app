namespace eValve.vanne {
  'use strict';

  interface IHistoryParams {
    beginDate: number;
    endDate: number;
    granularity: number;
    theoricalEndDate: number;
    requestedDate?: number;
  }

  export interface IAccessedCharacteristics {
    config: boolean;
    details: boolean;
    geoloc: boolean;
    history: boolean;
    prog: boolean;
    stats: boolean;
    tempExt: boolean;
  };

  export interface IVanne {
    accessedCharacteristics: IAccessedCharacteristics;
    connectedValveProtocolVersion: number;
    connectedValveSerial: string;
    selectedValveProtocolVersion: number;
    selectedValveSerial: string;

    arrayToNumber(array: Array<number>): number;
    connect(deviceId: string, connectionCode?: string, retry?: number): ng.IPromise<any>;
    disconnect(sameTarget?: boolean): ng.IPromise<any>;
    getAll(): ng.IPromise<string[]>;
    getLabelForInitiator(value?: number): string;
    getLabelForPosition(value?: number): string;
    getConfig(id?: string): ng.IPromise<IValve>;
    getGeoloc(id?: string, forceRefresh?: boolean): ng.IPromise<IValveGeoloc>;
    getHistory(date: Date, granularity: number, id?: string
    ): ng.IPromise<(IHistorySyncElement | IHistoryAsyncElement)[] | IHistoryComputedElement[] | void>;
    getManualPurge(id?: string, retry?: number): ng.IPromise<IPurgeManual & { unit: number }>;
    getProg(id?: string): ng.IPromise<IValveProgram>;
    getState(id?: string): ng.IPromise<IValve>;
    getStats(id?: string, forceRefresh?: boolean): ng.IPromise<IValveStats>;
    getTempExt(serialNumber?: string, forceRefresh?: boolean): ng.IPromise<IValveTempExt>;
    getVanneDetails(serialNumber?: string): ng.IPromise<IValve>;
    initAccessedCharacteristics(): IAccessedCharacteristics;
    initValve(serialNumber: string, connectionCode: string, initialIndex: number, k: string): ng.IPromise<IValveConfig>;
    isSelectedValveTempExternSensorOk(data: { defaults: any[]; sensor1: number; }): boolean | undefined;
    parseVanneErrors(rawErrors: number): any[][];
    saveConfig(details: IValveConfig, id?: string): ng.IPromise<IValve>;
    saveGeoloc(geoloc: IValveGeoloc, id?: string): ng.IPromise<IValveGeoloc>;
    saveProg(prog: IValveProgram, id?: string): ng.IPromise<IValveProgram>;
    saveTempExt(tempExt: IValveTempExt, serialNumber?: string): ng.IPromise<IValveTempExt>;
    sendAction(value: number, purge?: IPurgeManual & { unit: number }): ng.IPromise<any>;
    setTime(timestamp: number): ng.IPromise<{}>;
  }

  export class Vanne implements IVanne {
    private _connectedDeviceId: string;
    // private _connectedValveProtocolVersion: number;
    private _connectedValveSerial: string;
    private _selectedValveProtocolVersion: number;
    private _selectedValveSerial: string;

    private _vanneData: {
      details?: IValve,
      geoloc?: IValveGeoloc,
      prog?: IValveProgram,
      stats?: IValveStats,
      tempExt?: IValveTempExt
    } = {};

    accessedCharacteristics: IAccessedCharacteristics;

    static $inject: Array<string> = ['$rootScope', '$state', 'db', 'utils', '$q', '$log', 'protocol',
      '$ionicPopup', 'VANNE_CONSTS', 'ERROR_CODES', 'park', '$timeout', '$ionicLoading'];
    constructor(
      private $rootScope: ng.IRootScopeService,
      private $state: ng.ui.IStateService,
      private db: eValve.core.IDb,
      private utils: eValve.core.IUtils,
      private $q: ng.IQService,
      private $log: ng.ILogService,
      private protocol: eValve.communication.IProtocol,
      private $ionicPopup: ionic.popup.IonicPopupService,
      private VANNE_CONSTS: any,
      private ERROR_CODES: eValve.communication.IErrors,
      private park: eValve.park.IParkService,
      private $timeout: ng.ITimeoutService,
      private $ionicLoading: ionic.loading.IonicLoadingService
    ) {
      this.initAccessedCharacteristics();

      this.$rootScope.$on('communication:reset', (event) => {
        event.stopPropagation();
        this.resetConnection();
      });
    }

    get selectedValveSerial() { return this._selectedValveSerial; }
    set selectedValveSerial(value) { this._selectedValveSerial = value; }

    get connectedValveSerial() { return this._connectedValveSerial; }
    set connectedValveSerial(value) { this._connectedValveSerial = value; }

    get connectedValveProtocolVersion() { return this.protocol.connectedValveProtocolVersion; }
    get selectedValveProtocolVersion() { return this._selectedValveProtocolVersion; }

    private get vanneData() { return angular.copy(this._vanneData); }

    /**
     * Envoie un timestamp à la vanne pour forcer la mise à jour de l'horloge
     * @param {Number} timestamp - Timestamp en secondes
     * @returns {Promise} Promise de la mise à jour réussie de l'horloge
     */
    setTime(timestamp: number): ng.IPromise<{}> {
      return this.protocol.sendCommand('TIME', [timestamp]);
    }

    /**
     * Retourne l'ensemble des vannes en mémoire
     * @returns {Promise} Promise du tableau des numéros de série des vannes
     */
    getAll(): ng.IPromise<string[]> {
      return this.db.getVannes();
    }

    /**
     * Récupère les caractéristiques détaillées d'une vanne
     * @param {String} [serialNumber] - Numéro de série de la vanne
     * @returns {Promise<IValve>} Promise des details
     */
    getVanneDetails(serialNumber?: string): ng.IPromise<IValve> {
      let deferred = this.$q.defer<IValve>();

      serialNumber = serialNumber || this.selectedValveSerial;
      if (this._vanneData.details && this._vanneData.details.serialNumber == serialNumber) {
        deferred.resolve(this._vanneData.details);
      } else {

        this.getVanneDoc(serialNumber)
          .then((details: IValve) => {
            this._vanneData.details = details;

            this.$log.info('Details gotten');
            deferred.resolve(details);
          })
          .catch(error => {
            this.$log.error(error);
            deferred.reject(error);
          });
      }

      return deferred.promise;
    }

    /**
     * Renvoie le label de la position de la vanne en fonction de sa valeur
     * @param {Number} [value] - Valeur de la position
     * @returns {String} position - Valeur littérale de la position
     */
    getLabelForPosition(value?: number): string {
      try {
        if (value == undefined) {
          value = this._vanneData.details.position;
        }

        let positions = ['Ouverte', 'Fermée', 'Débit limité'];
        return positions[value - 1];
      } catch (error) {
        // $log.error("Error while getting label for position");
        return null;
      }
    }

    /**
     * Renvoie le label de l'initiateur de la position de la vanne en fonction de sa valeur
     * @param {Number} [value] - Valeur de l'initiateur
     * @returns {String} label - Valeur littérale
     */
    getLabelForInitiator(value?: number): string {
      try {
        if (value == undefined) {
          value = this._vanneData.details.action;
        }

        let index = this.VANNE_CONSTS
          .positionInitiators
          .map(val => val.code)
          .indexOf(value);

        return this.VANNE_CONSTS.positionInitiators[index].label;
      } catch (error) {
        // $log.error("Error while getting label for initiator");
        return null;
      }
    }

    /**
     * Retourne la purge manuelle par défaut d'une vanne
     * @param {String} [serialNumber] - Numéro de série de la vanne
     * @param {Number} [retry] - S'incrémente en cas d'essais négatifs
     * @returns {Promise} Promise de la purge manuelle de la vanne
     */
    getManualPurge(serialNumber?: string, retry?: number): ng.IPromise<IPurgeManual & { unit: number }> {
      serialNumber = serialNumber || this.selectedValveSerial;
      retry = retry || 0;

      return this.$q
        .all([this.getVanneDoc(serialNumber, ['prog', 'manual']), this.getVanneDoc(serialNumber, ['prog', 'units'])])
        .then((results: [IPurgeManual, IPurgeUnits]) => {
          let params = <IPurgeManual & { unit: number }>results[0];
          params.unit = results[1].tempo;

          this.$log.debug('Manual purge: ' + JSON.stringify(params));
          /* Modification du volume et de la temp de la purge manuelle si elle vaut déjà 0 pour éviter un message d'erreur par défaut */
          if (params.volume === 0) {
            params.volume = 1;
          }
          if (params.tempo === 0x00) {
            params.tempo = 0x01;
          }

          return params;
        })

        .catch(error => {
          this.$log.error(error);
          if (++retry < 3 && error.status == 404) {
            /* Si les paramères n'existent pas en bdd, on récupère depuis la vanne */
            return this.getProg(serialNumber)
              .then(() => {
                return this.getManualPurge(serialNumber, retry);
              });
          }

          throw error;
        });
    }

    /**
     * Retourne l'état d'une vanne
     * @param {String} [serialNumber] - Numéro de série de la vanne
     * @returns {Promise<IValve>} Promise de l'état de la vanne
     */
    getState(serialNumber?: string): ng.IPromise<IValve> {
      serialNumber = serialNumber || this.selectedValveSerial;
      let deferred = this.$q.defer();

      /* On récupère l'état en bdd */
      this.getVanneDetails(serialNumber)
        .catch(error => {
          if (error.status == 404) {
            this.$log.info('La vanne n\'existe pas dans la base de données');
          }
        })

        .then((details: IValve | void) => {
          details = details || <IValve>{};

          if (this.connectedValveSerial && this.connectedValveSerial == serialNumber) {
            details.protocolVersion = this.connectedValveProtocolVersion;

            /* On récupère la version de la vanne */
            this.protocol
              .sendCommand('Q_ETAT', [], true)
              .then(rawFrame => {
                let dataView = this.protocol.rawToDataView('V_ETAT', rawFrame);

                let secondPart = dataView.getUint8(9);
                return <IValveState>{
                  serialNumber: String.fromCharCode.apply(this, (rawFrame.slice(2, 2 + 9))),
                  position: secondPart & 0x07,
                  storageMode: secondPart & 0x08 ? true : false,
                  action: secondPart & 0xF0,
                  rawDefault: this.numberFromBuffer(dataView.buffer, 10, 3),
                  defaults: this.parseVanneErrors(this.numberFromBuffer(dataView.buffer, 10, 3)),
                  currentIndex: dataView.getUint32(13, this.protocol.littleEndian),
                  battery: dataView.getUint8(23),

                  temperature: this.temperatureFromHexa(dataView.getUint8(17)),
                  tension: this.tensionFromHexa(dataView.getUint8(22)),

                  sensor1: this.temperatureFromHexa(dataView.getUint8(18))
                };
              })

              .then(state => {
                this.$log.debug('Received state: ' + JSON.stringify(state));
                /* On merge les deux versions et on update la bdd */
                angular.extend(details, state);
                return this.save(<IValve>details);
              })
              .then(deferred.resolve);

          } else {
            deferred.resolve();
          }
        });

      return deferred
        .promise
        .then(() => {
          this.$log.debug('Details: ' + JSON.stringify(this._vanneData.details));

          this._selectedValveProtocolVersion = this._vanneData.details.protocolVersion ? this._vanneData.details.protocolVersion : 0;
          this.accessedCharacteristics.details = true;
          return this._vanneData.details;
        });
    }

    /**
     * Envoie une action et retourne la réponse de la vanne
     * @param {Number} value - Code de l'action demandée
     * @param {Object} [purge] - Paramètres de la purge manuelle
     * @returns {Promise} Promise de la réponse de la vanne
     */
    sendAction(value: number, purge?: IPurgeManual & { unit: number }): ng.IPromise<any> {
      let parsedPurge = [0, 0, 0];
      if (purge) {
        parsedPurge = [purge.unit, purge.volume, purge.position | purge.tempo];
      }

      return this.protocol.sendCommand('ACTION', [value].concat(parsedPurge));
    }

    /**
     * Retourne le programme de purges d'une vanne
     * @param {String} [serialNumber] - Numéro de série de la vanne
     * @returns {Promise<IValveProgram>} Promise du programme
     */
    getProg(serialNumber?: string): ng.IPromise<IValveProgram> {
      serialNumber = serialNumber || this.selectedValveSerial;
      let deferred = this.$q.defer<IValveProgram>();

      if (this.accessedCharacteristics.prog) {
        deferred.resolve(this._vanneData.prog);
      } else {

        /* On récupère le prog en bdd */
        this.$q
          .all([
            this.getVanneDoc(serialNumber, ['prog']),
            this.getVanneDoc(serialNumber, ['prog', 'manual']),
            this.getVanneDoc(serialNumber, ['prog', 'units'])
          ])

          .then((results: [IValveProgram, IPurgeManual, IPurgeUnits]) => {
            this._vanneData.prog = results[0];
            this._vanneData.prog.manual._rev = results[1]._rev;
            this._vanneData.prog.units._rev = results[2]._rev;

            this.$log.debug('DB prog: ' + JSON.stringify(this._vanneData.prog));
          })

          .catch(error => {
            this._vanneData.prog = <IValveProgram>{}; // TODO: Empty prog
            if (error.status == 404) {
              this.$log.info('Le programme n\'existe pas dans la base de données');
            }
          })

          .then(() => {
            if (this.connectedValveSerial && this.connectedValveSerial == serialNumber) {
              /* On récupère la version de la vanne */
              this.protocol
                .sendCommand('Q_PROG', [], true)
                .then(result => this.parseProg(result))
                .then((prog: IValveProgram) => {
                  /* On merge les deux versions et on update la bdd */
                  angular.merge(this._vanneData.prog, prog);
                  return this.db.storeVanneProg(this._vanneData.prog, serialNumber);
                })

                .then((results: any[]) => {
                  /* On récupère un tableau de promises de db.storeVanneProg */
                  this._vanneData.prog._rev = results[0].rev;
                  this._vanneData.prog.manual._rev = results[1].rev;
                  this._vanneData.prog.units._rev = results[2].rev;

                  /* On met à jour le numéro de rev et on retourne le prog */
                  this.accessedCharacteristics.prog = true;
                  deferred.resolve(this._vanneData.prog);
                })

                .catch(error => {
                  if (error.code == this.ERROR_CODES['receive']['timeout'].code) {
                    if (Object.keys(this._vanneData.prog).length == 0) {
                      /* Si pas de réponse et pas dans bdd, nouveau programme vide */
                      return deferred.resolve(this._vanneData.prog);
                    }

                    /* Si pas de réponse et dans la bdd, erreur avec programme de la bdd */
                    return deferred.reject({ error: error, prog: this._vanneData.prog });
                  }
                });

            } else {
              this.accessedCharacteristics.prog = true;
              deferred.resolve(this._vanneData.prog);
            }
          });
      }

      return deferred.promise;
    }

    /**
     * Enregistre le programme de purges sur la vanne puis en bdd
     * @param {IValveProgram} prog - Programme de purges
     * @param {String} [serialNumber] - Numéro de série de la vanne
     * @returns {Promise<IValveProgram>} Promise du programme enregistré
     */
    saveProg(prog: IValveProgram, serialNumber?: string): ng.IPromise<IValveProgram> {
      this._vanneData.prog = this._vanneData.prog || <IValveProgram>{};
      serialNumber = serialNumber || this.selectedValveSerial;

      let purges = prog.auto
        .map(value => {
          let bitFrequency, frequency;
          let startDate = new Date(value.startDate);

          if (value.activeFrequency == PurgeFrequency.Weekly) {
            // frequency = prog.weekDay;
            frequency = startDate.getUTCDay();
            bitFrequency = 0x00;
          } else {
            // frequency = prog.monthDay;
            frequency = startDate.getUTCDate();
            bitFrequency = 0x80;
          }

          return [
            this.utils.timestampToSeconds(new Date(value.startDate).setSeconds(0)),  // Timestamp date de début
            this.utils.numberToBcd(startDate.getUTCMinutes()),                 // Minutes en BCD
            this.utils.numberToBcd(startDate.getUTCHours()),                   // Heures en BCD
            this.utils.numberToBcd(frequency) | bitFrequency,                  // Fréquence et valeur
            value.volume,                                                 // Volume
            value.tempo | value.position,                                 // Temporisation et position
            // value.isActive ? 1 : 0                                     // Active ou pas
          ];
        })
        .reduce((previousValue, currentValue) => previousValue.concat(currentValue), []);

      let inhibAuto = prog.inhibitions.auto.active ? 1 : 0;
      let inhibMan = prog.inhibitions.manual.active ? 1 : 0;
      let inhibSensor = prog.inhibitions.sensor.active ? 1 : 0;

      let activations = prog.auto.reduce((previousValue, currentValue, currentIndex) => {
        let bit = currentValue.isActive ? 1 : 0;
        return previousValue | (bit << currentIndex);
      }, 0);

      let frame =
        (<Array<any>>[prog.units.tempo | prog.units.inhibition, activations])
          .concat(
          purges,
          prog.manual.volume,
          prog.manual.tempo | prog.manual.position,
          (inhibSensor << 2) | (inhibMan << 1) | inhibAuto,
          prog.inhibitions.auto.value || 0xFF,
          prog.inhibitions.manual.value || 0xFF,
          prog.inhibitions.sensor.value || 0xFF,
          'admin',
          0x00
          // TODO: Capteurs
          );

      return this.protocol
        .sendCommand('PROG', frame, true)
        .then(result => this.parseProg(result))
        .then((vanneProg: IValveProgram) => {
          this.$log.debug('Program send');
          angular.merge(this._vanneData.prog, vanneProg);
          return this.db.storeVanneProg(this._vanneData.prog, serialNumber);
        })

        .then((results: any[]) => {
          /* On récupère un tableau de promises de db.storeVanneProg */
          this._vanneData.prog._rev = results[0].rev;
          this._vanneData.prog.manual._rev = results[1].rev;
          this._vanneData.prog.units._rev = results[2].rev;

          return this._vanneData.prog;
        });
    }

    /**
     * Récupère les paramètres depuis la bdd et la vanne si connectée
     * @param {String} [serialNumber] - Numéro de série de la vanne
     * @returns {Promise<IValve>} Promise de la configuration de la vanne
     */
    getConfig(serialNumber?: string): ng.IPromise<IValve> {
      serialNumber = serialNumber || this.selectedValveSerial;
      let deferred = this.$q.defer<IValve>();

      if (this.accessedCharacteristics.config) {
        deferred.resolve(this._vanneData.details);
      } else {

        /* On récupère les détails (donc les paramètres) en bdd */
        this.getVanneDetails(serialNumber)
          .then((details: IValve) => {
            if (this.connectedValveSerial && this.connectedValveSerial == serialNumber) {
              /* On récupère la version de la vanne */
              this.protocol.sendCommand('Q_PARAM')
                .then(result => this.parseConfig(result))
                .then((parsedConfig: IValveConfig) => {
                  this.$log.debug('Received config: ' + JSON.stringify(parsedConfig));
                  /* On merge les deux versions et on update la bdd */
                  angular.extend(this._vanneData.details, parsedConfig);
                  /* Comme les paramètres sont dans les détails, on sauve l'objet vanne "principal" */
                  return this.save(this._vanneData.details);
                })

                .then(result => {
                  /* On met à jour le numéro de rev et on retourne les détails */
                  this.accessedCharacteristics.config = true;
                  this._vanneData.details._rev = result.rev;
                  deferred.resolve(this._vanneData.details);
                });

              //                 .catch(error => {
              //                   if (error.code == ERROR_CODES.receive.timeout.code) {
              //                     if (Object.keys(vanneData.prog).length == 0) {
              //                       /* Si pas de réponse et pas dans bdd, nouveau programme vide */
              //                       return deferred.resolve(vanneData.prog);
              //                     }
              //
              //                     /* Si pas de réponse et dans la bdd, erreur avec programme de la bdd */
              //                     return deferred.reject({error: error, prog: vanneData.prog});
              //                   }
              //                 });

            } else {
              this.accessedCharacteristics.config = true;
              deferred.resolve(this._vanneData.details);
            }
          });
      }

      return deferred.promise;
    }

    /**
     * Enregistre les paramètres sur la vanne puis en bdd
     * @param {IValveConfig} details - Paramètres de la vanne
     * @param {String} [serialNumber] - Numéro de série de la vanne
     * @returns {Promise<IValve>} Promise des détails mis à jour avec les paramètres
     */
    saveConfig(details: IValveConfig, serialNumber?: string): ng.IPromise<IValve> {
      serialNumber = serialNumber || this.selectedValveSerial;

      let functions = details.endOfLife.functionStates
        .reduce((previousValue, currentValue, currentIndex) => {
          let bit = 0;
          let offset = 2 + currentIndex;

          if (currentValue) { bit = 1; }
          return previousValue | (bit << offset);
        }, 0);

      let kCode;
      for (let i = 0; i < this.VANNE_CONSTS.k.length; i++) {
        if (this.VANNE_CONSTS.k[i].value == details.k) {
          kCode = this.VANNE_CONSTS.k[i].code;
          break;
        }
      }

      let frame = [
        details.serialNumber,
        details.maintenance.frequency,
        details.maintenance.startDate / 1000,
        details.endOfLife.action | functions,
        kCode,
        details.initialIndex,
        details.software,
        details.hardware,
        details.timeMaxOffset,
        details.connectionCode
      ];

      return this.protocol
        .sendCommand('PARAM', frame)
        .then(result => this.parseConfig(result))
        .then((params: IValveConfig) => {
          this.$log.debug('Params sent');
          angular.merge(this._vanneData.details, params);
          return this.getState(serialNumber);
        });
    }

    /**
     * Initialise le numéro de série et le code de connexion sur une nouvelle vanne
     * @param {string} serialNumber Numéro de série à paramétrer
     * @param {string} connectionCode Code de connexion à paramétrer
     * @param {number} initialIndex Valeur initiale de l'index du compteur d'eau
     * @param {number} k Valeur correspondant au k souhaité
     * @returns {Promise<IValveConfig>} Promise de l'initialisation de la vanne
     */
    initValve(serialNumber: string, connectionCode: string, initialIndex: number, k: string): ng.IPromise<IValveConfig> {
      let initializedConfig: IValveConfig;

      return this.protocol
        .sendCommand('Q_PARAM')
        .then((rawConfig: any[]) => {
          rawConfig[9] = connectionCode;
          rawConfig[5] = initialIndex;
          rawConfig[4] = parseInt(k);
          rawConfig[0] = serialNumber;

          /* Mise à jour de la config avec les infos saisies */
          return this.protocol.sendCommand('PARAM', rawConfig);
        })

        .then(result => this.parseConfig(result))
        .then((config: IValveConfig) => {
          initializedConfig = config;
          this.$log.debug('Config initialized');
          this.connectedValveSerial = config.serialNumber;

          /* Enregistrement du code de connexion de la vanne en BDD */
          this.park.saveConnectionCode(serialNumber, connectionCode);
        })

        /* Enregistrement de l'accès à la vanne pour l'utilisateur */
        .then(() => this.park.addValveToUser(serialNumber, Date.now()))

        /* On ajoute l'adresse Mac et le serialNumber de la vanne en BD */
        .then(() => this.db.getMacAddressFromSerialNumber(serialNumber))
        .then((macAddress) => {
          if (macAddress == undefined) {
            return;
          }

          let vanneConfig: IValveInit = { macAddress: macAddress, serialNumber: serialNumber };
          this.db.storeMacAddress(vanneConfig);
        })

        .then(() => initializedConfig);
    }

    /**
     * Récupère les stats d'une vanne depuis la bdd et la vanne si connectée
     * @param {String} [serialNumber] - Numéro de série de la vanne
     * @param {Boolean} [forceRefresh] - Indique si on doit rafraîchir avec les données de la vanne
     * @returns {Promise<IValveStats>} Promise des stats
     */
    getStats(serialNumber?: string, forceRefresh?: boolean): ng.IPromise<IValveStats> {
      serialNumber = serialNumber || this.selectedValveSerial;
      forceRefresh = forceRefresh || false;
      let deferred = this.$q.defer<IValveStats>();

      if (this.accessedCharacteristics.stats && !forceRefresh) {
        deferred.resolve(this._vanneData.stats);
      } else {

        /* On récupère les stats en bdd */
        this.getVanneDoc(serialNumber, ['stats'])
          .catch(error => {
            if (error.status == 404) {
              this.$log.info("Les stats n'existent pas dans la base de données");
            }

            return {}; // Nouvel objet vide
          })

          .then((bddStats: IValveStats) => {
            this._vanneData.stats = bddStats;

            if (this.connectedValveSerial && this.connectedValveSerial == serialNumber) {
              /* On récupère la version de la vanne */
              this.protocol
                .sendCommand('Q_STATI', [], true)
                .then(rawFrame => {
                  let dataView = this.protocol.rawToDataView('V_STATI', rawFrame);

                  let parsedStats = <IValveStats>{
                    lastActionResult: dataView.getUint8(0),
                    timeSinceAction: dataView.getUint32(1, this.protocol.littleEndian),
                    messages: {
                      nbBadFrames: dataView.getUint16(5, this.protocol.littleEndian),
                      nbMessages: this.numberFromBuffer(dataView.buffer, 7, 3)
                    },
                    maintenance: {
                      nbOk: dataView.getUint16(10, this.protocol.littleEndian),
                      nbKo: dataView.getUint16(12, this.protocol.littleEndian),
                      lastDuration: dataView.getUint8(14) / 10,
                      meanDuration: dataView.getUint8(15) / 10
                    },
                    opening: {
                      nbOk: dataView.getUint16(16, this.protocol.littleEndian),
                      nbKo: dataView.getUint16(18, this.protocol.littleEndian),
                      lastDuration: dataView.getUint8(20) / 10,
                      meanDuration: dataView.getUint8(21) / 10,
                      totalDuration: this.numberFromBuffer(dataView.buffer, 22, 3),
                      meanFlowRate: dataView.getUint16(25, this.protocol.littleEndian)
                    },
                    closing: {
                      nbOk: dataView.getUint16(27, this.protocol.littleEndian),
                      nbKo: dataView.getUint16(29, this.protocol.littleEndian),
                      lastDuration: dataView.getUint8(31) / 10,
                      meanDuration: dataView.getUint8(32) / 10,
                      totalDuration: this.numberFromBuffer(dataView.buffer, 33, 3)
                    },
                    limited: {
                      nbOk: dataView.getUint16(36, this.protocol.littleEndian),
                      nbKo: dataView.getUint16(38, this.protocol.littleEndian),
                      lastDuration: dataView.getUint8(40) / 10,
                      meanDuration: dataView.getUint8(41) / 10,
                      totalDuration: this.numberFromBuffer(dataView.buffer, 42, 3),
                      meanFlowRate: dataView.getUint16(45, this.protocol.littleEndian)
                    },
                    purges: {
                      totalVolume: dataView.getUint32(47, this.protocol.littleEndian),
                      meanVolume: dataView.getUint16(51, this.protocol.littleEndian),
                      lastVolume: dataView.getUint16(53, this.protocol.littleEndian),
                      nbCountdown: dataView.getUint16(55, this.protocol.littleEndian),
                      nbTempo: dataView.getUint16(57, this.protocol.littleEndian),
                      lastStop: dataView.getUint8(59),
                      timeSinceLast: dataView.getUint16(60, this.protocol.littleEndian),
                      totalDuration: this.numberFromBuffer(dataView.buffer, 62, 3),
                      nbOpened: dataView.getUint16(65, this.protocol.littleEndian),
                      nbLimited: dataView.getUint16(67, this.protocol.littleEndian)
                    },
                    system: {
                      nbReset: dataView.getUint8(69),
                      ledDuration: dataView.getUint16(70, this.protocol.littleEndian),
                      nbProgUpgrades: dataView.getUint8(72),
                      lastUpgrade: {
                        date: dataView.getUint32(73, this.protocol.littleEndian) * 1000,
                        user: String.fromCharCode.apply(this, (rawFrame.slice(2 + 77, 2 + 77 + 10)))
                      },
                      motor: {
                        totalDuration: this.numberFromBuffer(dataView.buffer, 87, 3) / 10,
                        nbActuation: dataView.getUint16(90, this.protocol.littleEndian)
                      }
                    }
                  };

                  if (this.connectedValveProtocolVersion == 1) {
                    parsedStats.sensors = {
                      limitedVolumeDueToSensor1: dataView.getUint32(92, this.protocol.littleEndian),
                      openedVolumeDueToSensor1: dataView.getUint32(96, this.protocol.littleEndian)
                    };
                  }

                  return parsedStats;
                })

                .then((vanneStats: IValveStats) => {
                  this.$log.debug('Received stats: ' + JSON.stringify(vanneStats));
                  /* On merge les deux versions et on update la bdd */
                  angular.extend(this._vanneData.stats, vanneStats);
                  return this.db.storeVanneStats(this._vanneData.stats, serialNumber);
                })

                .then(result => {
                  /* On met à jour le numéro de rev et on retourne les stats */
                  this.accessedCharacteristics.stats = true;
                  this._vanneData.stats._rev = result.rev;
                  deferred.resolve(this._vanneData.stats);
                });

            } else {
              this.accessedCharacteristics.stats = true;
              deferred.resolve(this._vanneData.stats);
            }
          });
      }

      return deferred.promise;
    }

    /**
     * Récupère l'historique de la vanne pour un intervalle et une fréquence donnée
     * @param {Date} date - Date demandée
     * @param {Number} granularity - Granularité demandée
     * @param {String} [serialNumber] - Numéro de série de la vanne
     * @returns {Promise} Promise de l'historique
     */
    getHistory(date: Date, granularity: number, serialNumber?: string
    ): ng.IPromise<(IHistorySyncElement | IHistoryAsyncElement)[] | IHistoryComputedElement[] | void> {
      serialNumber = serialNumber || this.selectedValveSerial;
      let beginDate: number, endDate: number, theoricalEndDate: number, millisInDay = 86400000;

      switch (granularity) {
        case 15:
          /* Vue journée */
          beginDate = date.getTime();
          theoricalEndDate = beginDate + millisInDay; // +1 jour
          break;
        case 1440:
          /* Vue semaine */
          beginDate = this.utils.getMondayTimestamp(date);
          theoricalEndDate = beginDate + millisInDay * 7; // +1 semaine
          break;
        case 10080:
          /* Vue mois, on démarre à la semaine du 1er et on finit à celle du dernier jour */
          beginDate = this.utils.getMondayTimestamp(new Date(date.getFullYear(), date.getMonth()));
          theoricalEndDate = this.utils.getMondayTimestamp(new Date(date.getFullYear(), date.getMonth() + 1)) + 7 * millisInDay;
          break;
        case 43200:
          /* Vue année */
          beginDate = new Date(date.getFullYear(), 0).getTime();
          theoricalEndDate = new Date(date.getFullYear() + 1, 0).getTime();
          break;
        default:
      }

      let currentDate = new Date();
      if (theoricalEndDate > currentDate.getTime()) {
        /* Si la période demandée n'est pas finie */
        if (granularity == 43200) {
          endDate = new Date(currentDate.getFullYear(), currentDate.getMonth()).getTime();
        } else {
          let currentMinutes = currentDate.getMinutes();
          let currentHours = currentDate.getHours();
          endDate = currentDate.setHours(currentHours - (currentHours % (granularity / 60)),
            currentMinutes - (currentMinutes % granularity), 0, 0);
        }
      } else {
        endDate = theoricalEndDate;
      }

      let data: IHistoryParams = {
        granularity: granularity,
        beginDate: beginDate,
        endDate: endDate,
        theoricalEndDate: theoricalEndDate
      };

      let requestParams: Array<any> = ['history'];
      switch (data.granularity) {
        case 15:
          /* Détails d'une journée tous les 1/4 d'heure */
          requestParams.push('day', data.beginDate);
          break;
        case 1440:
          /* Vue semaine avec données quotidiennes */
          requestParams.push('week', data.beginDate);
          break;
        case 10080:
          /* Vue mois avec données hebdomadaires */
          requestParams.push('month', data.beginDate);
          break;
        case 43200:
          /* Vue année avec données mensuelles */
          requestParams.push('year', data.beginDate);
          break;
        default:
      }

      return this
        .getVanneDoc(serialNumber, requestParams)
        .catch(error => {
          if (error.status == 404) {
            this.$log.info('Les données n\'existent pas dans la base de données');
          } else {
            this.$log.error(JSON.stringify(error));
            throw error;
          }
        })

        .then((response: any) => {
          if (response && response.complete == true
            && new Date(data.theoricalEndDate).setHours(0, 0, 0, 0) != (new Date().setHours(0, 0, 0, 0)) + 86400000) {
            /* Si le jour de fin est différent du jour actuel + 1, on renvoie les données de la bdd */
            this.$log.info('Returning history from database...');
            return response.values;
          }

          if (!this.connectedValveSerial || this.connectedValveSerial != this.selectedValveSerial) {
            if (response) {
              return response.values;
            } else {
              throw new Error('Les données n\'existent pas en base et la vanne n\'est pas connectée');
            }
          }

          return this.receiveHistory(data, response, serialNumber);
        });
    }

    /**
     * Récupère les infos de géoloc d'une vanne depuis la bdd et la vanne si connectée
     * @param {String} [serialNumber] - Numéro de série de la vanne
     * @param {Boolean} [forceRefresh] - Indique si on doit rafraîchir avec les données de la vanne
     * @returns {Promise<IValveGeoloc>} Promise de la géoloc
     */
    getGeoloc(serialNumber?: string, forceRefresh?: boolean): ng.IPromise<IValveGeoloc> {
      serialNumber = serialNumber || this.selectedValveSerial;
      forceRefresh = forceRefresh || false;
      let deferred = this.$q.defer<IValveGeoloc>();

      if (this.accessedCharacteristics.geoloc && !forceRefresh) {
        deferred.resolve(this._vanneData.geoloc);
      } else {

        /* On récupère la geoloc en bdd */
        this.getVanneDoc(serialNumber, ['geoloc'])
          .catch(error => {
            if (error.status == 404) {
              this.$log.info("Les informations de geoloc n'existent pas dans la base de données");
            }

            return {}; // Nouvel objet vide
          })

          .then((geoloc: IValveGeoloc) => {
            this._vanneData.geoloc = geoloc;

            if (this.connectedValveSerial && this.connectedValveSerial == serialNumber) {
              /* On récupère la version de la vanne */
              this.protocol.sendCommand('Q_GEOLOC')
                .then(result => this.parseGeoloc(result))
                .then((parsedGeoloc: IValveGeoloc) => {
                  this.$log.debug('Received geoloc: ' + JSON.stringify(parsedGeoloc));
                  /* On merge les deux versions et on update la bdd */
                  angular.merge(this._vanneData.geoloc, parsedGeoloc);
                  return this.db.storeVanneGeoloc(this._vanneData.geoloc, serialNumber);
                })

                .then(result => {
                  /* On met à jour le numéro de rev et on retourne les infos */
                  this._vanneData.geoloc._rev = result.rev;
                  this.accessedCharacteristics.geoloc = true;
                  deferred.resolve(this._vanneData.geoloc);
                });

            } else {
              this.accessedCharacteristics.geoloc = true;
              deferred.resolve(this._vanneData.geoloc);
            }
          });
      }

      return deferred.promise;
    }

    /**
     * Enregistre les infos de géoloc sur la vanne puis en bdd
     * @param {IValveGeoloc} geoloc - Infos de géoloc de la vanne
     * @param {String} [serialNumber] - Numéro de série de la vanne
     * @returns {Promise<IValveGeoloc>} Promise de la géoloc mise à jour en BDD
     */
    saveGeoloc(geoloc: IValveGeoloc, serialNumber?: string): ng.IPromise<IValveGeoloc> {
      serialNumber = serialNumber || this.selectedValveSerial;

      let frame = [
        geoloc.meterSerial,
        geoloc.deviceFunction,
        geoloc.latitude,
        geoloc.longitude,
        geoloc.altitude,
        geoloc.installationDate,
        geoloc.streetNumber,
        geoloc.street,
        geoloc.zipCode,
        geoloc.city,
        geoloc.comments
      ];

      return this.protocol
        .sendCommand('GEOLOC', frame)
        .then(result => this.parseGeoloc(result))
        .then((parsedGeoloc: IValveGeoloc) => {
          this.$log.debug('Geoloc sent');
          angular.merge(this._vanneData.geoloc, parsedGeoloc);
          return this.db.storeVanneGeoloc(this._vanneData.geoloc, serialNumber);
        })

        .then(result => {
          /* On met à jour le numéro de révision */
          this._vanneData.geoloc._rev = result.rev;
          return this._vanneData.geoloc;
        });
    }

    /**
     * Récupère les paramètres du capteur de température externe depuis la bdd et la vanne si connectée
     *
     * @param {string} [serialNumber] - Numéro de série de la vanne
     * @param {boolean} [forceRefresh] - Indique si on doit rafraîchir avec les données de la vanne
     * @returns {ng.IPromise<IValveTempExt>} Promise des stats
     *
     * @memberOf Vanne
     */
    getTempExt(serialNumber?: string, forceRefresh?: boolean): ng.IPromise<IValveTempExt> {
      serialNumber = serialNumber || this.selectedValveSerial;
      forceRefresh = forceRefresh || false;
      let deferred = this.$q.defer<IValveTempExt>();

      if (this.accessedCharacteristics.tempExt && !forceRefresh) {
        deferred.resolve(this.vanneData.tempExt);
      } else {

        /* On récupère les stats en bdd */
        this.getVanneDoc(serialNumber, ['tempExt'])
          .catch(error => {
            if (error.status == 404) {
              this.$log.info("Les infos du capteur externe n'existent pas dans la base de données");
            }

            return {}; // Nouvel objet vide
          })

          .then((tempExtInfos: IValveTempExt) => {
            this._vanneData.tempExt = tempExtInfos;

            if (this.connectedValveSerial && this.connectedValveSerial == serialNumber) {
              /* On récupère la version de la vanne */
              this.protocol
                .sendCommand('Q_TEMP_EXT')
                .then(result => this.parseTempExt(result))
                .then((parsedValveTempExt: IValveTempExt) => {
                  this.$log.debug('Received temp ext: ' + JSON.stringify(parsedValveTempExt));
                  /* On merge les deux versions et on update la bdd */
                  angular.extend(this._vanneData.tempExt, parsedValveTempExt);
                  return this.db.storeVanneTempExt(this._vanneData.tempExt, serialNumber);
                })

                .then(result => {
                  /* On met à jour le numéro de rev et on retourne les infos du capteur */
                  this.accessedCharacteristics.tempExt = true;
                  this._vanneData.tempExt._rev = result.rev;
                  deferred.resolve(this.vanneData.tempExt);
                });

            } else {
              this.accessedCharacteristics.tempExt = true;
              deferred.resolve(this.vanneData.tempExt);
            }
          });
      }

      return deferred.promise;
    }

    /**
     * Enregistre les paramètres du capteur externe sur la vanne puis en BDD
     *
     * @param {IValveTempExt} tempExt - Données concernant le capteur externe
     * @param {string} [serialNumber] - Numéro de série de la vanne
     * @returns {ng.IPromise<IValveTempExt>} Promise de la mise à jour des infos du capteur externe en BDD
     *
     * @memberOf Vanne
     */
    saveTempExt(tempExt: IValveTempExt, serialNumber?: string): ng.IPromise<IValveTempExt> {
      serialNumber = serialNumber || this.selectedValveSerial;

      let frame = [
        tempExt.markedAsConnected ? 1 : 0,
        tempExt.bottomPosition,
        tempExt.middlePosition,
        tempExt.topPosition,
        (tempExt.bottomThreshold.value - this.VANNE_CONSTS.minTemp) / 0.5,
        (tempExt.topThreshold.value - this.VANNE_CONSTS.minTemp) / 0.5,
        tempExt.bottomThreshold.range / 0.5,
        tempExt.topThreshold.range / 0.5,
        tempExt.failureAction,
        tempExt.failureCountdown || 5
      ];

      return this.protocol
        .sendCommand('TEMP_EXT', frame)
        .then(result => this.parseTempExt(result))
        .then((parsedTempExt: IValveTempExt) => {
          this.$log.debug('TempExt sent and received: ', JSON.stringify(parsedTempExt));
          angular.merge(this._vanneData.tempExt, parsedTempExt);
          return this.db.storeVanneTempExt(this._vanneData.tempExt, serialNumber);
        })

        .then(result => {
          /* On met à jour le numéro de révision */
          this._vanneData.tempExt._rev = result.rev;
          return this.vanneData.tempExt;
        });
    }

    /**
     * Réinitialise et retourne les indicateurs d'accession de caractéristiques d'une vanne
     * @returns {IAccessedCharacteristics}
     */
    initAccessedCharacteristics(): IAccessedCharacteristics {
      return this.accessedCharacteristics = {
        config: false,
        details: false,
        history: false,
        geoloc: false,
        prog: false,
        stats: false,
        tempExt: false
      };
    }

    /**
     * Déconnecte l'application de la vanne (si connectée)
     * @param {boolean} [sameTarget] Indique si la cible est identique à la vanne à déconnecter
     * @returns {Promise} Promise de la déconnexion
     */
    disconnect(sameTarget?: boolean): ng.IPromise<any> {
      this.connectedValveSerial = this._connectedDeviceId = null;
      return this.protocol.disconnect(sameTarget);
    }

    /**
     * Etablit et initialise une connexion à une vanne
     * @param {String} deviceId - Adresse mac ou UUID de la vanne
     * @param {String} [connectionCode] Code de connexion à la vanne
     * @param {number} [retry] Nombre d'essais de connexion
     * @returns {Promise} Promise de la connexion
     */
    connect(deviceId: string, connectionCode?: string, retry?: number): ng.IPromise<any> {
      this.connectedValveSerial = null;
      let connectionInfos: any;
      let isCodeTemp: boolean = false;
      let serialNumber: string;

      /* Même cible : si deviceId égal, si retry ou si code fourni manuellement */
      let sameTarget: boolean = (deviceId == this._connectedDeviceId || !!retry || !!connectionCode);

      this.$ionicLoading.show();

      return this
        .disconnect(sameTarget)
        .then(() => {
          if (sameTarget) {
            /* S'il s'agit de se reconnecter à la même vanne, on met un timeout pour laisser le temps à la vanne de se remettre en écoute */
            return this.$timeout(3000);
          }
        })

        /* Connexion bluetooth de base à la vanne */
        .then(() => this.protocol.connect(deviceId))

        /* Récupération du code de connexion à l'aide du nom de la vanne */
        .then(connectionResult => {
          connectionInfos = connectionResult;
          this._connectedDeviceId = deviceId;

          /* On récupère le numéro de série à partir du nom de la vanne */
          serialNumber = connectionInfos.name.substr(7);

          /* On ajoute l'adresse Mac et le serialNumber de la vanne en BD */
          let vanneConfig: IValveInit = { macAddress: deviceId, serialNumber: serialNumber || '0000000000' };
          this.db.storeMacAddress(vanneConfig);

          if (connectionCode) {
            return this.$q.resolve();
          } else if (connectionInfos.name == 'ValveSL000000000') {
            connectionCode = '0000000000';
            return this.$q.resolve();

          } else {
            return this.park
              .getUserValveCode(serialNumber)
              .then(result => {
                isCodeTemp = result.temp || false;
                connectionCode = result.code;
              });
          }
        })

        .then(() => this.protocol.initProtocol(connectionCode))
        .catch(error => {
          /* Si on a une différence de timestamp, on répercute dans les infos de connexion */
          if (error.code == 26) {
            connectionInfos.vanneTimestamp = error.vanneTimestamp;
          } else {
            throw error;
          }
        })

        .then(() => {
          // this._connectedValveProtocolVersion = protocolVersion;

          if (connectionInfos.name != 'ValveSL000000000' && (connectionCode || isCodeTemp)) {
            /* Si le code d'activation a été fourni ou est temporaire, on l'enregistre et on met à jour l'utilisateur */
            return this.park
              .saveConnectionCode(serialNumber, connectionCode)
              .then(() => this.park.addValveToUser(serialNumber, Date.now()))
              .catch(error => {
                if (error == 'ERROR_WRITE_VALVE_TO_USER') {
                  this.$ionicPopup.alert({
                    title: `Erreur lors de la mise à jour des accès de l'utilisateur`,
                    okType: 'button-assertive',
                    template: JSON.stringify(error)
                  });
                } else if (error == 'ERROR_WRITE_CODE') {
                  this.$ionicPopup.alert({
                    title: `Erreur lors de l'enregistrement du code`,
                    okType: 'button-assertive',
                    template: JSON.stringify(error)
                  });
                }
              });
          }
        })

        .then(() => {
          /* On extrait le serial de la vanne depuis son nom */
          this.connectedValveSerial = connectionInfos.name.substr(7);
          this.initAccessedCharacteristics();

          return connectionInfos;
        })

        .catch(error => {
          if (error == this.ERROR_CODES['receive']['auth']) {
            if ((retry && retry < 1) || !retry) {
              retry = retry ? ++retry : 1;
              return this.connect(deviceId, connectionCode, retry);
            }
          }

          /* Si plus d'une tentative de deco/reco complète ou autre erreur, on remonte l'erreur */
          throw error;
        });
    }

    /**
     * Retourne un tableau avec les codes erreurs correspondant à la valeur en paramètre
     * @param {Number} rawErrors - Valeur brute retournée par la vanne
     * @returns {Array} Erreurs parsées
     */
    parseVanneErrors(rawErrors: number): any[][] {
      if (rawErrors == 0) {
        return null;
      }

      let parsedErrors = [[], [], []];
      this.VANNE_CONSTS.vanneErrors
        .forEach((byte, index) => {
          let selectedByte = (rawErrors >> index * 8) & 0xFF;

          angular.forEach(byte, (errorLabel, errorCode) => {
            const parsedErrorCode = parseInt(errorCode);

            if ((selectedByte & parsedErrorCode) == parsedErrorCode) {
              let add = true;

              if (index == 0 && [0x20, 0x40].indexOf(parsedErrorCode) != -1 && (selectedByte & 0x60) == 0x60) {
                add = false;
              }

              if (add) {
                parsedErrors[index].push(parsedErrorCode);
              }
            }
          });
        });

      return parsedErrors;
    }

    /**
     * Retourne un tableau en paramètres sous la forme d'une seule valeur avec décalages d'octets
     * @param {Array} array - Tableau de valeurs
     * @returns {Number} Valeurs sous forme d'un seul entier
     */
    arrayToNumber(array: Array<number>): number {
      return array.reduce((previousValue, currentValue, currentIndex) => {
        let shift = this.protocol.littleEndian ? currentIndex : length - currentIndex;
        return previousValue | (currentValue << (shift * 8));
      }, 0);
    }

    /**
     * Vérifie si la vanne sélectionnée pour affichage est thermostatée.
     * Retourne vrai si le capteur de température externe est branché et qu'il n'y a pas d'erreur
     * Retourne faux si le capteur est indiqué branché mais avec erreur
     * Retourne undefined si le capteur n'est pas branché
     *
     * @param {{ defaults: any[]; sensor1: number; }} data
     * @returns {boolean | undefined}
     *
     * @memberOf Vanne
     */
    isSelectedValveTempExternSensorOk(data: { defaults: any[]; sensor1: number; }): boolean | undefined {
      let isErrorPresent: boolean = data.defaults && data.defaults[1].length && data.defaults[1].includes(32);
      if (isErrorPresent) {
        return false;
      }

      /* Si pas d'erreur et temp égale à tempMin ou undefined, c'est que le capteur n'est pas indiqué branché */
      if (data.sensor1 == (undefined || this.VANNE_CONSTS.minTemp)) {
        return;
      }

      /* Si branché et pas d'erreur, OK */
      return true;
    }

    /**
     * Ajoute ou update une nouvelle vanne dans la base de données
     * @param {IValve} vanne
     * @returns {Promise} Promise de l'enregistrement de la vanne
     */
    private save(vanne: IValve): ng.IPromise<any> {
      if (!vanne.serialNumber) {
        vanne.serialNumber = this._selectedValveSerial;
      }

      return this.db.storeVanne(vanne)
        .then(result => {
          this._vanneData.details = vanne;
          this._vanneData.details._rev = result.rev;
          return result;
        })
        .catch(error => {
          this.$ionicPopup.alert({
            title: 'Erreur d\'écriture en base de données',
            okType: 'button-assertive',
            template: JSON.stringify(error)
          });

          return this.$q.reject(error);
        });
    }

    /**
     * Parse les données brutes d'un programme et retourne un objet
     * @param {Array} rawFrame - Tableau de la frame brute
     * @returns {Object} Programme parsé
     */
    private parseProg(rawFrame: Array<any>): IValveProgram {
      let dataView = this.protocol.rawToDataView('V_PROG', rawFrame);
      let prog: IValveProgram = {
        auto: [],
        units: {
          tempo: dataView.getUint8(0) & 0x0F,
          inhibition: dataView.getUint8(0) & 0xF0
        },
        manual: {
          volume: dataView.getUint16(103, this.protocol.littleEndian),
          tempo: dataView.getUint8(105) & 0x7F,
          position: dataView.getUint8(105) & 0x80
        },
        inhibitions: {
          auto: {
            active: dataView.getUint8(106) & 0x01 ? true : false,
            value: dataView.getUint8(107)
          },
          manual: {
            active: dataView.getUint8(106) & 0x02 ? true : false,
            value: dataView.getUint8(108)
          },
          sensor: {
            active: dataView.getUint8(106) & 0x04 ? true : false,
            value: dataView.getUint8(109)
          }
        },
        programmer: String.fromCharCode.apply(this, (rawFrame.slice(2 + 110, 2 + 110 + 10))),
        id: dataView.getUint8(120)
      };

      let activations = dataView.getUint16(1, this.protocol.littleEndian);

      let byteOffset = 3;
      for (let i = 0; i < 10; i++) {
        prog.auto.push({
          startDate: dataView.getUint32(byteOffset, this.protocol.littleEndian) * 1000,
          // minutes: bcdToNumber(dataView.getUint8(byteOffset + 4)),
          // hours: bcdToNumber(dataView.getUint8(byteOffset + 5)),
          activeFrequency: dataView.getUint8(byteOffset + 6) & 0x80 ? PurgeFrequency.Monthly : PurgeFrequency.Weekly,
          // weekDay: bcdToNumber(dataView.getUint8(byteOffset + 6) & 0x7F),
          // monthDay: bcdToNumber(dataView.getUint8(byteOffset + 6) & 0x7F),
          volume: dataView.getUint16(byteOffset + 7, this.protocol.littleEndian),
          position: dataView.getUint8(byteOffset + 9) & 0x80,
          tempo: dataView.getUint8(byteOffset + 9) & 0x7F,
          isActive: ((activations >> i) & 0x01) == 1 ? true : false
        });

        byteOffset += 10;
      }

      this.$log.debug('Parsed prog: ' + JSON.stringify(prog));
      return prog;
    }

    /**
     * Parse les données de config de la vanne et retourne un objet
     * @param {Array} array - Tableau de la frame
     * @returns {Object} Paramètres parsés
     */
    private parseConfig(array: Array<any>): IValveConfig {
      let kValue;
      for (let i = 0; i < this.VANNE_CONSTS.k.length; i++) {
        if (this.VANNE_CONSTS.k[i].code == array[4]) {
          kValue = this.VANNE_CONSTS.k[i].value;
          break;
        }
      }

      return <IValveConfig>{
        serialNumber: array[0],
        maintenance: {
          frequency: array[1],
          startDate: array[2] * 1000
        },
        endOfLife: {
          action: array[3] & 0x03,
          functionStates: [
            array[3] & 0x04 ? true : false,  // Activation maintenance
            array[3] & 0x08 ? true : false,  // Activation purges auto
            array[3] & 0x10 ? true : false,  // Activation actions capteurs
            array[3] & 0x20 ? true : false   // Activation comm' radio
          ]
        },
        k: kValue,
        initialIndex: array[5],
        software: array[6],
        hardware: array[7],
        timeMaxOffset: array[8],
        connectionCode: array[9]
      };
    }

    /**
     * Parse les données de géoloc de la vanne et retourne un objet
     * @param {Array} array - Tableau de la frame
     * @returns {Object} Paramètres parsés
     */
    private parseGeoloc(array: Array<any>): IValveGeoloc {
      return {
        altitude: array[4].replace(/\0/g, '').trim(),
        comments: array[10].replace(/\0/g, '').trim(),
        deviceFunction: array[1],
        installationDate: array[5] * 1000,
        latitude: array[2].replace(/\0/g, '').trim(),
        longitude: array[3].replace(/\0/g, '').trim(),
        meterSerial: array[0].replace(/\0/g, '').trim(),

        city: array[9].replace(/\0/g, '').trim(),
        street: array[7].replace(/\0/g, '').trim(),
        streetNumber: array[6].replace(/\0/g, '').trim(),
        zipCode: array[8].replace(/\0/g, '').trim()
      };
    }

    /**
     * Parse les données correspondant au capteur de température externe
     *
     * @private
     * @param {number[]} array - Tableau de la frame
     * @returns {IValveTempExt} Données parsées
     *
     * @memberOf Vanne
     */
    private parseTempExt(array: number[]): IValveTempExt {
      return {
        markedAsConnected: !!array[0],
        bottomPosition: array[1],
        middlePosition: array[2],
        topPosition: array[3],
        bottomThreshold: { value: this.temperatureFromHexa(array[4]), range: array[6] * 0.5 },
        topThreshold: { value: this.temperatureFromHexa(array[5]), range: array[7] * 0.5 },
        failureAction: array[8],
        failureCountdown: array[9]
      };
    }

    /**
     * Récupère l'historique de la période demandée auprès de la vanne
     * @param {IHistoryParams} data - Objet contenant les détails de la requête
     * @param {Object} [bddData] - Document correspondant dans la bdd
     * @param {String} [serialNumber] - Numéro de série de la vanne
     * @param {Array<IHistorySyncElement>} [syncData] - Tableau contenant les données synchrones déjà récupérées
     * @returns {Promise} Promise de l'historique
     */
    private receiveHistory(data: IHistoryParams, bddData?: any, serialNumber?: string, syncData?: Array<IHistorySyncElement>
    ): ng.IPromise<(IHistorySyncElement | IHistoryAsyncElement)[] | IHistoryComputedElement[] | void> {

      syncData = syncData || [];
      serialNumber = serialNumber || this.selectedValveSerial;
      let beginDate: number, endDate: number;

      //       if (data.complete) {
      //         /* On a récupéré les données périodiques, il nous manque la valeur la plus proche de l'heure actuelle */
      //         var currentDate = new Date();
      //         var currentMinutes = currentDate.getMinutes();
      //         beginDate = currentDate.setHours(currentDate.getHours(), currentMinutes - (currentMinutes % 15), 0, 0);
      //         endDate = beginDate;
      //
      //       } else {
      /* Les données à récupérer se situent dans une période passée ou les données périodiques n'ont pas encore été récupérées */

      if (data.granularity == 15) {
        beginDate = data.beginDate;
        endDate = data.endDate;

      } else {
        if (!data.requestedDate) {
          beginDate = data.beginDate;
        } else {
          let requestedDate = new Date(data.requestedDate);
          if (data.granularity == 43200) {
            beginDate = new Date(requestedDate.getFullYear(), requestedDate.getMonth() + 1).getTime();
          } else {
            beginDate = new Date(requestedDate.getFullYear(), requestedDate.getMonth(),
              requestedDate.getDate() + data.granularity / 60 / 24).getTime();
          }
        }

        if (beginDate > data.endDate) {
          /* Si la nouvelle date demandée dépasse la dernière date demandée ou disponible */
          beginDate = data.endDate;
        }

        data.requestedDate = beginDate;
        endDate = beginDate; // + 15 * 60 * 1000;
      }
      // }

      this.$log.debug('Begin sync date: ' + new Date(beginDate));
      this.$log.debug('End sync date: ' + new Date(endDate));
      let syncFrame = [0, this.utils.timestampToSeconds(beginDate), this.utils.timestampToSeconds(endDate), data.granularity];

      return this.protocol
        .sendCommand('Q_HISTO', syncFrame, true)
        /* Récupération de l'historique synchrone */
        .then(() => {
          return this.readSyncHistory(endDate, data.theoricalEndDate, data.granularity);
        })
        .then((parsedData: Array<IHistorySyncElement>) => {
          this.$log.debug('Received sync history: ' + JSON.stringify(parsedData));

          if (syncData.length) {
            Array.prototype.push.apply(syncData, parsedData);
            if (data.granularity != 15) {
              this.$log.debug('Periodic history data: ' + JSON.stringify(syncData));
            }
          } else {
            syncData = parsedData;
          }

          if (data.granularity != 15 && endDate < data.endDate) {
            this.$log.debug('Periodic history, requesting next timestamp...');
            return this.receiveHistory(data, bddData, serialNumber, syncData);

            // } else if (data.granularity != 15 && endDate > data.endDate && !data.complete) {
            //   data.complete = true;
            //   $log.debug("Sync history incomplete, getting last available value...");
            //   return receiveHistory(data, bddData, id, syncData);

          } else {
            this.$log.debug('Sync history complete');
            return this.mergeHistories(data, bddData, syncData, serialNumber);
          }
        })

        .catch(error => {
          if (error.code) {
            this.$ionicPopup.alert({
              title: 'Erreur de réception',
              template: 'Une erreur est survenue lors de la récupération des données depuis la vanne',
              okType: 'button-assertive'
            });
          } else {
            throw error;
          }
        });
    }

    /**
     * Récupère les données synchrones demandées tant que décompteur > 0
     * @param {Number} endDate - Timestamp de la date de fin
     * @param {Number} theoricalEndDate - Timestamp théorique de la date de fin si passée
     * @param {Number} granularity - Granularité de l'historique demandé en minutes
     * @param {IHistorySyncElement[]} [parsedData] - Tableau des données déjà reçues
     * @returns {Promise<IHistorySyncElement[]>} Promise de toutes les données synchrones
     */
    private readSyncHistory(endDate: number, theoricalEndDate: number, granularity: number,
      parsedData?: Array<IHistorySyncElement>): ng.IPromise<Array<IHistorySyncElement>> {

      parsedData = parsedData || [];

      return this.protocol
        .readData('V_HISTO_SYNC', true)
        .then(rawFrame => {
          let dataView = this.protocol.rawToDataView('V_HISTO_SYNC', rawFrame);

          let forth = dataView.getUint8(3);
          let count = this.numberFromBuffer(dataView.buffer, 0, 3);
          let timestamp, currentDate = new Date();

          if (currentDate.getTime() < endDate) {
            /* Si la période n'est pas finie */
            let currentMinutes = currentDate.getMinutes();
            let currentHours = currentDate.getHours();
            let lastValidDate = currentDate.setHours(currentHours - (currentHours % (granularity / 60)),
              currentMinutes - (currentMinutes % granularity), 0, 0);
            timestamp = lastValidDate - (count * granularity * 60 * 1000);
          } else {
            /* Si la période est terminée */
            timestamp = endDate - (count * granularity * 60 * 1000);
          }

          if (forth != 0xFF && forth != 0) {
            if (currentDate.getTime() < endDate || granularity != 15 || timestamp != theoricalEndDate) {
              let defaults = this.parseVanneErrors(this.numberFromBuffer(dataView.buffer, 4, 3));
              let sensor1 = this.temperatureFromHexa(dataView.getUint8(12));

              parsedData.push({
                frameType: HistoryType.Synchronous, // Synchrone
                timestamp: timestamp,
                position: forth & 0x07,
                storage: forth & 0x08 ? true : false,
                action: forth & 0xF0,
                rawDefault: this.numberFromBuffer(dataView.buffer, 4, 3),
                defaults: defaults,
                index: dataView.getUint32(7, this.protocol.littleEndian),
                temperature: this.temperatureFromHexa(dataView.getUint8(11)),
                captors: [
                  this.temperatureFromHexa(dataView.getUint8(12)),
                  dataView.getUint8(13),
                  dataView.getUint8(14),
                  dataView.getUint8(15)
                ],
                tension: this.tensionFromHexa(dataView.getUint8(16)),
                battery: dataView.getUint8(17),
                prog: dataView.getUint8(18),

                sensor1: sensor1,
                // isTempExternSensorOk: this.isSelectedValveTempExternSensorOk({ defaults, })
              });
            }
          }

          if (count > 0) {
            return this.readSyncHistory(endDate, theoricalEndDate, granularity, parsedData);
          }

          this.protocol.toggleReception(false);
          return parsedData;
        });
    }

    /**
     * Prend en paramètre l'historique synchrone, et merge avec l'asynchrone une fois récupéré
     * @param {IHistoryParams} data - Objet contenant les détails de la requête
     * @param {Object} [bddData] - Document correspondant dans la bdd
     * @param {Array<IHistorySyncElement>} [syncData] - Tableau contenant l'historique synchrone
     * @param {String} [serialNumber] - Numéro de série de la vanne
     * @returns {Promise} Promise de l'historique complet pour la granularité spécifiée
     */
    private mergeHistories(data: IHistoryParams, bddData?: any, syncData?: Array<IHistorySyncElement>,
      serialNumber?: string): ng.IPromise<(IHistorySyncElement | IHistoryAsyncElement)[] | IHistoryComputedElement[]> {

      syncData = syncData || [];
      serialNumber = serialNumber || this.selectedValveSerial;
      let asyncEndDate = data.theoricalEndDate > Date.now() ? Date.now() : data.endDate;
      let asyncFrame = [1, this.utils.timestampToSeconds(data.beginDate), this.utils.timestampToSeconds(asyncEndDate), 0];
      // var asyncData = [];

      return this.protocol
        .sendCommand('Q_HISTO', asyncFrame, true)
        /* Récupération de l'historique asynchrone */
        .then(result => this.readAsyncHistory(result))
        .then((asyncData: Array<IHistoryAsyncElement>) => {
          if (data.granularity == 15 || (syncData[0] && syncData[0].timestamp == data.beginDate)) {
            return asyncData;
          }

          this.$log.debug('First requested timestamp not available !');

          let firstSyncTimestamp: number;
          /* Si la date de la première donnée synchrone ne correspond pas à celle demandée (historique incomplet) */
          if ((asyncData.length && !syncData.length) || (asyncData.length && asyncData[0].timestamp < syncData[0].timestamp)) {
            /* Si l'historique asynchrone comporte des données, on va récupérer une donnée synchrone juste avant le premier asynchrone */
            let firstDate = new Date(asyncData[0].timestamp);
            let firstMinutes = firstDate.getMinutes();
            let firstHours = firstDate.getHours();
            firstSyncTimestamp = firstDate.setHours(firstHours - (firstHours % (15 / 60)), firstMinutes - (firstMinutes % 15), 0, 0);
          } else if (syncData.length) {
            /* Si l'historique asynchrone est vide, on rajoute une donnée synchrone par défaut avec un timestamp inférieur */
            firstSyncTimestamp = syncData[0].timestamp - 15 * 60 * 1000;
          } else {
            return asyncData;
          }

          let frame = [0, this.utils.timestampToSeconds(firstSyncTimestamp), this.utils.timestampToSeconds(firstSyncTimestamp), 15];
          return this.protocol
            .sendCommand('Q_HISTO', frame, true)
            .then(() => {
              return this.readSyncHistory(firstSyncTimestamp, data.theoricalEndDate, data.granularity);
            })
            .then((sync: Array<IHistorySyncElement>) => {
              let firstSync;
              if (!sync.length) {
                this.$log.debug('No sync element available before first async !');
                if (syncData.length) {
                  firstSync = { position: syncData[0].position, index: 0, timestamp: firstSyncTimestamp };
                  syncData.unshift(firstSync);
                  this.$log.debug('No async history available, adding default first sync element: ' + JSON.stringify(firstSync));
                }

              } else {
                firstSync = sync[0];
                this.$log.debug('Sync element found: ' + JSON.stringify(firstSync));
                /* On considère que l'index du premier élément synchrone correspond à 0 pour obtenir notre delta */
                firstSync.index = 0;
                syncData.unshift(firstSync);
              }

              return asyncData;
            });
        })

        .then((asyncData: Array<IHistoryAsyncElement>) => {
          this.$log.debug('Received async history: ' + JSON.stringify(asyncData));

          if (!asyncData.length && !syncData.length) {
            this.$log.debug('No history available at all');
            return;
          }

          if (data.granularity == 15) {
            /* Cas spéficique d'un historique journée */
            let fullData = (<Array<IHistorySyncElement | IHistoryAsyncElement>>syncData).concat(asyncData);
            return fullData
              .map((value, index) => {
                /* On extrait juste le timestamp et l'index pour traiter plus rapidement */
                return { index, timestamp: value.timestamp };
              })
              .sort((a, b) => {
                /* On trie suivant le timestamp */
                return a.timestamp - b.timestamp;
              })
              .map(value => {
                /* On retourne le tableau complet suivant l'index trié */
                return fullData[value.index];
              });

          } else {
            let lastIndex: number, lastPosition: number, lastTimestamp: number;
            let firstData = <IHistorySyncElement | IHistoryAsyncElement>{};

            if (!syncData[0]) {
              /* Pour un historique non quotidien, on oblige à avoir au moins un élément synchrone */
              this.$log.debug('No sync history available, required for history other than a day !');
              return;
            }

            if (syncData[0].timestamp == data.beginDate) {
              firstData = syncData.splice(0, 1)[0];
              lastTimestamp = firstData.timestamp;
            } else {
              if (asyncData[0] && asyncData[0].timestamp < syncData[0].timestamp) {
                firstData = asyncData[0];
              } else {
                firstData = syncData.splice(0, 1)[0];
              }

              /* On force l'index à 0 après avoir récupéré les autres valeurs de départ */
              firstData.index = 0;
            }

            lastIndex = firstData.index;
            lastPosition = firstData.position;

            if (!lastTimestamp) {
              /* Si le timestamp de départ n'est pas défini, c'est qu'on ne démarre pas à la date souhaitée */
              let beginDate = new Date(firstData.timestamp);
              if (data.granularity == 43200) {
                beginDate.setDate(1);
                lastTimestamp = beginDate.setHours(0, 0, 0, 0);
              } else {
                let beginHours = beginDate.getHours();
                let beginMinutes = beginDate.getMinutes();
                lastTimestamp = beginDate.setHours(beginHours - (beginHours % (data.granularity / 60)),
                  beginMinutes - (beginMinutes % data.granularity), 0, 0);
              }
            }

            return syncData
              .map((value: IHistorySyncElement, syncIndex: number, array: Array<IHistorySyncElement>) => {
                let computedValue: IHistoryComputedElement = {
                  timestamp: lastTimestamp,
                  totalVolume: 0,
                  detailedVolumes: {
                    0x01: 0,
                    0x02: 0,
                    0x03: 0
                  }
                };

                let i = 0;
                while (asyncData[i] && asyncData[i].timestamp <= value.timestamp) {
                  /* La valeur finale de i correspondra au nombre d'éléments à récupérer */
                  i++;
                }

                computedValue = asyncData
                  .splice(0, i)
                  .reduce((computedValue, frame: IHistoryAsyncElement) => {
                    let indexDelta = frame.index - lastIndex;

                    computedValue.detailedVolumes[lastPosition] += indexDelta;
                    lastIndex = frame.index;
                    lastPosition = frame.position;

                    return computedValue;
                  }, computedValue);

                let previousIndex = syncIndex > 0 ? array[syncIndex - 1].index : firstData.index;
                computedValue.totalVolume += value.index - previousIndex;
                computedValue.detailedVolumes[lastPosition] += value.index - lastIndex;

                lastIndex = value.index;
                lastPosition = value.position;
                lastTimestamp = value.timestamp;

                return computedValue;
              });
          }
        })

        .then((computedData) => {
          this.$log.debug('Computed history: ' + JSON.stringify(computedData));

          /* On écrit les données dans la bdd */
          if (!bddData) {
            let keyParams;
            switch (data.granularity) {
              case 15:
                keyParams = '::day::' + data.beginDate;
                break;
              case 1440:
                keyParams = '::week::' + data.beginDate;
                break;
              case 10080:
                keyParams = '::month::' + data.beginDate;
                break;
              case 43200:
                keyParams = '::year::' + data.beginDate;
                break;
              default:
            }

            bddData = {
              type: 'history',
              schemaVersion: '1',
              _id: 'vanne::' + serialNumber + '::history' + keyParams
            };
          }

          /* Si le jour de fin est inférieur au jour actuel + 1, les données sont complètes */
          if (new Date(data.theoricalEndDate).setHours(0, 0, 0, 0) < (new Date().setHours(0, 0, 0, 0)) + 86400000) {
            bddData.complete = true;
          } else {
            bddData.complete = false;
          }

          this.$log.info('History complete ? ' + bddData.complete);
          bddData.values = computedData;

          return this.db
            .createDocument(bddData)
            .then(() => {
              return computedData;
            });
        });
    }

    /**
     * Récupère les données asynchrones demandées tant que trame != 0
     * @param {Array<IHistoryAsyncElement>} [parsedData] - Tableau des données déjà reçues
     * @returns {Promise} Promise de toutes les données asynchrones
     */
    private readAsyncHistory(parsedData?: Array<IHistoryAsyncElement>): ng.IPromise<Array<IHistoryAsyncElement>> {
      parsedData = parsedData || [];

      return this.protocol
        .readData('V_HISTO_ASYNC', true)
        .then(rawFrame => {
          let dataView = this.protocol.rawToDataView('V_HISTO_ASYNC', rawFrame);

          let timestamp = dataView.getUint32(8, this.protocol.littleEndian);
          if (!timestamp) {
            /* Si le timestamp est égal à 0, alors on a tout récupéré et on retourne */
            this.protocol.toggleReception(false);
            return parsedData;
          }

          let first = dataView.getUint8(0);
          parsedData.push({
            frameType: HistoryType.Asynchronous, // Asynchrone
            timestamp: timestamp * 1000, // s => ms
            position: first & 0x03,
            overlap: first & 0x04,
            storage: first & 0x08 ? true : false,
            action: first & 0xF0,
            rawDefault: this.numberFromBuffer(dataView.buffer, 1, 3),
            defaults: this.parseVanneErrors(this.numberFromBuffer(dataView.buffer, 1, 3)),
            index: dataView.getUint32(4, this.protocol.littleEndian)
          });

          return this.readAsyncHistory(parsedData);
        });
    }

    /**
     * Crée une requête pour un document relatif à une vanne
     * @param {String} serialNumber - Numéro de série de la vanne
     * @param {String[]} [objNames] - Paramètres à rajouter à la clé du document
     * @returns {Promise} Promise du document demandé
     */
    private getVanneDoc(serialNumber: string, objNames?: Array<string>): ng.IPromise<{}> {
      let endParams = objNames && objNames.reduce((previousValue, currentValue) => {
        return previousValue + '::' + currentValue;
      }, '');

      endParams = endParams || '';
      let fullKey = 'vanne::' + serialNumber + endParams;
      this.$log.debug('Getting vanne doc: ' + fullKey);

      return this.db.getDocument(fullKey);
    }

    /**
     * Reset les variables liées à la vanne connectée et sélectionnée et renvoie vers le scan
     */
    private resetConnection() {
      this.connectedValveSerial = this.selectedValveSerial = null;
      this.$state.go('scanner');
    }

    /**
     * Convertit la valeur reçue de la vanne pour la température suivant la formule établie
     * @param {Number} hexa - Valeur hexa image de la température
     * @returns {Number} Valeur calculée de la température
     */
    private temperatureFromHexa(hexa: number): number {
      return hexa * 0.5 + this.VANNE_CONSTS.minTemp;
    }

    /**
     * Convertit la valeur reçue de la vanne pour la tension suivant la formule établie
     * @param {Number} hexa - Valeur hexa image de la tension
     * @returns {Number} Valeur calculée de la tension
     */
    private tensionFromHexa(hexa: number): number {
      return hexa / 10;
    }

    /**
     * Retourne une valeur parsée depuis le nombre d'octets spéficiés sur un arrayBuffer
     * @param {ArrayBuffer} arrayBuffer - ArrayBuffer contenant les données brutes
     * @param {Number} offset - Offset à partir duquel parser la valeur dans le ArrayBuffer
     * @param {Number} length - Longueur en octets sur laquelle parser la valeur
     * @returns {Number} Valeur parsée
     */
    private numberFromBuffer(arrayBuffer: ArrayBuffer, offset: number, length: number): number {
      let typedArray = new Uint8Array(arrayBuffer, offset, length);
      let array: Array<number> = Array.prototype.slice.call(typedArray);

      return this.arrayToNumber(array);
    }
  }

  angular
    .module('eValve.vanne')
    .service('vanne', Vanne);
}
