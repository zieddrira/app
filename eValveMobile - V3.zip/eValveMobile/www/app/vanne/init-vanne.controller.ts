namespace eValve.vanne {
  'use strict';

  export class InitVanneController {
    fields: any;
    model: any;
    k: Array<{ code: number, value: number }>;
    optionsK: Array<{ name: number, value: string }>;

    static $inject: Array<string> = ['vanne', '$state', '$ionicPopup', 'VANNE_CONSTS', '$log'];
    constructor(
      private vanne: IVanne,
      private $state: ng.ui.IStateService,
      private $ionicPopup: ionic.popup.IonicPopupService,
      private VANNE_CONSTS: any,
      private $log: ng.ILogService

    ) {
      this.k = VANNE_CONSTS.k;
      this.setInitForm();
    }

    /**
     * Initialise le numéro de série et le code de connexion de la vanne connectée
     */
    initValve() {
      if (this.model.serialNumber == '000000000') {
        return this.$ionicPopup.alert({
          title: 'Numéro de série incorrect',
          template: `Vous ne pouvez pas spécifier "000000000" comme numéro de série`
        });
      }
      this.vanne
        .initValve(this.model['serialNumber'], this.model['connectionCode'], this.model['initialIndex'], this.model['k'])
        .then((config: IValveConfig) => this.$state.go('vanne.details', { valveSerial: config.serialNumber }))
        .catch(error => {
          let title;
          if (error == 'ERROR_WRITE_VALVE_TO_USER') {
            title = `Erreur lors de la mise à jour des accès de l'utilisateur`;
          } else if (error == 'ERROR_WRITE_CODE') {
            title = `Erreur lors de l'enregistrement du code`;
          } else {
            title = `Une erreur est survenue`;
          }

          this.$ionicPopup.alert({
            title,
            okType: 'button-assertive',
            template: JSON.stringify(error)
          });
        });
    }

    /**
     * Demande confirmation de l'abandon et déconnecte la vanne le cas échéant
     */
    abandon() {
      this.$ionicPopup
        .confirm({
          title: 'Arrêt de la configuration',
          template: `Etes-vous sûr(e) de vouloir arrêter la configuration ? Vous serez déconnecté(e) de la vanne.`,
          okText: 'Arrêter',
          cancelText: 'Annuler'
        })
        .then(result => {
          if (!result) {
            return;
          }

          return this.vanne.disconnect()
            .finally(() => this.$state.go('dashboard'));
        })

        .catch(error => {
          return this.$ionicPopup
            .alert({
              title: 'Une erreur est survenue',
              okType: 'button-assertive',
              template: JSON.stringify(error)
            })
            .then(() => this.$state.go('dashboard'));
        });
    }

    /**
     * Initialise le formulaire de saisie du numéro de série et du code de connexion
     */
    setInitForm() {
      this.model = {};
      this.fields = [
        {
          key: 'serialNumber',
          type: 'floating-input',
          templateOptions: {
            type: 'text',
            placeholder: `Numéro de série`,
            label: `Numéro de série`,
            required: true,
            maxlength: 9,
            minlength: 9
          },
          validation: {
            messages: {
              maxlength: () => 'Le numéro de série doit être composé de 9 caractères',
              minlength: () => 'Le numéro de série doit être composé de 9 caractères'
            }
          }
        },
        {
          key: 'connectionCode',
          type: 'floating-input',
          templateOptions: {
            type: 'text',
            label: 'Code de connexion',
            placeholder: 'Code de connexion',
            required: true,
            maxlength: 10,
            minlength: 10
          },
          validation: {
            messages: {
              maxlength: () => 'La longueur du code de connexion doit être de 10 caractères',
              minlength: () => 'La longueur du code de connexion doit être de 10 caractères'
            }
          }
        },
        {
          key: 'initialIndex',
          type: 'floating-input',
          templateOptions: {
            type: 'text',
            label: 'Index initial (L)',
            placeholder: 'Index initial (L)',
            required: true
          }
        },
        {
          key: 'k',
          type: 'select',
          defaultValue: this.k[0].code.toString(),
          templateOptions: {
            label: 'Coefficient K',
            options: this.k.map(obj => ({ name: obj.value, value: (obj.code).toString() })),
            required: true,
          }
        }
      ];
    }
  }

  angular
    .module('eValve.vanne')
    .controller('InitVanneController', InitVanneController);
}
