namespace eValve.dashboard {
  'use strict';

  export class DashboardController {
    search: string;
    valves: [string, number][];
    valvesAlreadyConnected: string[];

    static $inject: Array<string> = ['$scope', '$state', '$ionicPopup', 'vanne', 'bluetooth', 'park', '$log'];
    constructor(
      private $scope: ng.IScope,
      private $state: ng.ui.IStateService,
      private $ionicPopup: ionic.popup.IonicPopupService,
      private vanne: eValve.vanne.IVanne,
      private bluetooth: eValve.communication.IBluetooth,
      private park: eValve.park.IParkService,
      private $log: ng.ILogService
    ) {
      /* Vérifie que le bluetooth est activé et notifie via une popup dans le cas contraire */
      this.valvesAlreadyConnected = [];
      this.bluetooth
        .isEnabled()
        .catch(() => {
          this.$ionicPopup.alert({
            title: 'Bluetooth désactivé',
            template: 'Veuillez activer le bluetooth dans les réglages de votre appareil'
          });
        });
      $scope.$on('$ionicView.beforeEnter', () => this.initVannesList());
    }

    /**
     * Récupère la liste des vannes et initialise le champ de recherche
     */
    initVannesList() {
      this.search = undefined;

      this.park
        .getAllValves()
        .then((vannes: string[]) => {
          this.valves = Array.from(this.park.loggedUser.valves).filter(value => vannes.includes(value[0]));

        });

      this.park.loggedUser.valves.forEach((value, serial) => {
        if (value !== 0) {
          this.valvesAlreadyConnected.push(serial);
        }
      });
    }

    /**
     * Marque la vanne en paramètre comme sélectionnée et redirige vers le dashboard
     * @param {string} serialNumber - Numéro de série de la vanne sélectionnée
     */
    selectVanne(serialNumber: string) {
      this.vanne.initAccessedCharacteristics();

      if (this.valvesAlreadyConnected.includes(serialNumber)) {
        /* Gère l'affichage des liens dans le menu */
        this.vanne.selectedValveSerial = serialNumber;
        this.$state.go('vanne.details', { valveSerial: serialNumber });
      } else {
        this.$ionicPopup.alert({
          title: 'Vanne non connectée :',
          template: `La vanne "` + serialNumber + `" n'a jamais été connectée à l'appareil, de ce fait vous n'avez pas accès à ses données`,
          okText: 'Fermer',
          okType: 'button-assertive'
        });
      }
    }
  }

  angular
    .module('eValve.dashboard')
    .controller('DashboardController', DashboardController);
}
