namespace eValve.dashboard {
  'use strict';

  angular
    .module('eValve.dashboard', [])
    .run(initModule);

  initModule.$inject = ['routerHelper'];
  function initModule(routerHelper) {
    routerHelper.configureStates(getStates());
  }

  function getStates() {
    return [
      {
        /* Accueil principal */
        state: 'dashboard',
        config: {
          url: '/dashboard',
          views: {
            '': {
              templateUrl: 'app/dashboard/dashboard.html',
              controller: 'DashboardController as dashboard'
            }
          }

          // resolve: {
          //   mustBeAuth: function ($q, $rootScope) {
          //     return angular.isDefined($rootScope.user) ? $q.resolve() : $q.reject('AUTH_REQUIRED');
          //   }
          // }
        }
      }
    ];
  }

}
