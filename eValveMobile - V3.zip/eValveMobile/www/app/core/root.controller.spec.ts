declare var ngDescribe;

ngDescribe({
  name: 'RootController',
  module: 'eValve.core',
  element: '<div ng-controller="RootController as ctrl"></div>',
  inject: ['auth', '$httpBackend'],
  mock: {
    'eValve.auth': {},
    'eValve.park': {},
    'eValve.vanne': {
      vanne: {
        connectedValveSerial: '123456789',
        disconnect: ($q) => $q.resolve()
      }
    }
  },

  tests: (deps) => {

    beforeEach(() => {
      deps.$httpBackend.expectGET('app/auth/login.html').respond(500);
      spyOn(deps.auth, 'logout');
    });

    describe('logout()', () => {
      it('calls auth.logout() method', () => {
        let ctrl = deps.element.controller();
        ctrl.logout();
        ctrl.$rootScope.$apply();
        expect(deps.auth.logout).toHaveBeenCalled();
        // expect(ctrl.connectedValveSerial).toEqual('123456789');
      });
    });
  }
});
