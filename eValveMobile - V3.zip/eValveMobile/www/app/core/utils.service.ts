namespace eValve.core {
  'use strict';

  export interface IUtils {
    bcdToNumber(value: number): number;
    numberToBcd(value: number): number;
    getMondayTimestamp(date: Date): number;
    timestampToSeconds(timestamp: number): number;
    getVerboseErrorMessage(error: any): string;
    isObject(obj): boolean;
  }

  export class Utils implements IUtils {
    // static $inject: Array<string> = [];
    // constructor() {}

    /**
     * Transforme un nombre sous forme décimale en sa forme bcd
     * @param {Number} value - Nombre sous forme décimale
     * @returns {Number} Nombre sous forme bcd
     */
    numberToBcd(value: number) {
      let tens = value / 10;
      let units = value % 10;
      return (tens << 4) | units;
    }

    /**
     * Transforme un nombre sous bcd en sa forme décimale
     * @param {Number} value - Nombre sous forme bcd
     * @returns {Number} Nombre sous forme décimale
     */
    bcdToNumber(value: number) {
      let tens = value >> 4;
      let units = value & 0x0F;
      return (tens * 10) + units;
    }

    /**
     * Retourne le timestamp correspondant au lundi minuit de la semaine du jour passé en paramètre
     * @param {Date} date - Date dont on veut récupérer le lundi
     * @returns {Number} Timestamp correspondant au lundi minuit
     */
    getMondayTimestamp(date: Date) {
      date.setHours(0, 0, 0, 0);
      let correctedDay = date.getDay() - 1; // Par défaut, dimanche = 0
      let padding = correctedDay == -1 ? 6 : correctedDay;
      return date.getTime() - (padding * 86400000);
    }

    /**
     * Convertit un timestamp des millisecondes en secondes
     * @param {Number} timestamp - Timestamp en millisecondes
     * @returns {Number} Timestamp en secondes
     */
    timestampToSeconds(timestamp: number): number {
      return Math.floor(timestamp / 1000);
    }

    /**
     * Gère un objet erreur pour renvoyer un message efficace
     *
     * @param {*} error - Objet erreur quelconque
     * @returns {Object} : Renvoie une string si possible sinon l'objet
     */
    getVerboseErrorMessage(error: any): string {
      if (this.isObject(error)) {
        // this.$log.debug('Verbose error : ' + JSON.stringify(error));
        return error.errorMessage ? error.errorMessage : JSON.stringify(error);
      }
      return error;
    }

    /**
     * Vérifie si le paramètre est un objet
     *
     * @param {any} obj - Variable à vérifier
     * @returns boolean
     */
    isObject(obj): boolean {
      return obj === Object(obj);
    }
  }

  angular
    .module('eValve.core')
    .service('utils', Utils);
}
