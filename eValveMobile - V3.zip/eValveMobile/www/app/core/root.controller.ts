namespace eValve.core {
  'use strict';

  export class RootController {
    static $inject: Array<string> = ['$rootScope', 'vanne', 'auth', '$state', 'park', '$ionicLoading', '$log'];
    constructor(
      private $rootScope: eValve.core.IAppRootScope,
      private vanne: eValve.vanne.IVanne,
      private auth: eValve.auth.IAuth,
      private $state: ng.ui.IStateService,
      private park: eValve.park.IParkService,
      private $ionicLoading: ionic.loading.IonicLoadingService,
      private $log: ng.ILogService
    ) {
      $rootScope.appVersion = '2.1.0';
    }

    get connectedValveSerial() { return this.vanne.connectedValveSerial; }
    get selectedValveProtocolVersion() { return this.vanne.selectedValveProtocolVersion; }

    get selectedValveSerial() { return this.vanne.selectedValveSerial; }
    set selectedValveSerial(val) { this.vanne.selectedValveSerial = val; }

    get isUserAdmin() { return this.park.loggedUser && this.park.loggedUser.isAdmin; }
    get isLoggedIn() { return this.park.loggedUser; }

    /**
     * Déconnecte l'utilisateur et le redirige sur le login
     */
    logout() {
      this.$ionicLoading.show();
      this.vanne
        .disconnect()
        .catch(error => this.$log.error(error))

        .then(() => {
          this.auth.logout();
          this.$state.go('login');
        })

        .finally(() => this.$ionicLoading.hide());
    }
  }

  angular
    .module('eValve.core')
    .controller('RootController', RootController);
}
