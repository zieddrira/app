namespace eValve.core {
  'use strict';

  function ctToggle() {
    return {
      restrict: 'A',
      scope: {
        selected: '=ctToggle'
      },
      bindToController: true,
      controllerAs: 'ctToggle',
      controller: function () {
        let vm = this;
        vm.select = select;
        vm.selected = undefined;

        ///////////////

        /**
         * Sette la sélection à l'id correspondant
         * @param {number} id
         */
        function select(id) {
          if (vm.selected != undefined && vm.selected == id) {
            delete vm.selected;
            return;
          }

          vm.selected = id;
        }
      }
    };
  }

  function ctToggleButton() {
    return {
      restrict: 'E',
      require: '^ctToggle',
      transclude: true,
      replace: true,
      scope: {
        value: '='
      },
      template: '<button class="button button-positive" ng-class="{\'button-outline\': selected != value}" ng-transclude></button>',
      link: function (scope, element, attrs, toggleController) {
        scope.$watch(function () { return toggleController.selected; }, function (newVal) {
          scope.selected = newVal;
        });

        element.on('click', () => {
          scope.$apply(() => {
            toggleController.select(scope.value);
          });
        });
      }
    };
  }

  angular
    .module('eValve.core')
    .directive('ctToggle', ctToggle)
    .directive('ctToggleButton', ctToggleButton);
}
