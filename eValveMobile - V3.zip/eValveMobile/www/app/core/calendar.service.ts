namespace eValve.core {
  'use strict';

  export interface ICalendar {
    days: Array<string>;
    frequencies: Array<string>;

    convertTimestamp(timestamp: number): string;
  }

  export class Calendar implements ICalendar {
    private _days: Array<string> = ['Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi', 'Dimanche'];
    private _frequencies: Array<string> = ['hebdomadaire', 'mensuelle'];

    // static $inject: Array<string> = [];
    // constructor() {}

    /**
     * Retourne la liste des jours de la semaine
     * @returns {string[]} jours
     */
    get days(): string[] { return this._days; }

    /**
     * Retourne les fréquences de purge possibles
     * @returns {string[]}
     */
    get frequencies(): string[] { return this._frequencies; }

    /**
     * Convertit un timestamp en datetime-local
     * @param {number} timestamp
     * @returns {string} datetime-local
     */
    convertTimestamp(timestamp: number): string {
      // https://gist.github.com/kmaida/6045266

      let d = new Date(timestamp),
        yyyy = d.getFullYear(),
        mm = ('0' + (d.getMonth() + 1)).slice(-2),	// Months are zero based. Add leading 0.
        dd = ('0' + d.getDate()).slice(-2),			// Add leading 0.
        hh = ('0' + d.getHours()).slice(-2),
        h = hh,
        min = ('0' + d.getMinutes()).slice(-2),		// Add leading 0.
        time: string;

      // ie: 2013-02-18, 8:35 AM
      time = yyyy + '-' + mm + '-' + dd + 'T' + h + ':' + min + ':00';
      // console.log(time);

      return time;
    }

  }

  angular
    .module('eValve.core')
    .service('calendar', Calendar);
}
