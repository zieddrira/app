describe('Utils', () => {
  let utils: eValve.core.Utils;

  beforeAll(() => {
    utils = new eValve.core.Utils();
  });

  describe('numberToBcd', () => {
    it('transforms integer into its bcd representation', () => {
      expect(utils.numberToBcd(45)).toEqual(0b01000101);
    });
  });

  describe('bcdToNumber', () => {
    it('transforms bcd number into its base 10 form', () => {
      expect(utils.bcdToNumber(0b01000101)).toEqual(45);
    });
  });

  describe('getMondayTimestamp', () => {
    it('returns the timestamp of monday 12pm for date param week', () => {
      // Passed date : Tue Nov 01 2016 23:22:35 GMT+0100 (CET)
      // Must equals : new Date(2016, 9, 31) (month starts at 0 : 9 == october)
      expect(utils.getMondayTimestamp(new Date(1478038955813))).toEqual(new Date(2016, 9, 31).getTime());
    });
  });

  describe('timestampToSeconds', () => {
    it('converts a milliseconds timestamp to a second timestamp', () => {
      expect(utils.timestampToSeconds(1478038955813)).toEqual(1478038955);
    });
  });

  describe('getVerboseErrorMessage', () => {
    it('returns the message from the object error if present', () => {
      let errorMessage = 'ERROR';
      expect(utils.getVerboseErrorMessage({ errorMessage: errorMessage })).toEqual(errorMessage);
    });

    it('returns the entire stringified error object if no errorMessage value', () => {
      let error = { anotherValue: 'tutu' };
      expect(utils.getVerboseErrorMessage(error)).toEqual(JSON.stringify(error));
    });

    it('returns the passed error if not an object', () => {
      let error = 14;
      expect(utils.getVerboseErrorMessage(error)).toEqual(JSON.stringify(error));
    });
  });

});
