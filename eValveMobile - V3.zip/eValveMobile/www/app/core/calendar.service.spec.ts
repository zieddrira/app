describe('Calendar', () => {
  let calendar: eValve.core.Calendar;

  beforeAll(() => {
    calendar = new eValve.core.Calendar();
  });

  describe('convertTimestamp', () => {
    it('converts a timestamp to datetime-local format', () => {
      // Passed date : Tue Nov 01 2016 23:22:35 GMT+0100 (CET)
      expect(calendar.convertTimestamp(1478038955813)).toEqual('2016-11-01T23:22:00');
    });
  });

});
