namespace eValve.core {
  'use strict';

  export interface IAppRootScope extends ng.IRootScopeService {
    appVersion: string;
    user: string;
  }

  angular
    .module('eValve.core', [
      'ionic',
      'ngCordova',
      'ngCouchbaseLite',
      'ngMessages',
      'formlyIonic',
      'highcharts-ng',
      'ngIOS9UIWebViewPatch',

      'blocks.router'
    ])
    .run(initDb);

  initDb.$inject = ['$ionicPlatform', 'db'];
  function initDb($ionicPlatform: ionic.platform.IonicPlatformService, db: eValve.core.IDb) {
    $ionicPlatform.ready(() => db.startConnection());
  }
}
