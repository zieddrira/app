namespace eValve.core {
  'use strict';

  declare var cblite;
  declare var emit;

  export interface IDb {
    createDocument(document: any): ng.IPromise<any>;
    deleteUserByUserName(username: string): ng.IPromise<any>;
    deleteValve(serialNumber: string): ng.IPromise<any[]>;
    getAllValves(): ng.IPromise<string[]>;
    getDocument(key: string): ng.IPromise<any>;
    getUserByUsername(username: string): ng.IPromise<eValve.park.IUser>;
    getUsers(): ng.IPromise<{ username: string, isAdmin: boolean }[]>;
    getVannes(): ng.IPromise<string[]>;
    startConnection(): void;
    storeUser(user: eValve.park.IUser): ng.IPromise<any>;
    storeVanne(vanne: eValve.vanne.IValve): ng.IPromise<any>;
    storeVanneCode(serialNumber: string, document: eValve.park.IValveCode): ng.IPromise<any>;
    storeVanneGeoloc(geoloc: eValve.vanne.IValveGeoloc, serialNumber: string): ng.IPromise<any>;
    storeVanneProg(prog: eValve.vanne.IValveProgram, serialNumber: string): ng.IPromise<any[]>;
    storeVanneStats(stats: eValve.vanne.IValveStats, serialNumber: string): ng.IPromise<any>;
    storeVanneTempExt(tempExt: eValve.vanne.IValveTempExt, serialNumber: string): ng.IPromise<any>;
    storeMacAddress(vanne: eValve.vanne.IValveInit): ng.IPromise<any>;
    getSerialNumberFromMacAddress(macAddress: string): ng.IPromise<string>;
    getMacAddressFromSerialNumber(serialNumber: string): ng.IPromise<string>;
  }

  export class Db implements IDb {
    private _database;

    static $inject: Array<string> = ['$couchbase', '$q', '$log', '$rootScope'];
    constructor(
      private $couchbase: any,
      private $q: ng.IQService,
      private $log: ng.ILogService,
      private $rootScope: ng.IRootScopeService
    ) { }

    /**
     * Initialise la connexion avec la base de données
     */
    startConnection() {
      if (!window['cblite']) {
        alert('Couchbase Lite is not installed!');
      } else {
        cblite.getURL((err, url) => {
          if (err) {
            alert('There was an error getting the database URL');
            return;
          }

          this._database = new this.$couchbase(url, 'evalve');
          this._database
            .createDatabase()
            .catch(error => this.$log.error(error))

            .then(result => {
              let views = {
                vannes: {
                  map: function (doc) {
                    if (doc.type == 'vanne' && doc.serialNumber) {
                      emit(doc.serialNumber, null);
                    }
                  }.toString()
                },
                macAddresses: {
                  map: function (doc) {
                    if (doc.type == 'macAddress') {
                      emit(doc.serialNumber, null);
                    }
                  }.toString()
                },
                users: {
                  map: function (doc) {
                    if (doc.type == 'user') {
                      emit({ isAdmin: doc.isAdmin, hidden: doc.hidden }, null);
                    }
                  }.toString()
                },
                allValves: {
                  map: function (doc) {
                    if (doc.type == 'code') {
                      emit(doc._id, null);
                    }
                  }.toString()
                }
              };

              return this._database
                .getDesignDocument('_design/evalve')
                .catch(error => {
                  if (error.status != 404) {
                    throw error;
                  }
                })
                .then(document => {
                  if (document) {
                    this.$log.info(`Le design document existe déjà`);
                    document.views = views;
                  } else {
                    this.$log.info(`Le design document n'existe pas encore`);
                    document = { views };
                  }

                  return document;
                })
                .then(document => {
                  return this._database.makeRequest('PUT', url + 'evalve' + '/_design/evalve', {}, document);
                });
              // return this._database.createDesignDocument('_design/evalve', views);
            })

            .then(() => {
              this._database.listen();

              this.$rootScope.$emit('database:initialized');
              this.$log.info('Database initialized');
            })

            .then(() => {
              this
                .getDocument('database::initialized')
                .catch(error => {
                  if (error.status == 404) {
                    // this.storeVanne(VANNE_MOCK.state);
                    // this.storeVanneCode(VANNE_MOCK.state.serialNumber, { code: VANNE_MOCK.state.connectionCode });
                    // this.storeVanneGeoloc(VANNE_MOCK.geoloc, VANNE_MOCK.state.serialNumber);
                    // this.storeVanneProg(VANNE_MOCK.prog, VANNE_MOCK.state.serialNumber);
                    // this.storeVanneTempExt(VANNE_MOCK.tempExt, VANNE_MOCK.state.serialNumber);

                    this.storeUser({
                      username: '9UC6YcRitt',
                      password: 'jQdoy35Kj4',
                      hidden: true,
                      isAdmin: true,
                      userType: 1,
                      valves: new Map<string, number>(),
                      connectionCodes: {}
                    });

                    this.createDocument({ _id: 'database::initialized', version: 1 });
                  }
                })
                .then(() => {
                  let deprecatedExampleValves = [
                    '68352f39-5366-4666-8268-e45490ccbb0d',
                    '4a20b48f-5fb3-454d-95ab-9c6737e0d1ec',
                    '24b62864-9df3-40f6-9bb0-78cbf669e396',
                    'a170a634-4eb4-4d9a-ab5f-7eb8b1a5c04f'
                  ];

                  /* Suppression des vannes temporaires si elles existent */
                  deprecatedExampleValves.forEach(serialNumber => this.deleteValve(serialNumber));
                });
            })

            .catch(error => {
              this.$log.error(error);
              // There was an error creating the database
            });
        });
      }
    }

    /**
     * Enregistre une nouvelle vanne en base de données
     * @param {IValve} vanne
     * @returns {Promise} promise de la création du document
     */
    storeVanne(vanne: eValve.vanne.IValve): ng.IPromise<any> {
      let dbProps = {
        type: 'vanne',
        schemaVersion: '1',
        _id: 'vanne::' + vanne.serialNumber
      };

      angular.merge(vanne, dbProps);
      return this.createDocument(vanne);
    }

    /**
     * Récupère la liste numéros de série de toutes les vannes
     * @returns {Promise<string[]>} Promise des numéros de série des vannes
     */
    getVannes(): ng.IPromise<string[]> {
      let serialNumbers = [];
      let deferred = this.$q.defer<string[]>();

      this._database
        .queryView('_design/evalve', 'vannes')
        .then(result => {
          result.rows.forEach(details => {
            serialNumbers.push(details.id.split('::')[1]);
          });
          deferred.resolve(serialNumbers);
        })

        .catch(error => {
          this.$log.error(error);
          deferred.reject(error);
        });

      return deferred.promise;
    }

    /**
     * Enregistre le programme d'une vanne en base de données
     * @param {IValveProgram} prog - Programme à sauvegarder
     * @param {String} serialNumber - Numéro de série de la vanne
     * @returns {Promise} Promise de la création du document
     */
    storeVanneProg(prog: eValve.vanne.IValveProgram, serialNumber: string): ng.IPromise<any[]> {
      let fullProps = {
        type: 'prog',
        schemaVersion: '1',
        _id: 'vanne::' + serialNumber + '::prog'
      },
        manualProps = {
          type: 'prog::manual',
          schemaVersion: '1',
          _id: 'vanne::' + serialNumber + '::prog::manual'
        },
        unitsProps = {
          type: 'prog::units',
          schemaVersion: '1',
          _id: 'vanne::' + serialNumber + '::prog::units'
        };

      let fullProg = angular.merge({}, prog, fullProps);
      let manual = angular.merge({}, prog.manual, manualProps);
      let units = angular.merge({}, prog.units, unitsProps);

      return this.$q.all([this.createDocument(fullProg), this.createDocument(manual), this.createDocument(units)]);
    }

    /**
     * Enregistre les stats d'une vanne en base de données
     * @param {IValveStats} stats
     * @param {String} serialNumber - Numéro de série de la vanne
     * @returns {Promise} Promise de la création du document
     */
    storeVanneStats(stats: eValve.vanne.IValveStats, serialNumber: string): ng.IPromise<any> {
      let dbProps = {
        type: 'stats',
        schemaVersion: '1',
        _id: 'vanne::' + serialNumber + '::stats'
      };

      angular.merge(stats, dbProps);
      return this.createDocument(stats);
    }

    /**
     * Enregistre le code de connexion à une vanne dans une entrée spéficique
     * @param {string} serialNumber Numéro de série de la vanne
     * @param {IValveCode} document Document avec le code de connexion
     * @returns {Promise} Promise de la création du document
     */
    storeVanneCode(serialNumber: string, document: eValve.park.IValveCode): ng.IPromise<any> {
      let dbProps = {
        type: 'code',
        schemaVersion: '1',
        _id: `vanne::${serialNumber}::code`
      };

      angular.merge(document, dbProps);
      return this.createDocument(document);
    }

    /**
     * Enregistre un utilisateur dans la base de données
     * @param {IUser} user Utilisateur à enregistrer
     * @returns {Promise} Promise de la création du document
     */
    storeUser(user: eValve.park.IUser): ng.IPromise<any> {
      let dbProps = {
        type: 'user',
        schemaVersion: '1',
        _id: 'user::' + user.username
      };

      angular.merge(user, dbProps);
      return this.createDocument(user)
        .then(result => {
          /* Si ajout d'un compte admin, suppression du compte "Apple" */
          if (user.isAdmin && !user.hidden) {
            this.deleteUserByUserName('9UC6YcRitt')
              .catch(error => error);
          }

          return result;
        });
    }

    /**
     * Retourne s'il existe l'utilisateur grâce à son username
     * @param {string} username Username de l'utilisateur
     * @returns {Promise} Promise de la récupération de l'utilisateur
     */
    getUserByUsername(username: string): ng.IPromise<eValve.park.IUser> {
      return this
        .getDocument('user::' + username)
        .then((user: eValve.park.IUser) => {
          /* Un Set est sérialisé dans la BDD en tant que tableau, on le retransforme en Set lors de la désérialisation */
          user.valves = new Map(user.valves);
          return user;
        });
    }

    /**
     * Retourne la liste des utilisateurs avec leur statut (admin?)
     * @returns {Promise<Object[]>} Promise de la liste des utilisateurs
     */
    getUsers(): ng.IPromise<{ username: string, isAdmin: boolean }[]> {
      let deferred = this.$q.defer();

      if (!this._database) {
        let initListenerFunction = this.$rootScope.$on('database:initialized', () => {
          initListenerFunction();
          deferred.resolve();
        });
      } else {
        deferred.resolve();
      }

      return deferred.promise
        .then(() => this._database.queryView('_design/evalve', 'users'))
        .then(result => {
          let users: any;
          users = result.rows
            .filter(doc => !doc.key.hidden)
            .map(doc => ({ username: doc.id.split('::')[1], isAdmin: doc.key.isAdmin }));

          /* Suppression de l'utilisateur caché (du coup result.rows devrait être vide) existant nécessaire pour le build IOS */
          if (!users.length) {
            this.deleteUserByUserName('9UC6YcRitt');
            this.$log.info('Test user deleted.');
          }

          return users;
        })
        .catch(error => {
          this.$log.error(error);
          throw error;
        });
    }

    /**
     * Supprime un utilisateur de la BDD à partir de son username
     * @param {string} username Nom de l'utilisateur à supprimer
     * @returns {Promise} Promise de la suppression de l'utilisateur
     */
    deleteUserByUserName(username: string): ng.IPromise<any> {
      return this
        .getUserByUsername(username)
        .then(document => this._database.deleteDocument(document._id, document._rev))
        .catch(error => {
          this.$log.error(error);
          throw error;
        });
    }

    /**
     * Supprime la vanne et toutes les entrées associées de la BDD
     * @param {string} serialNumber Numéro de série de la vanne à supprimer
     * @returns {Promise} Promise de la suppression de la vanne
     */
    deleteValve(serialNumber: string): ng.IPromise<any[]> {
      let errors = [];

      return this.getDocument(`vanne::${serialNumber}::prog`)
        .then(document => this._database.deleteDocument(document._id, document._rev))
        .catch(error => { errors.push(error); this.$log.error(error); })

        .then(() => this.getDocument(`vanne::${serialNumber}::prog::manual`))
        .then(document => this._database.deleteDocument(document._id, document._rev))
        .catch(error => { errors.push(error); this.$log.error(error); })

        .then(() => this.getDocument(`vanne::${serialNumber}::prog::units`))
        .then(document => this._database.deleteDocument(document._id, document._rev))
        .catch(error => { errors.push(error); this.$log.error(error); })

        .then(() => this.getDocument(`vanne::${serialNumber}::stats`))
        .then(document => this._database.deleteDocument(document._id, document._rev))
        .catch(error => { errors.push(error); this.$log.error(error); })

        .then(() => this.getDocument(`vanne::${serialNumber}::code`))
        .then(document => this._database.deleteDocument(document._id, document._rev))
        .catch(error => { errors.push(error); this.$log.error(error); })

        .then(() => this.getDocument(`vanne::${serialNumber}::geoloc`))
        .then(document => this._database.deleteDocument(document._id, document._rev))
        .catch(error => { errors.push(error); this.$log.error(error); })

        .then(() => this.getDocument(`vanne::${serialNumber}`))
        .then(document => this._database.deleteDocument(document._id, document._rev))
        .catch(error => { errors.push(error); this.$log.error(error); })

        .then(() => errors);
    }

    /**
     * Retourne la liste de toutes les vannes, même celles non vérifiées
     * @returns {Promise<string[]>} Promise de la liste des vannes
     */
    getAllValves(): ng.IPromise<string[]> {
      return this._database
        .queryView('_design/evalve', 'allValves')
        .then(result => {
          return result.rows.map(doc => doc.id.split('::')[1]);
        })
        .catch(error => {
          this.$log.error(error);
          throw error;
        });
    }

    /**
     * Enregistre les infos de géoloc d'une vanne en base de données
     * @param {IValveGeoloc} geoloc - Geoloc à sauvegarder
     * @param {String} serialNumber - Numéro de série de la vanne
     * @returns {Promise} Promise de la création du document
     */
    storeVanneGeoloc(geoloc: eValve.vanne.IValveGeoloc, serialNumber: string): ng.IPromise<any> {
      let dbProps = {
        type: 'geoloc',
        schemaVersion: '1',
        _id: 'vanne::' + serialNumber + '::geoloc'
      };

      angular.merge(geoloc, dbProps);
      return this.createDocument(geoloc);
    }

    /**
     * Enregistre les infos du capteur de température externe en base de données
     *
     * @param {eValve.vanne.IValveTempExt} tempExt - Infos à sauvegarder
     * @param {string} serialNumber - Numéro de série de la vanne
     * @returns {ng.IPromise<any>} Promise de la création du document
     *
     * @memberOf Db
     */
    storeVanneTempExt(tempExt: eValve.vanne.IValveTempExt, serialNumber: string): ng.IPromise<any> {
      let dbProps = {
        type: 'tempExt',
        schemaVersion: '1',
        _id: 'vanne::' + serialNumber + '::tempExt'
      };

      angular.merge(tempExt, dbProps);
      return this.createDocument(tempExt);
    }

    /**
     * Enregistre une nouvelle vanne en base de données
     * @param {IValve} vanne
     * @returns {Promise} promise de la création du document
     */
    storeMacAddress(vanneConfig: eValve.vanne.IValveInit): ng.IPromise<any> {
      let dbProps: any = {
        type: 'macAddress',
        schemaVersion: '1',
        _id: 'macAddress::' + vanneConfig.macAddress
      };

      return this.getDocument(dbProps._id)
        .then(result => {
          dbProps._rev = result._rev;
        }).catch(error => {
          if (error.status != 404) {
            throw error;
          }
        }).finally(() => {
          angular.merge(vanneConfig, dbProps);
          return this.createDocument(vanneConfig);
        });
    }

    getSerialNumberFromMacAddress(macAddress: string): ng.IPromise<string> {
      return this
        .getDocument('macAddress::' + macAddress)
        .then((valveConfig: eValve.vanne.IValveInit) => {
          return valveConfig.serialNumber;
        })
        .catch(error => {
          if (error.status != 404) {
            throw error;
          }

          return null;
        });
    }

    getMacAddressFromSerialNumber(serialNumber: string): ng.IPromise<string> {
      return this._database
        .queryView('_design/evalve', 'macAddresses')
        .then(result => {
          return (<any[]>result.rows).find(doc => doc.key == serialNumber);
        })
        .catch(error => {
          this.$log.error(error);
          throw error;
        });
    }

    /**
     * Méthode générique pour requêter la bdd
     * @param {String} key - Clé de l'objet à récupérer
     * @returns {Promise} Promise de l'objet
     */
    getDocument(key: string): ng.IPromise<any> {
      return this._database
        .getDocument(key)
        .then(result => {
          this.$log.log('Getting document from DB:', result);
          return result;
        })
        .catch(error => {
          this.$log.error(error);
          throw error;
        });
    }

    /**
     * Méthode générique pour créer un document dans la bdd
     * @param {Object} document
     * @returns {Promise} Promise de la création du document
     */
    createDocument(document: any): ng.IPromise<any> {
      let deferred = this.$q.defer();

      this._database.createDocument(document)
        .then(result => {
          this.$log.debug(result);
          deferred.resolve(result);
        })
        .catch(error => {
          this.$log.error(error);
          deferred.reject(error);
        });

      return deferred.promise;
    }

  }

  angular
    .module('eValve.core')
    .service('db', Db);

  const VANNE_MOCK: {
    state: eValve.vanne.IValve,
    prog: eValve.vanne.IValveProgram,
    geoloc: eValve.vanne.IValveGeoloc,
    tempExt: eValve.vanne.IValveTempExt
  } = {
      state: {
        'maintenance': {
          'startDate': 1437440870309,
          'frequency': 2
        },
        'endOfLife': {
          'functionStates': [
            true,
            false,
            false,
            true
          ],
          'action': 0x03
        },
        'software': '0.0.1',
        'hardware': '0.0.1',
        'initialIndex': 305,
        'k': 10,
        'battery': 27,
        'tension': 0.06,
        'temperature': 24,
        'currentIndex': 970,
        'action': 0x20,
        'position': 0x02,
        'serialNumber': '68352f39-5366-4666-8268-e45490ccbb0d',
        'defaults': [],
        'rawDefault': 0,
        'storageMode': false,
        'connectionCode': '1234567890',
        'timeMaxOffset': 60,
        'sensor1': 22.5
      },
      prog: {
        'auto': [
          {
            'tempo': 12,
            'volume': 130,
            'activeFrequency': 0,
            'isActive': true,
            'position': 0x80,
            'startDate': 1478299468314
          },
          {
            'tempo': 15,
            'volume': 1600,
            'activeFrequency': 0,
            'isActive': true,
            'position': 0x80,
            'startDate': 1478537068314
          },
          {
            'tempo': 8,
            'volume': 2161,
            'activeFrequency': 0,
            'isActive': false,
            'position': 0x80,
            'startDate': 1428758777314
          },
          {
            'tempo': 4,
            'volume': 1125,
            'activeFrequency': 1,
            'isActive': false,
            'position': 0x80,
            'startDate': 1428758777314
          },
          {
            'tempo': 53,
            'volume': 4905,
            'activeFrequency': 1,
            'isActive': true,
            'position': 0x80,
            'startDate': 1428758777314
          },
          {
            'tempo': 45,
            'volume': 5442,
            'activeFrequency': 0,
            'isActive': true,
            'position': 0x80,
            'startDate': 1428758777314
          },
          {
            'tempo': 40,
            'volume': 1661,
            'activeFrequency': 1,
            'isActive': false,
            'position': 0x80,
            'startDate': 1428758777314
          },
          {
            'tempo': 14,
            'volume': 7380,
            'activeFrequency': 0,
            'isActive': true,
            'position': 0x80,
            'startDate': 1428758777314
          },
          {
            'tempo': 49,
            'volume': 3805,
            'activeFrequency': 1,
            'isActive': false,
            'position': 0x80,
            'startDate': 1428758777314
          },
          {
            'tempo': 53,
            'volume': 2980,
            'activeFrequency': 1,
            'isActive': false,
            'position': 0x80,
            'startDate': 1428758777314
          }
        ],
        'manual': {
          'volume': 1000,
          'tempo': 20,
          'position': 0x00
        },
        'units': {
          'tempo': 0x02,
          'inhibition': 0x00
        },
        'inhibitions': {
          'auto': {
            'active': false,
            'value': 45
          },
          'manual': {
            'active': false,
            'value': 90
          },
          'sensor': {
            'active': false,
            'value': 90
          }
        }
      },
      geoloc: {
        altitude: '10',
        comments: '',
        deviceFunction: 0,
        installationDate: 1475844260000,
        latitude: '43.545521',
        longitude: '1.513899',
        meterSerial: '123456789',

        city: 'Labège',
        street: 'Rue Pierre et Marie Curie',
        streetNumber: '231',
        zipCode: '31670'
      },
      tempExt: {
        markedAsConnected: true,
        bottomPosition: 0x01,
        middlePosition: 0x02,
        topPosition: 0x03,
        bottomThreshold: { value: 1, range: 1 },
        topThreshold: { value: 10, range: 2 },
        failureAction: 0x01,
        failureCountdown: 5
      }
    };

  // const STATS = {
  //   'lastActionResult': 0x00,
  //   'timeSinceAction': 45612,
  //   'messages': {
  //     'nbBadFrames': 12,
  //     'nbMessages': 67,
  //     'nbBadFramesRadio': 89,
  //     'nbMessagesRadio': 34
  //   },
  //   'maintenance': {
  //     'nbOk': 24,
  //     'nbKo': 97,
  //     'lastDuration': 66,
  //     'meanDuration': 75
  //   },
  //   'opening': {
  //     'nbOk': 0,
  //     'nbKo': 54,
  //     'lastDuration': 76,
  //     'meanDuration': 29,
  //     'totalDuration': 126,
  //     'meanFlowRate': 35
  //   },
  //   'closing': {
  //     'nbOk': 63,
  //     'nbKo': 2,
  //     'lastDuration': 58,
  //     'meanDuration': 15,
  //     'totalDuration': 882
  //   },
  //   'limited': {
  //     'nbOk': 100,
  //     'nbKo': 19,
  //     'lastDuration': 83,
  //     'meanDuration': 100,
  //     'totalDuration': 203,
  //     'meanFlowRate': 14
  //   },
  //   'purges': {
  //     'totalVolume': 507,
  //     'meanVolume': 72,
  //     'lastVolume': 87,
  //     'nbCountdown': 43,
  //     'nbTempo': 81,
  //     'lastStop': 'Volume',
  //     'timeSinceLast': 63,
  //     'totalDuration': 72,
  //     'nbOpened': 49,
  //     'nbLimited': 63
  //   },
  //   'system': {
  //     'nbReset': 53,
  //     'ledDuration': 34,
  //     'nbProgUpgrades': 37,
  //     'lastUpgrade': {
  //       'date': 'Tue Sep 01 2009 01:54:17 GMT+0000 (UTC)',
  //       'user': 'Jacques'
  //     },
  //     'motor': {
  //       'totalDuration': 24,
  //       'nbActuation': 28
  //     }
  //   }
  // };
}
