namespace eValve {
  'use strict';

  angular
    .module('eValve', [
      'eValve.core',
      'eValve.communication',
      'eValve.auth',
      'eValve.dashboard',
      'eValve.vanne',
      'eValve.scanner',
      'eValve.park',
      'eValve.geoloc'
    ])
    // .config(disableLogs)
    .config(ionicConfig)
    .run(formlyConfig)
    .run(setIonic);

  disableLogs.$inject = ['$logProvider'];
  function disableLogs($logProvider: ng.ILogProvider) {
    $logProvider.debugEnabled(false);
  }

  setIonic.$inject = ['$ionicPlatform'];
  function setIonic($ionicPlatform: ionic.platform.IonicPlatformService) {
    $ionicPlatform.ready(() => {
      // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
      // for form inputs)
      // if (window.cordova && window.cordova.plugins && window.cordova.plugins.Keyboard) {
      //   cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
      //   cordova.plugins.Keyboard.disableScroll(true);
      // }
    });
  }

  ionicConfig.$inject = ['$ionicConfigProvider'];
  function ionicConfig($ionicConfigProvider: ionic.utility.IonicConfigProvider) {
    $ionicConfigProvider.backButton.text('');
  }

  formlyConfig.$inject = ['formlyConfig', 'formlyValidationMessages'];
  function formlyConfig(formlyConfig: AngularFormly.IFormlyConfig, formlyValidationMessages: AngularFormly.IValidationMessages) {
    formlyConfig.setWrapper(<any>[
      {
        template: `
          <formly-transclude></formly-transclude>
          <div class="padding validation" ng-if="options.validation.errorExistsAndShouldBeVisible" ng-messages="options.formControl.$error">
            <div ng-messages-include="validation.html"></div>
            <div ng-message="{{::name}}" ng-repeat="(name, message) in ::options.validation.messages">
              {{message(options.formControl.$viewValue, options.formControl.$modelValue, this)}}
            </div>
          </div>
        `
      },
      {
        name: 'loader',
        template: `
          <formly-transclude></formly-transclude>
          <span class="ion-loop loader" ng-show="to.loading"></span>
        `
      }
    ]);

    formlyConfig.setType({
      name: 'floating-input-loader',
      extends: 'floating-input',
      wrapper: ['loader']
    });

    formlyValidationMessages.addTemplateOptionValueMessage('maxlength', 'maxlength',
      'La longueur maximale est de ', 'caractères', 'Champ trop long');
  }
}
