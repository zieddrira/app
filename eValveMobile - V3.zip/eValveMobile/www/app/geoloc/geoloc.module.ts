namespace eValve.geoloc {
  'use strict';

  angular
    .module('eValve.geoloc', [])
    // .constant('GOOGLE_MAPS_API_KEY', 'AIzaSyCm-cw-OdfuWHFOYNsMpvtRhUlCuAW1MNY')
    .run(initModule);

  initModule.$inject = ['routerHelper'];
  function initModule(routerHelper) {
    routerHelper.configureStates(getStates());
  }

  function getStates() {
    return [
      {
        /* Gestion de la géolocalisation */
        state: 'geoloc',
        config: {
          url: '/geoloc',
          views: {
            '': {
              templateUrl: 'app/geoloc/geoloc.html',
              controller: 'GeolocController as geoloc'
            }
          }
        }
      }
    ];
  }
}
