namespace eValve.geoloc {
  'use strict';

  export class GeolocController {
    private _geolocWatch: Function;

    geocode: google.maps.Geocoder;
    geolocChanged: boolean;
    googleMapApiUrl: string;
    fields: any;
    map: google.maps.Map;
    marker: google.maps.Marker;
    model: eValve.vanne.IValveGeoloc & { parsedInstallationDate?: Date };
    statusNetwork: string;

    static $inject: Array<string> = ['$ionicPlatform', '$scope', 'vanne', '$ionicPopup', 'geoloc',
      '$log', '$cordovaDatePicker', '$ionicLoading', 'utils', '$cordovaNetwork', '$q'];
    constructor(
      private $ionicPlatform: ionic.platform.IonicPlatformService,
      private $scope: ng.IScope,
      private vanne: eValve.vanne.IVanne,
      private $ionicPopup: ionic.popup.IonicPopupService,
      private geoloc: IGeoloc,
      private $log: ng.ILogService,
      private $cordovaDatePicker: ngCordova.IDatePickerService,
      private $ionicLoading: ionic.loading.IonicLoadingService,
      private utils: eValve.core.IUtils,
      private $cordovaNetwork: ngCordova.INetworkInformationService,
      private $q: ng.IQService
    ) {
      this.statusNetwork = $cordovaNetwork.getNetwork();
      this.$scope.$on('$ionicView.beforeEnter', () => {
        this.vanne
          .getGeoloc()
          .then((geolocInfos: eValve.vanne.IValveGeoloc) => this.initVm(geolocInfos));
      });

      // this.$scope.$on('$cordovaNetwork:online', (networkState) => {
      //   let isOnlineState = networkState;
      //   if (isOnlineState) {
      //     this.vanne
      //       .getGeoloc()
      //       .then((geolocInfos: eValve.vanne.IValveGeoloc) => this.initVm(geolocInfos));
      //   }
      // });
    }

    /**
     * Initialise les infos et le watcher pour les modifications
     */
    initVm(geoloc: eValve.vanne.IValveGeoloc) {
      if (Object.keys(geoloc).length == 0) {
        this.$ionicPopup.alert({
          title: `Pas d'infos de géolocalisation`,
          template: `Les infos de géolocalisation de la vanne n'ont jamais été récupérées.`
        });

        return;
      };

      this.model = angular.copy(geoloc);
      this.model.parsedInstallationDate = this.model.installationDate ? new Date(this.model.installationDate) : new Date();

      if (this.statusNetwork !== 'none') {
        let latLng = this.geoloc.latLngFromStrings(this.model.latitude, this.model.longitude);

        this.geocode = new google.maps.Geocoder;
        let mapOptions: google.maps.MapOptions = {
          center: latLng,
          zoom: 14,
          mapTypeId: google.maps.MapTypeId.ROADMAP,
          streetViewControl: false,
          zoomControl: false
        };

        this.map = new google.maps.Map(document.getElementById('eValveMap'), mapOptions);

        google.maps.event.addListenerOnce(this.map, 'idle', () => {
          /* Ajout du marker une fois la carte initialisée */
          this.marker = new google.maps.Marker({
            map: this.map,
            animation: google.maps.Animation.DROP,
            position: latLng,
            draggable: true
          });

          /* Event levé lors d'un bouger du marker */
          google.maps.event.addListener(this.marker, 'dragend',
            (event: google.maps.MouseEvent) => this.updateModelLocation(event.latLng.lat(), event.latLng.lng()));
        });
      };

      /* Reset le watch qui vérifie si la config a changé */
      this._geolocWatch && this._geolocWatch();

      let originalGeoloc = angular.copy(this.model);

      this._geolocWatch = this.$scope.$watch(
        () => { return this.model; },
        (newVal: eValve.vanne.IValveGeoloc) => {
          this.geolocChanged = !angular.equals(newVal, originalGeoloc);
        },
        true
      );
      this.setGeolocForm();
    }

    /**
     * Synchronise les infos de géolocalisation avec la vanne
     */
    sync() {
      if (!this.geolocChanged) {
        return;
      }

      this.model.installationDate = this.utils.timestampToSeconds(this.model.parsedInstallationDate.getTime());

      this.vanne
        .saveGeoloc(this.model)
        .then((geoloc: eValve.vanne.IValveGeoloc) => this.initVm(geoloc))
        .catch(error => {
          this.$ionicPopup.alert({
            title: 'Une erreur est survenue',
            template: JSON.stringify(error)
          });
        });
    }

    /**
     * Récupère les infos de géolocalisation et met à jour le formulaire
     */
    getCurrentPosition() {
      this.$ionicPlatform.ready()
        .then(() => {
          this.statusNetwork = this.$cordovaNetwork.getNetwork();
          this.$log.debug('IT : ' + this.statusNetwork);

          let deferred = this.$q.defer();

          cordova.plugins.diagnostic.isLocationEnabled(
            (enabled: boolean) => {
              this.$log.debug('Loc : ' + enabled);
              deferred.resolve(enabled);
            },
            (error) => {
              this.$log.debug('The following error occurred : ' + error);
              deferred.resolve(error);
            }
          );

          return deferred.promise;
        })

        .then(result => {
          /* Gestion localisation manquante */
          if (result != true) {
            this.$ionicPopup.alert({
              title: `Attention : `,
              template: `Veuillez activer la locatisation avant de relancer : "Me localiser".`
            });
          } else {
            this.$ionicLoading.show();

            this.geoloc
              .getCurrentPosition({timeout: 5000})
              .then((position: ngCordova.IGeoPosition) => {
                if (position.coords.altitude) {
                  this.model.altitude = position.coords.altitude.toString().slice(0, 8);
                }

                this.model.latitude = this.geoloc.coordToString(position.coords.latitude);
                this.model.longitude = this.geoloc.coordToString(position.coords.longitude);
              })

              .catch((error: ngCordova.IGeoPositionError) => {
                this.$ionicLoading.hide();

                this.$ionicPopup.alert({
                  title: 'Erreur lors de la géolocalisation',
                  template: `${error.code}: ${error.message}.
              Veuillez vérifier que vous avez bien activé la géolocalisation et que le signal GPS est OK.`,
                  okType: 'button-assertive'
                });

                throw error;
              })

              .then(() => {
                if (this.statusNetwork == 'none') {
                  this.$ionicLoading.hide();
                  return this.$ionicPopup
                    .alert({
                      title: `Attention : `,
                      template: `La connexion Internet n'est pas active.`
                    })
                    .then(() => { throw 'No connection'; });
                }
              })
              .then(() => this.updateModelLocation())
              .then(() => this.updateFromCoords())

              /* Si erreur ou pas, on cache le spinner */
              .finally(() => this.$ionicLoading.hide());
          }
        });
    }

    /**
     * Appelée lors de la modification de la position du marqueur sur la carte
     * Met à jour les coordonnées du formulaire en fonction
     * @param {Number} [lat] Latitude du marqueur
     * @param {Number} [lng] Longitude du marqueur
     */
    updateModelLocation(lat?: number, lng?: number) {
      if (lat != undefined) {
        this.model.latitude = this.geoloc.coordToString(lat);
        this.model.longitude = this.geoloc.coordToString(lng);
      }

      let latLng = this.geoloc.latLngFromStrings(this.model.latitude, this.model.longitude);
      this.geocode.geocode({ location: latLng }, (results, status) => {
        if (status === google.maps.GeocoderStatus.OK) {
          if (results[0]) {
            let cityFound = false;

            results[0].address_components.forEach(component => {
              switch (component.types[0]) {
                case 'street_number':
                  this.model.streetNumber = component.long_name;
                  break;

                case 'route':
                  this.model.street = component.long_name;
                  break;

                case 'locality':
                  this.model.city = component.long_name;
                  cityFound = true;
                  break;

                case 'administrative_area_level_3':
                  if (!cityFound) {
                    this.model.city = component.long_name;
                  }
                  break;

                case 'postal_code':
                  this.model.zipCode = component.long_name;
                  break;

                default:
                  break;
              }
            });
          }
        } else {
          this.$log.error('Geocoder failed due to: ' + status);
        }

        /* La fonction a été appelée en dehors d'angular */
        this.$scope.$apply();
      });
    }

    /**
     * Met à jour l'emplacement du marqueur sur la carte et l'adresse à partir des coordonnées du formulaire
     */
    updateFromCoords() {
      if (!this.model.latitude || !this.model.latitude.length || !this.model.longitude || !this.model.longitude.length) {
        /* Si les coordonnées ne sont pas renseignées, popup d'alerte */
        return this.$ionicPopup.alert({
          title: 'Coordonnées incomplètes !',
          template: 'Veuillez remplir correctement les coordonnées'
        });
      }

      let latLng = this.geoloc.latLngFromStrings(this.model.latitude, this.model.longitude);

      this.map.setCenter(latLng);
      this.marker.setPosition(latLng);

      this.updateModelLocation();
    }

    /**
     * Met à jour les coordonnées et l'emplacement du marqueur à partir de l'adresse du formulaire
     */
    updateFromAddress() {
      let address = `${this.model.streetNumber} ${this.model.street}, ${this.model.zipCode} ${this.model.city}`;

      this.geocode.geocode({ address }, (results, status) => {
        if (status === google.maps.GeocoderStatus.OK) {
          if (results[0]) {
            this.model.latitude = this.geoloc.coordToString(results[0].geometry.location.lat());
            this.model.longitude = this.geoloc.coordToString(results[0].geometry.location.lng());

            let latLng = this.geoloc.latLngFromStrings(this.model.latitude, this.model.longitude);

            this.map.setCenter(latLng);
            this.marker.setPosition(latLng);
          }
        } else {
          this.$log.error('Geocoder failed due to: ' + status);
        }
        this.$scope.$apply();
      });
    }

    /**
     * Affiche un datepicker natif pour sélectionner la date d'installation
     */
    showDatePicker() {
      let today = new Date();
      today.setHours(0, 0, 0, 0);

      let dateOptions = {
        date: this.model.parsedInstallationDate || today,
        maxDate: today,
        // allowFutureDates: false, //iOS only
        mode: 'date',
        locale: 'fr_fr'
      };

      this.$cordovaDatePicker
        .show(dateOptions)
        .then((settedDate: Date) => this.onDateSelect(settedDate));
    }

    /**
     * Appelée lors de la sélection d'une date via le datepicker, récupère les données correspondantes
     * @param {Date} date - Date sélectionnée
     */
    onDateSelect(date: Date) {
      if (!date) {
        return;
      }

      this.model.parsedInstallationDate = date;
    }

    /**
     * Initialise les infos du formulaire de géolocalisation
     */
    setGeolocForm() {
      let deviceFunctions = Object.keys(eValve.vanne.deviceFunction)
        .filter(key => !isNaN(parseInt(key)))
        .map(key => ({ label: eValve.vanne.deviceFunction[key], id: parseInt(key) }));

      this.fields = [
        {
          key: 'latitude',
          type: 'floating-input',
          templateOptions: {
            type: 'text',
            label: 'Latitude',
            placeholder: 'Latitude',
            maxlength: 11
          }
        },
        {
          key: 'longitude',
          type: 'floating-input',
          templateOptions: {
            type: 'text',
            label: 'Longitude',
            placeholder: 'Longitude',
            maxlength: 11
          }
        },
        {
          key: 'altitude',
          type: 'floating-input',
          templateOptions: {
            type: 'text',
            label: 'Altitude (m)',
            placeholder: 'Altitude (m)',
            maxlength: 8
          }
        },
        {
          key: 'meterSerial',
          type: 'floating-input',
          templateOptions: {
            type: 'text',
            label: 'N° de série compteur',
            placeholder: 'N° de série compteur',
            maxlength: 25
          }
        },
        {
          key: 'streetNumber',
          type: 'floating-input',
          templateOptions: {
            type: 'text',
            label: 'N° de rue',
            placeholder: 'N° de rue',
            maxlength: 5
          }
        },
        {
          key: 'street',
          type: 'floating-input',
          templateOptions: {
            type: 'text',
            label: 'Rue',
            placeholder: 'Rue',
            maxlength: 55
          }
        },
        {
          key: 'zipCode',
          type: 'floating-input',
          templateOptions: {
            type: 'text',
            label: 'Code postal',
            placeholder: 'Code postal',
            maxlength: 10
          }
        },
        {
          key: 'city',
          type: 'floating-input',
          templateOptions: {
            type: 'text',
            label: 'Ville',
            placeholder: 'Ville',
            maxlength: 20
          }
        },
        {
          key: 'deviceFunction',
          type: 'select',
          templateOptions: {
            label: 'Fonction',
            options: deviceFunctions,
            valueProp: 'id',
            labelProp: 'label'
          }
        },
        {
          key: 'parsedInstallationDate',
          noFormControl: true,
          templateOptions: { datePicker: this.showDatePicker.bind(this) },
          template: `
            <ion-item class="item-input item-stacked-label" ng-click="options.templateOptions.datePicker()">
              <span class="input-label">Date de pose</span>
              <span style="font-size: 14px; padding-top: 2px; line-height: 34px;">
                {{ model[options.key] | date:"dd/MM/yyyy" }}
              </span>
            </ion-item>
          `
        },
        {
          key: 'comments',
          type: 'floating-input',
          templateOptions: {
            type: 'text',
            label: 'Commentaire',
            placeholder: 'Commentaire',
            maxlength: 100
          }
        }
      ];
    }
  }

  angular
    .module('eValve.geoloc')
    .controller('GeolocController', GeolocController);
}
