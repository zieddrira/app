namespace eValve.geoloc {
  'use strict';

  export interface IGeoloc {
    coordToString(coord: number): string;
    getCurrentPosition(options?: ngCordova.IGeolocationOptions): ng.IPromise<ngCordova.IGeoPosition>;
    latLngFromStrings(lat: string, lng: string): google.maps.LatLng;
  }

  export class Geoloc implements IGeoloc {
    static $inject: Array<string> = ['$cordovaGeolocation'];
    constructor(
      private $cordovaGeolocation: ngCordova.IGeolocationService
    ) { }

    /**
     * Retourne les infos de la position actuelle
     * @param {ngCordova.IGeolocationOption} [options] Options de geoloc
     * @returns {Promise} Promise de la position actuelle
     */
    getCurrentPosition(options?: ngCordova.IGeolocationOptions): ng.IPromise<ngCordova.IGeoPosition> {
      return this.$cordovaGeolocation.getCurrentPosition(options);
    }

    /**
     * Convertit une coordonnée en string de longueur maximale 11 caractères
     * @param {Number} coord Coordonnée à convertir
     * @returns {String} Coordonnée convertie en string de 11 caractères max
     */
    coordToString(coord: number): string {
      return coord.toString().slice(0, 11);
    }

    /**
     * Retourne un objet google LatLng à partir de deux coordonnées sous forme de string
     * @param {String} lat Latitude
     * @param {String} lng Longitude
     * @returns {LatLng} Objet LatLng utilisé par l'api Google Maps
     */
    latLngFromStrings(lat: string, lng: string): google.maps.LatLng {
      return new google.maps.LatLng(parseFloat(lat), parseFloat(lng));
    }
  }

  angular
    .module('eValve.geoloc')
    .service('geoloc', Geoloc);
}
