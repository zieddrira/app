namespace eValve.park {
  'use strict';

  export interface IUser {
    isAdmin: boolean;
    hidden?: boolean;
    password: string;
    userType: number;
    username: string;
    valves: Map<string, number>;
    connectionCodes: { [serialNumber: string]: string };

    _id?: string;
    _rev?: string;
  }

  export interface IValveCode {
    code: string;
    temp?: boolean;

    _rev?: string;
  }

  angular
    .module('eValve.park', ['ngCsv'])
    .run(initModule);

  initModule.$inject = ['routerHelper', '$cordovaFile', '$ionicPlatform'];
  function initModule(routerHelper, $cordovaFile: ngCordova.IFileService, $ionicPlatform: ionic.platform.IonicPlatformService) {
    routerHelper.configureStates(getStates());

    /* On attend que la plateforme Ionic soit complètement chargée pour gérer les fichiers cordova.
     * Permet de gérer la fermeture de l'application et la réouverture (avec le bouton back Android par exemple).
     */
    $ionicPlatform.ready(() => {
      if (ionic.Platform.isAndroid()) {
        /* Sur Android, on crée le dossier eValveMobile à la racine si il n'est pas déjà présent */
        $cordovaFile.createDir(cordova.file.externalRootDirectory, 'eValveMobile');
      }
    });
  }

  function getStates() {
    return [
      {
        state: 'park',
        config: {
          asbtract: true,
          url: '/park',
          views: {
            '': {
              template: '<ion-nav-view name="park-view"></ion-nav-view>'
            }
          }
        }
      },
      {
        /* Ajout d'une vanne */
        state: 'park.addValve',
        config: {
          url: '/addValve',
          views: {
            'park-view': {
              templateUrl: 'app/park/add-valve.html',
              controller: 'AddValveController as vm'
            }
          }
        }
      },
      {
        /* Liste des utilisateurs */
        state: 'park.users',
        config: {
          url: '/users',
          views: {
            'park-view': {
              templateUrl: 'app/park/users-list.html',
              controller: 'UsersListController as vm'
            }
          }
        },
        resolve: {
          mustBeAdministrator: ['park', '$q', function (park: eValve.park.IParkService, $q: ng.IQService) {
            return park.loggedUser.isAdmin
              ? $q.resolve()
              : $q.reject('NOT_ADMIN');
          }]
        }
      },
      {
        /* Edition d'un utilisateur */
        state: 'park.editUser',
        config: {
          url: '/editUser/{username}',
          views: {
            'park-view': {
              templateUrl: 'app/park/edit-user.html',
              controller: 'EditUserController as vm'
            }
          }
        },
        resolve: {
          mustBeAdministrator: ['park', '$q', function (park: eValve.park.IParkService, $q: ng.IQService) {
            return park.loggedUser.isAdmin
              ? $q.resolve()
              : $q.reject('NOT_ADMIN');
          }]
        }
      },
      {
        /* Gestion des vannes d'un utilisateur */
        state: 'park.userValves',
        config: {
          url: '/userValves/{username}',
          views: {
            'park-view': {
              templateUrl: 'app/park/user-valves.html',
              controller: 'UserValvesController as vm'
            }
          }
        },
        resolve: {
          mustBeAdministrator: ['park', '$q', function (park: eValve.park.IParkService, $q: ng.IQService) {
            return park.loggedUser.isAdmin
              ? $q.resolve()
              : $q.reject('NOT_ADMIN');
          }]
        }
      },
      {
        /* Onglet de gestion des vannes */
        state: 'park.manageValves',
        config: {
          url: '/manageValves',
          abstract: true,
          cache: false,
          views: {
            'park-view': {
              templateUrl: 'app/park/manage/manage-valves.html',
              controller: 'ManageValvesController as vm'
            }
          }
        }
      },
      {
        /* Export des vannes */
        state: 'park.exportValves',
        config: {
          url: '/export',
          parent: 'park.manageValves',
          views: {
            'export-valves': {
              templateUrl: 'app/park/manage/export-valves.html'
            }
          }
        }
      },
      {
        /* Export des coordonnées */
        state: 'park.exportCoords',
        config: {
          url: '/coords',
          parent: 'park.manageValves',
          views: {
            'export-coords': {
              templateUrl: 'app/park/manage/export-coords.html'
            }
          }
        }
      },
      {
        /* Suppression des vannes */
        state: 'park.deleteValves',
        config: {
          url: '/delete',
          parent: 'park.manageValves',
          views: {
            'delete-valves': {
              templateUrl: 'app/park/manage/delete-valves.html'
            }
          }
        },
        resolve: {
          mustBeAdministrator: ['park', '$q', function (park: eValve.park.IParkService, $q: ng.IQService) {
            return park.loggedUser.isAdmin
              ? $q.resolve()
              : $q.reject('NOT_ADMIN');
          }]
        }
      }
    ];
  }
}
