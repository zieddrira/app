namespace eValve.park {
  'use strict';

  export class EditUserController {
    fields: any;
    model: any;
    user: IUser;

    static $inject: Array<string> = ['park', '$stateParams', '$ionicPopup', '$ionicHistory', '$q'];
    constructor(
      private park: IParkService,
      private $stateParams: ng.ui.IStateParamsService,
      private $ionicPopup: ionic.popup.IonicPopupService,
      private $ionicHistory: ionic.navigation.IonicHistoryService,
      private $q: ng.IQService
    ) {
      this.initVm();
    }

    /**
     * Récupère les infos de l'utilisateur à éditer à partir du username
     * Initialise le modèle du formulaire (champ admin)
     */
    initVm() {
      this.park
        .getUserDetails(this.$stateParams['username'])
        .then((user: IUser) => {
          this.user = user;
          this.setUserForm(user.isAdmin);
        });
    }

    /**
     * Met à jour l'utilisateur en BDD avec les modifications apportées
     * @returns {Promise} Promise de la mise à jour de l'utilisateur
     */
    updateUser(): ng.IPromise<void> {
      let adminPromise = this.$q.resolve(true);

      if (this.user.isAdmin && !this.model.isAdmin) {
        /* Si suppression du statut admin, on vérifie qu'il restera d'autres admins */
        adminPromise = this.park.checkIfMultipleAdmins();
      }

      return adminPromise
        .then((result: boolean) => {
          if (!result) {
            /* Si il n'y a pas d'autres admins et qu'on veut supprimer le statut sur l'utilisateur */
            this.model.isAdmin = true;
            throw 'ONLY_ONE_ADMIN';
          }

          this.user.isAdmin = this.model.isAdmin;
          if (this.model.password) {
            this.user.password = this.model.password;
          }

          return this.park.updateUser(this.user);
        })

        /* Si l'update a réussi on retourne sur la vue précédente */
        .then(() => this.$ionicHistory.goBack())

        .catch(error => {
          if (error == 'ONLY_ONE_ADMIN') {
            return this.$ionicPopup.alert({
              title: 'Impossible de changer le statut',
              template: `Il s'agit du seul administrateur de l'application, vous ne pouvez pas changer son statut !`,
              okType: 'button-assertive'
            });
          }

          this.$ionicPopup.alert({
            title: `Erreur lors de l'enregistrement`,
            template: JSON.stringify(error),
            okType: 'button-assertive'
          });
        });
    }

    /**
     * Initialise le formulaire d'édition d'utilisateur
     * @param {type} isAdmin Valeur de base du champ isAdmin
     */
    setUserForm(isAdmin: boolean) {
      this.model = { isAdmin };

      this.fields = [
        {
          key: 'password',
          type: 'floating-input',
          templateOptions: {
            type: 'password',
            placeholder: 'Nouveau mot de passe',
            label: 'Nouveau mot de passe'
          }
        },
        {
          key: 'confirmPassword',
          type: 'floating-input',
          templateOptions: {
            type: 'password',
            placeholder: 'Confirmation du mot de passe',
            label: 'Confirmation du mot de passe'
          },
          validators: {
            equalPasswords: {
              expression: ($viewValue, $modelValue) => {
                let value = $modelValue || $viewValue;
                return this.model.password == value;
              },
              message: '"Le mot de passe ne correspond pas"'
            }
          },
          extras: {
            validateOnModelChange: true
          }
        },
        {
          key: 'isAdmin',
          type: 'toggle',
          templateOptions: {
            label: 'Administrateur',
            toggleClass: 'toggle-positive'
          }
        }
      ];
    }
  }

  angular
    .module('eValve.park')
    .controller('EditUserController', EditUserController);
}
