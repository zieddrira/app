namespace eValve.park {
  'use strict';

  export class ManageValvesController {
    valves: { serialNumber: string; selected: boolean }[];

    static $inject: Array<string> = ['park', 'vanne', '$ionicPopup', '$ionicLoading', '$log'];
    constructor(
      private park: IParkService,
      private vanne: eValve.vanne.IVanne,
      private $ionicPopup: ionic.popup.IonicPopupService,
      private $ionicLoading: ionic.loading.IonicLoadingService,
      private $log: ng.ILogService
    ) {
      this.initVm();
    }

    initVm() {
      this.park
        .getAllValves()
        .then((serialNumbers: string[]) => this.valves = serialNumbers.map(serialNumber => ({ serialNumber, selected: false })))
        .catch(error => {
          this.$ionicPopup.alert({
            title: 'Erreur lors de la récupération des vannes',
            template: JSON.stringify(error),
            okType: 'button-assertive'
          });
        });
    }

    /**
     * Exporte les vannes sélectionnées dans un CSV
     */
    exportValves() {
      let filename;
      let valvesToExport = this.getSelectedValves();

      if (valvesToExport.length == 0) {
        /* Si pas de vanne sélectionnée, on retourne une alerte */
        return this.$ionicPopup.alert({
          title: 'Pas de vanne sélectionnée',
          template: `Aucune vanne n'a été sélectionnée !`
        });
      }

      this.$ionicPopup
        .prompt({
          title: 'Nom du fichier',
          template: `Spécifiez le nom du fichier dans lequel exporter les vannes`,
          inputPlaceholder: `export.csv (par défaut)`,
          okText: 'Exporter'
        })
        .then(input => {
          if (input === undefined) {
            /* Si undefined, l'utilisateur a annulé l'export */
            return;
          }

          filename = input || 'export.csv';
          return this.park.checkIfFileExists(filename);
        })

        /* On rentre ici si le fichier existe */
        .then(fileExists => {
          if (filename === undefined) {
            /* Si undefined, l'utilisateur a annulé */
            return false;
          }

          return this.$ionicPopup
            .confirm({
              title: 'Fichier déjà existant',
              template: `Un fichier avec ce nom existe déjà, souhaitez-vous continuer ?`,
              cancelText: 'Annuler',
              okText: 'Confirmer'
            });
        })

        /* Si le fichier n'existe pas déjà ou autre erreur */
        .catch(error => {
          if (error.code) {
            /* Si l'erreur a un code, elle a été remontée par cordova car le fichier n'existe pas */
            return;
          } else {
            /* Si erreur autre que cordova, on relève l'erreur */
            throw error;
          }
        })

        /* Si il n'y a pas de paramètre, c'est qu'on est passé par l'erreur du fichier qui n'existe pas encore */
        .then((response: boolean | void) => {
          if (response == false) {
            /* Si faux, l'utilisateur a annulé */
            return;
          }

          return this.park.exportValvesAsCsv(filename, valvesToExport);
        })
        .then(result => {
          if (!result) {
            return;
          }

          return this.$ionicPopup.alert({
            title: 'Fichier créé',
            template: `Le fichier CSV a bien été créé`
          });
        })

        /* Erreur autre que cordova lors de la vérification du fichier, ou erreur lors de la création du CSV */
        .catch(error => {
          this.$ionicPopup.alert({
            title: 'Une erreur est survenue',
            template: JSON.stringify(error),
            okType: 'button-assertive'
          });
        })

        .finally(() => this.initVm());
    }

    /**
     * Exporte les coordonnées des valves sélectionnés dans un fichier kml
     */
    exportCoords() {
      let filename;
      let valvesToExport = this.getSelectedValves();

      if (valvesToExport.length == 0) {
        /* Si pas de vanne sélectionnée, on retourne une alerte */
        return this.$ionicPopup.alert({
          title: 'Pas de vanne sélectionnée',
          template: `Aucune vanne n'a été sélectionnée !`
        });
      }

      this.$ionicPopup
        .prompt({
          title: 'Nom du fichier',
          template: `Spécifiez le nom du fichier dans lequel exporter les coordonnées`,
          inputPlaceholder: `geoloc.kml (par défaut)`,
          okText: 'Exporter'
        })
        .then(input => {
          if (input === undefined) {
            /* Si undefined, l'utilisateur a annulé l'export */
            return;
          }

          filename = input || 'geoloc.kml';
          return this.park.checkIfFileExists(filename);
        })

        /* On rentre ici si le fichier existe */
        .then(fileExists => {
          if (filename === undefined) {
            /* Si undefined, l'utilisateur a annulé */
            return false;
          }

          return this.$ionicPopup
            .confirm({
              title: 'Fichier déjà existant',
              template: `Un fichier avec ce nom existe déjà, souhaitez-vous continuer ?`,
              cancelText: 'Annuler',
              okText: 'Confirmer'
            });
        })

        /* Si le fichier n'existe pas déjà ou autre erreur */
        .catch(error => {
          if (error.code) {
            /* Si l'erreur a un code, elle a été remontée par cordova car le fichier n'existe pas */
            return;
          } else {
            /* Si erreur autre que cordova, on relève l'erreur */
            throw error;
          }
        })

        /* Si il n'y a pas de paramètre, c'est qu'on est passé par l'erreur du fichier qui n'existe pas encore */
        .then((response: boolean | void) => {
          if (response == false) {
            /* Si faux, l'utilisateur a annulé */
            return response;
          }

          return this.park.exportValvesGeoloc(filename, valvesToExport);
        })
        .then(result => {
          if (result == false) {
            /* Si faux, l'utilisateur a annulé */
            return;
          } else if (!result) {
            /* Si result undefined, pas de données à exporter */
            return this.$ionicPopup.alert({
              title: 'Pas de données',
              template: `Aucune vanne sélectionnée n'a de données de géolocalisation à exporter`
            });
          }

          return this.$ionicPopup.alert({
            title: 'Fichier créé',
            template: `Le fichier KML a bien été créé`
          });
        })

        /* Erreur autre que cordova lors de la vérification du fichier, ou erreur lors de la création du KML */
        .catch(error => {
          this.$ionicPopup.alert({
            title: 'Une erreur est survenue',
            template: JSON.stringify(error),
            okType: 'button-assertive'
          });
        })

        .finally(() => this.initVm());
    }

    /**
     * Supprime les vannes sélectionnées de l'appareil et des utilisateurs
     */
    deleteValves() {
      let valvesToDelete = this.getSelectedValves();

      if (valvesToDelete.length == 0) {
        /* Si pas de vanne sélectionnée, on retourne une alerte */
        return this.$ionicPopup.alert({
          title: 'Pas de vanne sélectionnée',
          template: `Aucune vanne n'a été sélectionnée !`
        });
      }

      return this.$ionicPopup
        .confirm({
          title: 'Confirmez la suppression',
          template: `Etes-vous sûr(e) de vouloir supprimer ces vannes de l'application ?`,
          okText: 'Supprimer',
          cancelText: 'Annuler'
        })

        .then(result => {
          if (!result) {
            throw 'CANCELED';
          }

          if (valvesToDelete.includes(this.vanne.selectedValveSerial)) {
            this.vanne.selectedValveSerial = null;
          }

          if (valvesToDelete.includes(this.vanne.connectedValveSerial)) {
            this.vanne.disconnect();
          }

          this.$ionicLoading.show();
          return this.park.bulkValveDelete(valvesToDelete);
        })

        .then((errors: any[]) => {
          this.$ionicLoading.hide();
          let filteredErrors = errors ? errors.filter(error => error.code != '404') : [];

          if (filteredErrors.length) {
            return this.$ionicPopup.alert({
              title: 'Des erreurs se sont produites',
              template: JSON.stringify(filteredErrors),
              okType: 'button-assertive'
            });
          }

          return this.$ionicPopup.alert({
            title: 'Suppression terminée',
            template: `Les vannes sélectionnées ont bien été supprimées`
          });
        })

        .finally(() => {
          this.$ionicLoading.hide();
          this.initVm();
        });
    }

    /**
     * Retourne la liste des vannes sélectionnées
     * @returns {string[]} Liste des vannes sélectionnées
     */
    private getSelectedValves(): string[] {
      return this.valves
        .filter(valve => valve.selected)
        .map(valve => valve.serialNumber);
    }
  }

  angular
    .module('eValve.park')
    .controller('ManageValvesController', ManageValvesController);
}
