namespace eValve.park {
  'use strict';

  declare var vkbeautify;

  export interface IParkService {
    loggedUser: IUser;

    addValveToUser(serialNumber: string, timestampLastConnection: number, connectionCode?: string): ng.IPromise<void>;
    addOfflineValve(serialNumber: string, timestampLastConnection: number, connectionCode: string): ng.IPromise<void>;
    bulkValveDelete(valves: string[], errors?: any[]): ng.IPromise<any>;
    bulkValveImport(filename: string): ng.IPromise<any>;
    checkIfFileExists(filename: string): ngCordova.IFilePromise<FileEntry>;
    checkIfMultipleAdmins(): ng.IPromise<boolean>;
    deleteUser(username: string): ng.IPromise<any>;
    exportValvesAsCsv(filename: string, ids: string[], valvesDatas?: { serialNumber: string, connectionCode: string }[],
      errors?: string[]): ngCordova.IFilePromise<ProgressEvent>;
    exportValvesGeoloc(filename: string, serialNumbers: string[], geolocDatas?: eValve.vanne.IValveGeoloc[],
      errors?: string[]): ngCordova.IFilePromise<ProgressEvent>;
    getAllValves(): ng.IPromise<string[]>;
    getUserDetails(username: string): ng.IPromise<IUser>;
    getUsers(): ng.IPromise<{ username: string, isAdmin: boolean }[]>;
    getUserValveCode(serialNumber: string): ng.IPromise<{ code: string, temp?: boolean }>;
    removeValvesFromUser(username: string, valves: string[]): ng.IPromise<any>;
    saveConnectionCode(serialNumber: string, connectionCode: string, temp?: boolean): ng.IPromise<any>;
    transferValvesToUser(username: string, valves: string[]): ng.IPromise<any>;
    updateUser(user: IUser): ng.IPromise<any>;
  }

  export class ParkService implements IParkService {
    private _loggedUser: IUser;
    private _storagePath: string;
    private _targetUser: IUser;

    static $inject: Array<string> = ['db', '$q', '$log', '$cordovaFile', 'CSV'];
    constructor(
      private db: eValve.core.IDb,
      private $q: ng.IQService,
      private $log: ng.ILogService,
      private $cordovaFile: ngCordova.IFileService,
      private CSV: any
    ) { }

    get loggedUser() { return this._loggedUser; }
    set loggedUser(user: eValve.park.IUser) { this._loggedUser = user; }

    /**
     * Retourne le chemin vers le dossier de stockage des fichiers en fonction de l'OS
     * @returns {String} Chemin vers le dossier de stockage des documents de l'application
     */
    private get storagePath() {
      if (this._storagePath) {
        return this._storagePath;
      }

      if (ionic.Platform.isIOS()) {
        this._storagePath = cordova.file.documentsDirectory;
      } else if (ionic.Platform.isAndroid()) {
        this._storagePath = cordova.file.externalRootDirectory + 'eValveMobile/';
      }

      return this._storagePath;
    }

    /**
     * Vérifie si l'utilisateur courant est déjà autorisé sur la vanne en paramètre
     * @param {string} serialNumber Numéro de série de la vanne à vérifier
     * @returns {Promise<{code: string, temp: boolean}>} Promise du code de connexion de la vanne (si dans la liste de l'utilisateur)
     */
    getUserValveCode(serialNumber: string): ng.IPromise<{ code: string, temp?: boolean }> {
      if (this.loggedUser.valves.has(serialNumber)) {
        if (this.loggedUser.connectionCodes[serialNumber]) {
          /* Si le code de l'utilisateur n'a pas encore eu l'occasion d'être validé */
          return this.$q.resolve({ code: this.loggedUser.connectionCodes[serialNumber], temp: true });
        }

        /* Si l'utilisateur n'a pas de code non-validé, on récupère le code de la vanne */
        return this.db
          .getDocument(`vanne::${serialNumber}::code`)
          .then(document => ({ code: document.code, temp: document.temp }))
          .catch(error => {
            if (error.status != 404) {
              throw error;
            }

            return this.$q.reject('CODE_NOT_FOUND');
          });
      }

      return this.$q.reject('NOT_REGISTERED');
    }

    /**
     * Ajoute la vanne spécifiée et son code de connexion à l'utilisateur courant
     * @param {string} serialNumber Numéro de série de la vanne
     * @param {number} timestampLastConnection récupère le timestamp de la dernière connection
     * @param {string}  [connectionCode] Code de connexion s'il n'a pas pu être vérifié
     * @returns {Promise} Promise de la mise à jour de l'utilisateur en base de données
     */
    addValveToUser(serialNumber: string, timestampLastConnection: number, connectionCode?: string): ng.IPromise<void> {
      if (this.loggedUser.valves.has(serialNumber)) {
        /* Si l'utilisateur a déjà la vanne associée, si il n'y a pas de code de connexion en paramètre c'est qu'on valide l'association */
        if (!connectionCode) {
          if (this.loggedUser.connectionCodes[serialNumber]) {
            /* Si le code de l'utilisateur n'était pas encore validé, on le supprime maintenant de la liste temporaire */
            delete this.loggedUser.connectionCodes[serialNumber];
          }

          /* Cas d'une vanne importée à laquelle on se connecte : on met à jour le timestamp de connexion */
          if (this.loggedUser.valves.get(serialNumber) === 0) {
            this.loggedUser.valves.set(serialNumber, timestampLastConnection);
          }
        }

      } else {
        this.loggedUser.valves.set(serialNumber, timestampLastConnection);
      }

      if (connectionCode) {
        /* Si le code n'a pas pu être vérifié, on le stocke dans le profil utilisateur */
        this.loggedUser.connectionCodes[serialNumber] = connectionCode;
      }

      return this.db
        .storeUser(this.loggedUser)
        .then(result => {
          this.loggedUser._rev = result.rev;
        })
        .catch(error => {
          throw 'ERROR_WRITE_VALVE_TO_USER';
        });
    }

    /**
     * Vérifie qu'un code de connexion pour la vanne existe déjà ou pas. Si il existe déjà, compare avec celui saisi
     * Sinon ajoute le code dans la vanne et l'utilisateur, avec le flag temp
     * @param {string} serialNumber Numéro de série de la vanne
     * @param {number} timestampLastConnection récupère le timestamp de la dernière connection
     * @param {string} connectionCode Code de connexion à la vanne
     * @returns {Promise} Promise de l'enregistrement de la vanne dans l'utilisateur
     */
    addOfflineValve(serialNumber: string, timestampLastConnection: number, connectionCode: string): ng.IPromise<void> {
      return this.db
        .getDocument(`vanne::${serialNumber}::code`)
        .then(document => {
          if (document.temp) {
            /* Si le code n'a pas encore été validé, on écrase avec la nouvelle valeur */
            document.code = connectionCode;
            return this.addValveToUser(serialNumber, timestampLastConnection, connectionCode);
          }

          if (document.code != connectionCode) {
            /* Si le code de la vanne a déjà été validé et diffère, on lève un erreur */
            throw 'BAD_CONNECTION_CODE';
          }

          /* On est ici si la vanne a déjà été connectée et que le code saisi hors-connexion correspond à celui de la vanne */
          return this.addValveToUser(serialNumber, timestampLastConnection);
        })

        .catch(error => {
          if (!error.status || error.status != 404) {
            /* Si erreur autre que document inexistant */
            this.$log.error(error);
            throw error;
          }

          /* Si le document n'existe pas, on écrit le code sur la nouvelle vanne avec le flag temp */
          return this
            .saveConnectionCode(serialNumber, connectionCode, true)
            .then(() => this.addOfflineValve(serialNumber, timestampLastConnection, connectionCode));
        });
    }

    /**
     * Ajoute des vannes existantes à un utilisateur
     * @param {string} username Utilisateur auquel affecter les vannes
     * @param {string[]} valves Ids des vannes à affecter
     * @returns {Promise} Promise de la mise à jour de l'utilisateur
     */
    transferValvesToUser(username: string, valves: string[]): ng.IPromise<any> {
      return this
        .getUserDetails(username)
        .then((user: IUser) => {
          valves.forEach(valve => user.valves.set(valve, Date.now()));
          return this.updateUser(user);
        });
    }

    /**
     * Supprime les vannes en paramètre des accès de l'utilisateur
     * @param {string} username Utilisateur à modifier
     * @param {string[]} valves Liste des vannes à retirer
     * @returns {Promise} Promise de la mise à jour de l'utilisateur
     */
    removeValvesFromUser(username: string, valves: string[]): ng.IPromise<any> {
      return this
        .getUserDetails(username)
        .then((user: IUser) => {
          valves.forEach(valve => {
            user.valves.delete(valve);
            delete user.connectionCodes[valve];
          });

          return this.updateUser(user);
        });
    }

    /**
     * Ouverture du fichier passé en paramètre et import des vannes
     * @param {string} filename Nom du fichier à ouvrir
     * @returns {Promise} Promise de l'import des vannes
     */
    bulkValveImport(filename: string): ng.IPromise<any> {
      return this.$cordovaFile
        .readAsText(this.storagePath, filename)
        .then(fileContent => this.bulkValveSave(this.CSVToArray(fileContent, ';')))
        .catch(error => {
          this.$log.error(error);
          throw error;
        });
    }

    /**
     * Récupère par récursion tous les codes des vannes à exporter puis enregistre le CSV dans le fichier spécifié
     * @param {string} filename Nom du fichier dans lequel écrire le CSV
     * @param {string[]} serialNumbers Numéros de série des vannes à exporter
     * @param {Object[]} [valvesDatas] Liste des vannes avec les codes déjà récupérés
     * @param {string[]} [errors] Liste des vannes pour lesquelles une erreur est survenue lors de la récupération du code
     * @returns {Promise} Promise de l'enregistrement du CSV
     */
    exportValvesAsCsv(filename: string, serialNumbers: string[], valvesDatas?: { serialNumber: string, connectionCode: string }[],
      errors?: string[]): ngCordova.IFilePromise<ProgressEvent> {
      let serialNumber = serialNumbers.shift();

      if (serialNumber) {
        /* Si il y a encore des ids pour lesquels récupérer le code de connexion */
        return this.db
          .getDocument(`vanne::${serialNumber}::code`)
          .then(document => {
            valvesDatas
              ? valvesDatas.push({ serialNumber: serialNumber, connectionCode: document.code })
              : valvesDatas = [{ serialNumber: serialNumber, connectionCode: document.code }];
          })
          .catch(error => {
            /* Si erreur, on ajoute la ligne concernée à la liste d'erreurs */
            errors ? errors.push(serialNumber) : errors = [serialNumber];
          })
          .then(() => this.exportValvesAsCsv(filename, serialNumbers, valvesDatas, errors));
      }

      /* Si serialNumber est undefined, on est censé avoir récupéré tous les codes nécessaires */
      return this.CSV.stringify(valvesDatas, { fieldSep: ';' })
        .then(csv => this.$cordovaFile.writeFile(this.storagePath, filename, csv, true));
    }

    /**
     * Exporte les coordonnées des vannes sélectionnées dans un fichier kml
     * @param {String} filename Nom du fichier kml
     * @param {String[]} serialNumbers Liste des vannes à exporter
     * @param {IValveGeoloc[]} geolocDatas Données de géolocalisation déjà récupérées
     * @param {String[]} [errors] Liste des vannes pour lesquelles une erreur est survenue
     * lors de la récupération des infos de géolocalisation
     * @returns {Promise} Promise de l'enregistrement du kml
     */
    exportValvesGeoloc(filename: string, serialNumbers: string[], geolocDatas?: eValve.vanne.IValveGeoloc[],
      errors?: string[]): ngCordova.IFilePromise<ProgressEvent> {
      let serialNumber = serialNumbers.shift();

      if (serialNumber) {
        /* Si il y a encore des ids pour lesquels récupérer les infos de géolocalisation */
        return this.db
          .getDocument(`vanne::${serialNumber}::geoloc`)
          .then(document => {
            geolocDatas ? geolocDatas.push(document) : geolocDatas = [document];
          })
          .catch(error => {
            /* Si erreur, on ajoute la ligne concernée à la liste d'erreurs */
            errors ? errors.push(serialNumber) : errors = [serialNumber];
          })

          .then(() => this.exportValvesGeoloc(filename, serialNumbers, geolocDatas, errors));
      }

      if (!geolocDatas) {
        return;
      }

      let placemarksTemplate = geolocDatas
        .map(geoloc => {
          /* On appelle replace() sur chaque valeur pour supprimer les possibles bits nulls à la fin */
          let address = geoloc.streetNumber.length && geoloc.streetNumber.replace(/\0/g, '').trim() + ' ' || '';
          address += geoloc.street.length && geoloc.street.replace(/\0/g, '').trim() + ', ' || '';
          address += geoloc.zipCode.length && geoloc.zipCode.replace(/\0/g, '').trim() + ' ' || '';
          address += geoloc.city.length && geoloc.city.replace(/\0/g, '').trim();

          let parsedLongitude = geoloc.longitude.replace(/\0/g, '').trim();
          let parsedLatitude = geoloc.latitude.replace(/\0/g, '').trim();
          let parsedAltitude = geoloc.altitude.replace(/\0/g, '').trim();

          return `
            <Placemark>
              <name>Vanne ${geoloc._id.split('::')[1]}</name>
              <description>${address}</description>
              <Point>
                <coordinates>${parsedLongitude},${parsedLatitude},${parsedAltitude}</coordinates>
              </Point>
            </Placemark>
          `;
        })

        .reduce((previous, current) => previous + current);

      /* Important : le xml ne doit pas démarrer par une ligne vide ! */
      let kmlTemplate =
        `<?xml version="1.0" encoding="UTF-8"?>
        <kml xmlns="http://www.opengis.net/kml/2.2">
          <Document>
            <name>Géolocalisation des vannes</name>
            <open>1</open>
            <Folder>
              <name>Vannes</name>
              ${placemarksTemplate}
            </Folder>
          </Document>
        </kml>`;

      return this.$cordovaFile.writeFile(this.storagePath, filename, vkbeautify.xml(kmlTemplate), true);
    }

    /**
     * Vérifie si le fichier passé en paramètre existe déjà
     * @param {string} filename Nom du fichier à vérifier
     * @returns {Promise} Promise résolue si fichier existant et rejetée autrement
     */
    checkIfFileExists(filename: string): ngCordova.IFilePromise<FileEntry> {
      return this.$cordovaFile.checkFile(this.storagePath, filename);
    }

    /**
     * Enregistre le code de connexion à une vanne dans une entrée spéficique
     * @param {string} serialNumber Numéro de série de la vanne
     * @param {string} connectionCode Code de connexion à la vanne
     * @param {boolean} [temp] Si le code n'a pas encore été vérifié, temp doit être passé à true
     * @returns {Promise} Promise de l'enregistrement du code
     */
    saveConnectionCode(serialNumber: string, connectionCode: string, temp?: boolean): ng.IPromise<any> {
      return this.db
        .getDocument(`vanne::${serialNumber}::code`)
        .catch(error => {
          if (error.status == 404) {
            this.$log.info(`Il n'y a pas encore de code enregistré pour cette vanne`);
          }
        })

        .then((doc: eValve.park.IValveCode | void) => {
          let document: eValve.park.IValveCode = doc as eValve.park.IValveCode;

          if (!doc) {
            document = <eValve.park.IValveCode>{};
          }

          document.code = connectionCode;
          temp ? document.temp = temp : delete document.temp;

          return this.db.storeVanneCode(serialNumber, document);
        })
        .catch(error => {
          throw 'ERROR_WRITE_CODE';
        });
    }

    /**
     * Retourne la liste des noms d'utilisateurs
     * @returns {Promise<string[]>} Promise des usernames
     */
    getUsers(): ng.IPromise<{ username: string, isAdmin: boolean }[]> {
      return this.db.getUsers();
    }

    /**
     * Récupère les détails d'un utilisateur à partir de son username
     * @param {string} username
     * @returns {Promise<IUser>} Promise de l'utilisateur
     */
    getUserDetails(username: string): ng.IPromise<IUser> {
      if (this._targetUser && this._targetUser.username == username) {
        /* Si utilisateur "en cache", on le retourne directement */
        return this.$q.resolve(this._targetUser);
      }

      return this.db
        .getUserByUsername(username)
        .then((user: IUser) => this._targetUser = user);
    }

    /**
     * Met à jour l'utilisateur en paramètre en base de données
     * @param {IUser} user Utilisateur à mettre à jour
     * @returns {Promise} Promise de la mise à jour de l'utilisateur
     */
    updateUser(user: IUser): ng.IPromise<any> {
      return this.db
        .storeUser(user)
        .then(result => {
          if (this._targetUser && this._targetUser.username == user.username) {
            this._targetUser._rev = result.rev;

            if (this.loggedUser && this.loggedUser.username == this._targetUser.username) {
              /* Si on a modifié l'utilisateur loggé, on le met à jour */
              this.loggedUser = this._targetUser;
            }
          }

          return result;
        });
    }

    /**
     * Supprime l'utilisateur à partir de son username
     * @param {string} username Nom de l'utilisateur à supprimer
     * @returns {Promise} Promise de la suppression de l'utilisateur
     */
    deleteUser(username: string): ng.IPromise<any> {
      if (this.loggedUser.username == username) {
        /* Si tentative de suppression de l'utilisateur connecté, on rejette */
        return this.$q.reject('CONNECTED_USER');
      }

      return this.db
        .deleteUserByUserName(username)
        .then(result => {
          if (this._targetUser && this._targetUser.username == username) {
            this._targetUser = null;
          }

          return result;
        });
    }

    /**
     * Vérifie si il y a plusieurs administrateurs sur l'application
     * @returns {Promise<boolean>} Promise vraie si plusieurs admins
     */
    checkIfMultipleAdmins(): ng.IPromise<boolean> {
      return this.db
        .getUsers()
        .then((users: { username: string, isAdmin: boolean }[]) => {
          return users.filter(user => user.isAdmin).length > 1;
        });
    }

    /**
     * Retourne la liste de toutes les vannes de l'application, même celles non-vérifiées et jamais connectées
     * @returns {Promise<string[]>} Promise de tous les ids des vannes de l'application
     */
    getAllValves(): ng.IPromise<string[]> {
      return this.db.getAllValves();
    }

    /**
     * Fonction récursive qui supprime une par une les vannes passées en paramètre
     * @param {string[]} valves Numéros de série des vannes à supprimer
     * @returns {Promise} Promise de la suppression des vannes
     */
    bulkValveDelete(valves: string[], errors?: any[]): ng.IPromise<any> {
      let valveToDelete = valves.shift();

      if (!valveToDelete) {
        return this.$q.resolve(errors);
      }

      return this.db.deleteValve(valveToDelete)
        .then((result: any[]) => {
          if (result.length) {
            errors ? errors.concat(result) : errors = result;
          }

          return this.bulkValveDelete(valves);
        });
    }

    /**
     * Retourne le chemin vers le dossier de stockage des fichiers en fonction de l'OS
     * @returns {String} Chemin vers le dossier de stockage des documents de l'application
     */
    getStoragePath(): string {
      let path: string;

      if (ionic.Platform.isIOS()) {
        path = cordova.file.documentsDirectory;
      } else if (ionic.Platform.isAndroid()) {
        path = cordova.file.externalRootDirectory + 'eValveMobile/';
      }

      return path;
    }

    /**
     * Enregistre récursivement toutes les vannes du tableau en paramètre
     * @param {string[][]} data Tableau des vannes à enregistrer
     * @param {string[][]} errors Erreurs rencontrées lors de l'enregistrement
     * @returns {Promise} Promise de l'enregistrement de toutes les vannes
     */
    private bulkValveSave(data: string[][], errors?: string[][]) {
      let line = data.shift();
      if (!line) {
        if (errors) {
          /* Si il y a eu des erreurs pour certaines vannes, on les remonte */
          throw errors;
        }

        return;
      }

      if (!line[0].length) {
        /* Si le numéro de série est vide (ligne vide ?) */
        return this.bulkValveSave(data, errors);
      }

      return this
        .addOfflineValve(line[0], 0, line[1])
        .catch(error => {
          /* Si erreur, on ajoute la ligne concernée à la liste d'erreurs */
          errors ? errors.push(line) : errors = [line];
        })
        .then(() => this.bulkValveSave(data, errors));
    }

    /**
     * ref: http://stackoverflow.com/a/1293163/2343
     * This will parse a delimited string into an array of
     * arrays. The default delimiter is the comma, but this
     * can be overriden in the second argument.
     * @param {string} strData Contenu du CSV sous forme de string
     * @param {string} strDelimiter Délimitations des champs du CSV
     * @returns {string[][]} Tableau correspondant au CSV parsé
     */
    private CSVToArray(strData, strDelimiter): string[][] {
      // Check to see if the delimiter is defined. If not,
      // then default to comma.
      strDelimiter = (strDelimiter || ',');

      // Create a regular expression to parse the CSV values.
      let objPattern = new RegExp(
        (
          // Delimiters.
          '(\\' + strDelimiter + '|\\r?\\n|\\r|^)' +

          // Quoted fields.
          '(?:\"([^\"]*(?:\"\"[^\"]*)*)\"|' +

          // Standard fields.
          '([^\"\\' + strDelimiter + '\\r\\n]*))'
        ),
        'gi'
      );

      // Create an array to hold our data. Give the array
      // a default empty first row.
      let arrData = [[]];

      // Create an array to hold our individual pattern
      // matching groups.
      let arrMatches = null;

      // Keep looping over the regular expression matches
      // until we can no longer find a match.
      while (arrMatches = objPattern.exec(strData)) {

        // Get the delimiter that was found.
        let strMatchedDelimiter = arrMatches[1];

        // Check to see if the given delimiter has a length
        // (is not the start of string) and if it matches
        // field delimiter. If id does not, then we know
        // that this delimiter is a row delimiter.
        if (
          strMatchedDelimiter.length &&
          strMatchedDelimiter !== strDelimiter
        ) {
          // Since we have reached a new row of data,
          // add an empty row to our data array.
          arrData.push([]);
        }

        let strMatchedValue;

        // Now that we have our delimiter out of the way,
        // let's check to see which kind of value we
        // captured (quoted or unquoted).
        if (arrMatches[2]) {

          // We found a quoted value. When we capture
          // this value, unescape any double quotes.
          strMatchedValue = arrMatches[2].replace(
            new RegExp('\"\"', 'g'),
            '"'
          );

        } else {
          // We found a non-quoted value.
          strMatchedValue = arrMatches[3];
        }

        // Now that we have our value string, let's add
        // it to the data array.
        arrData[arrData.length - 1].push(strMatchedValue);
      }

      // Return the parsed data.
      return (arrData);
    }
  }

  angular
    .module('eValve.park')
    .service('park', ParkService);
}
