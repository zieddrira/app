namespace eValve.park {
  'use strict';

  export class UserValvesController {
    private _originalFullValves: { serialNumber: string; selected: boolean }[];

    fullValves: { serialNumber: string; selected: boolean }[];
    user: IUser;

    static $inject: Array<string> = ['park', '$stateParams', '$ionicPopup', '$ionicNavBarDelegate', 'vanne', '$ionicHistory'];
    constructor(
      private park: IParkService,
      private $stateParams: ng.ui.IStateParamsService,
      private $ionicPopup: ionic.popup.IonicPopupService,
      private $ionicNavBarDelegate: ionic.navigation.IonicNavBarDelegate,
      private vanne: eValve.vanne.IVanne,
      private $ionicHistory: ionic.navigation.IonicHistoryService
    ) {
      this.initVm();
    }

    initVm() {
      this.park
        .getUserDetails(this.$stateParams['username'])
        .then((user: IUser) => {
          this.user = user;

          /* On met à jour le titre de la page dynamiquement */
          this.$ionicNavBarDelegate.title(`${this.user.username} : vannes`);
        })

        .then(() => this.park.getAllValves())
        .then((allValves: string[]) => {
          let notAddedValves = allValves
            .filter(valve => !this.user.valves.has(valve))
            .map(valve => ({ serialNumber: valve, selected: false }));

          let parsedUserValves = Array
            .from(this.user.valves)
            .map(valve => ({ serialNumber: valve[0], selected: true }));

          this.fullValves = parsedUserValves.concat(notAddedValves);
          this._originalFullValves = angular.copy(this.fullValves);
        })

        .catch(error => {
          this.$ionicPopup.alert({
            title: 'Une erreur est survenue',
            template: JSON.stringify(error),
            okType: 'button-assertive'
          });
        });
    }

    /**
     * Met à jour la liste des vannes de l'utilisateur
     */
    updateValves() {
      this.fullValves.forEach((valve, index) => {
        if (this._originalFullValves[index].selected != valve.selected) {
          if (!valve.selected) {
            /* Si la vanne n'est plus sélectionnée, on la supprime de l'utilisateur */
            this.user.valves.delete(valve.serialNumber);
            delete this.user.connectionCodes[valve.serialNumber];

            if (this.vanne.connectedValveSerial == valve.serialNumber) {
              /* Si suppression des droits sur la vanne actuellement connectée, on déconnecte */
              this.vanne.disconnect();
            }

            if (this.vanne.selectedValveSerial == valve.serialNumber) {
              /* Si suppression des droits sur la vanne actuellement sélectionnée, on réinitialise */
              this.vanne.selectedValveSerial = null;
            }

          } else if (valve.selected) {
            /* Si la vanne a été sélectionnée, on l'ajoute à l'utilisateur */
            this.user.valves.set(valve.serialNumber, null);
          }
        }
      });

      this.park
        .updateUser(this.user)
        .then(result => {
          this.$ionicPopup
            .alert({
            title: 'Mise à jour réussie',
            template: `L'utilisateur a bien été mis à jour`
            })
            .then(() => this.$ionicHistory.goBack());
        })

        .catch(error => {
          this.$ionicPopup
            .alert({
              title: `Erreur lors de la mise à jour`,
              template: JSON.stringify(error),
              okType: 'button-assertive'
            })
            .then(() => this.initVm());
        });
    }
  }

  angular
    .module('eValve.park')
    .controller('UserValvesController', UserValvesController);
}
