namespace eValve.park {
  'use strict';

  export class UsersListController {
    users: { username: string, isAdmin: boolean }[];

    static $inject: Array<string> = ['park', '$ionicPopup', '$ionicListDelegate', '$scope', '$q'];
    constructor(
      private park: IParkService,
      private $ionicPopup: ionic.popup.IonicPopupService,
      private $ionicListDelegate: ionic.list.IonicListDelegate,
      private $scope: ng.IScope,
      private $q: ng.IQService
    ) {
      this.getUserNames();
      this.$scope.$on('$ionicView.leave', () => this.$ionicListDelegate.closeOptionButtons());
      // this.usernames = ['tutu'];
    }

    /**
     * Récupère la liste des noms d'utilisateurs
     */
    getUserNames() {
      this.park
        .getUsers()
        .then(list => this.users = list)
        .catch(error => {
          this.$ionicPopup.alert({
            title: 'Erreur lors de la récupération des utilisateurs',
            template: JSON.stringify(error),
            okType: 'button-assertive'
          });
        });
    }

    /**
     * Demande confirmation de la suppression et met à jour la liste
     * @param {Object} user Utilisateur à supprimer
     */
    deleteUser(user: { username: string, isAdmin: boolean }) {
      let adminPromise = this.$q.resolve(true);

      if (user.isAdmin) {
        /* Si admin, on vérifie qu'il en restera d'autres */
        adminPromise = this.park.checkIfMultipleAdmins();
      }

      adminPromise
        .then((result: boolean) => {
          if (!result) {
            /* Si il n'y a pas d'autres admins */
            throw 'ONLY_ONE_ADMIN';
          }

          return this.$ionicPopup.confirm({
            title: `Suppression d'un utilisateur`,
            template: `Souhaitez-vous vraiment supprimer l'utilisateur ${user.username} ?`,
            okText: 'Supprimer',
            okType: 'button-assertive',
            cancelText: 'Annuler'
          });
        })

        .then(confirmation => {
          if (confirmation) {
            /* Si confirmé, suppression de l'utilisateur en base */
            return this.park.deleteUser(user.username);
          }
        })
        .then(result => {
          if (result) {
            /* Si suppression OK, mise à jour de la liste des utilisateurs */
            this.users.splice(this.users.indexOf(user), 1);
          }
        })

        .catch(error => {
          let title = 'Erreur lors de la suppression';
          let template = JSON.stringify(error);

          if (error == 'ONLY_ONE_ADMIN') {
            title = 'Unique administrateur !';
            template = `Il s'agit du seul administrateur de l'application, vous ne pouvez pas le supprimer.`;
          } else if (error == 'CONNECTED_USER') {
            title = 'Suppression impossible';
            template = `Vous ne pouvez pas vous supprimer vous-même !`;
          }

          this.$ionicPopup.alert({
            title,
            template,
            okType: 'button-assertive'
          });
        })

        .finally(() => this.$ionicListDelegate.closeOptionButtons());
    }
  }

  angular
    .module('eValve.park')
    .controller('UsersListController', UsersListController);
}
