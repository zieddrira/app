namespace eValve.park {
  'use strict';

  export class AddValveController {
    bulkModel: any;
    bulkFields: any;
    valveModel: any;
    valveFields: any;

    static $inject: Array<string> = ['park', '$scope', '$ionicPopup', '$ionicLoading'];
    constructor(
      private park: IParkService,
      private $scope: ng.IScope,
      private $ionicPopup: ionic.popup.IonicPopupService,
      private $ionicLoading: ionic.loading.IonicLoadingService
    ) {
      this.$scope.$on('$ionicView.beforeEnter', () => {
        this.setValveForm();
        this.setBulkForm();
      });
    }

    /**
     * Ajoute la vanne à l'utilisateur courant
     */
    addValve() {
      let { serialNumber, connectionCode } = this.valveModel;
      this
        .park
        .addOfflineValve(serialNumber, 0, connectionCode)
        .then(() => {
          this.$ionicPopup
            .alert({
              title: 'Vanne ajoutée',
              template: `La vanne a bien été ajoutée au compte`
            })
            .then(() => this.setValveForm());
        })
        .catch(error => {
          if (error == 'BAD_CONNECTION_CODE') {
            return this.$ionicPopup.alert({
              title: 'Mauvais code de connexion',
              template: 'Le code de connexion que vous avez saisi ne correspond pas à celui enregistré pour la vanne',
              okType: 'button-assertive'
            });
          }

          return this.$ionicPopup.alert({
            title: 'Erreur',
            template: JSON.stringify(error),
            okType: 'button-assertive'
          });
        });
    }

    /**
     * Import de vannes depuis un fichier
     */
    bulkImport() {
      this.$ionicLoading.show({ template: 'Importation en cours...' });

      return this.park.bulkValveImport(this.bulkModel['filename'] || 'import.csv')
        .then(result => {
          this.$ionicLoading.hide();
          return this.$ionicPopup.alert({
            title: 'Import réussi',
            template: 'Les vannes ont bien été importées'
          });
        })
        .catch(error => {
          let title, template;
          this.$ionicLoading.hide();

          if (error.code && error.code == 1) {
            /* Fichier non trouvé */
            title = 'Fichier non trouvé';
            template = 'Impossible de trouver le fichier correspondant, vérifiez le nom du fichier.';

          } else if (error.length) {
            /* Cas d'un tableau d'erreurs : certaines vannes n'ont pas pu être ajoutées */
            let serialNumbers = (<string[][]>error)
              .map(line => line[0])
              .reduce((prev, curr) => `${prev}, ${curr}`);

            title = `Des erreurs sont survenues`;
            template = `Les vannes suivantes n'ont pas pu être importées : ${serialNumbers}. Vérifiez les codes de connexion.`;

          } else {
            title = 'Erreur';
            template = JSON.stringify(error);
          }

          return this.$ionicPopup.alert({
            title,
            template,
            okType: 'button-assertive'
          });
        });
    }

    /**
     * Initialise le formulaire d'ajout individuel
     */
    setValveForm() {
      this.valveModel = {};
      this.valveFields = [
        {
          key: 'serialNumber',
          type: 'floating-input',
          templateOptions: {
            type: 'text',
            label: 'Numéro de série',
            placeholder: 'Numéro de série',
            required: true,
            maxlength: 9,
            minlength: 9
          },
          validation: {
            messages: {
              maxlength: () => 'La longueur du code de connexion doit être de 9 caractères',
              minlength: () => 'La longueur du code de connexion doit être de 9 caractères'
            }
          }
        },
        {
          key: 'connectionCode',
          type: 'floating-input',
          templateOptions: {
            type: 'text',
            label: 'Code de connexion',
            placeholder: 'Code de connexion',
            required: true,
            maxlength: 10,
            minlength: 10
          },
          validation: {
            messages: {
              maxlength: () => 'La longueur du code de connexion doit être de 10 caractères',
              minlength: () => 'La longueur du code de connexion doit être de 10 caractères'
            }
          }
        }
      ];
    }

    /**
     * Initialise le formulaire d'ajout en masse
     */
    setBulkForm() {
      this.bulkModel = {};
      this.bulkFields = [
        {
          key: 'filename',
          type: 'floating-input',
          templateOptions: {
            type: 'text',
            label: 'Nom du fichier (.csv)',
            placeholder: 'import.csv (par défaut)',
            pattern: '^(.*\.csv)$'
          },
          validation: {
            messages: {
              pattern: () => 'Le fichier doit être en .csv'
            }
          }
        }
      ];
    }
  }

  angular
    .module('eValve.park')
    .controller('AddValveController', AddValveController);
}
