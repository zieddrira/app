namespace eValve.scanner {
  'use strict';

  angular
    .module('eValve.scanner', [])
    .run(initModule);

  initModule.$inject = ['routerHelper'];
  function initModule(routerHelper) {
    routerHelper.configureStates(getStates());
  }

  function getStates() {
    return [
      {
        /* Scan */
        state: 'scanner',
        config: {
          url: '/scanner',
          views: {
            '': {
              templateUrl: 'app/scanner/scanner.html',
              controller: 'ScanController as scan'
            }
          }
        }
      }
    ];
  }

}
