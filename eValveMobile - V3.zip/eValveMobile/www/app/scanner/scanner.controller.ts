namespace eValve.scanner {
  'use strict';

  export class ScanController {
    appTime: Date;
    peripherals: Array<any>;
    scanning: boolean;
    vanneTime: number;

    static $inject: Array<string> = ['$scope', 'bluetooth', '$ionicPopup', '$state', '$log', '$ionicPlatform',
      'vanne', 'protocol', '$q', '$timeout', '$ionicLoading', '$cordovaDatePicker', 'ERROR_CODES', 'utils', 'db'];
    constructor(
      private $scope: ng.IScope,
      private bluetooth: eValve.communication.IBluetooth,
      private $ionicPopup: ionic.popup.IonicPopupService,
      private $state: ng.ui.IStateService,
      private $log: ng.ILogService,
      private $ionicPlatform: ionic.platform.IonicPlatformService,
      private vanne: eValve.vanne.IVanne,
      private protocol: eValve.communication.IProtocol,
      private $q: ng.IQService,
      private $timeout: ng.ITimeoutService,
      private $ionicLoading: ionic.loading.IonicLoadingService,
      private $cordovaDatePicker: ngCordova.IDatePickerService,
      private ERROR_CODES: eValve.communication.IErrors,
      private utils: eValve.core.IUtils,
      private db: eValve.core.IDb
    ) {
      $scope.$on('$ionicView.beforeEnter', () => {
        this.peripherals = [];
        this.scanning = true;
      });

      $scope.$on('$ionicView.enter', () => this.startScan());

      /* Events listeners */
      $scope.$on('$destroy', this.onDestroy);
    }

    /**
     * Lance le scan bluetooth pour détecter les vannes
     * @param {Object[]} [services] - Liste des services à découvrir
     * @param {Number} [seconds] - Durée du scan en secondes
     */
    startScan(services?: Array<any>, seconds?: number) {
      this.peripherals = [];

      this.bluetooth.isEnabled()
        .catch(() => { throw { bluetooth: true }; })
        .then(() =>
          /* Si la localisation n'est pas activée sur Android : message d'erreur */
          this.isLocationEnabled()
            .catch(() => { throw { localisation: true }; })
        )
        .then(() => {
          /* Si bluetooth activé, on lance le scan */
          this.scanning = true;
          return this.$timeout(() => {
            /* Le scan démarre au bout de 5 secondes */
            return this.bluetooth.startScan(services, seconds);
          }, 5000);
        })

        .then(() => {
          this.scanning = false;
        }, null, (device) => {
          this.$log.debug('Peripheral found: ' + JSON.stringify(device));
          if (device.rssi == 127) { return; }

          this.db.getSerialNumberFromMacAddress(device.id)
            .then((serialNumber) => {
              if (serialNumber) {
                device.name = 'ValveSL' + serialNumber;
              } else {
                device.name = device.name || 'Inconnu';
              }

              let indexFound;
              let alreadyScanned = this.peripherals.some((value, index) => {
                /* On vérifie qu'un périphérique avec le même nom n'existe pas déjà */
                if (value.name != 'Inconnu' && value.name == device.name) {
                  indexFound = index;
                  return true;
                }
              });

              alreadyScanned && this.peripherals.splice(indexFound, 1);

              this.peripherals.push(device);
              this.peripherals.sort((a, b) => {
                return b.rssi - a.rssi;
              });
            });
        })

        .catch(error => {
          this.scanning = false;

          if (error.bluetooth) {
            this.$ionicPopup.alert({
              title: 'Bluetooth désactivé',
              template: 'Veuillez activer le bluetooth dans les réglages de votre appareil'
            });
          } else if (error.localisation) {
            this.$ionicPopup.alert({
              title: 'Localisation désactivée',
              template: 'Veuillez activer les données GPS dans les réglages de votre appareil (requis pour Android 6.0 ou +).'
            });
          } else {
            this.$ionicPopup.alert({
              title: 'Erreur lors du scan',
              template: error,
              okType: 'button-assertive'
            });
          }

        });
    }

    /**
     * Arrête le scan de vannes
     */
    stopScan() {
      this.bluetooth
        .stopScan()
        .then(() => {
          this.scanning = false;
        })
        .catch(error => {
          this.$ionicPopup.alert({
            title: 'Erreur lors de l\'arrêt',
            template: error,
            okType: 'button-assertive'
          });
        });
    }

    /**
     * Vérifie si la localisation GPS est activée et affiche une popup si désactivé
     * @returns {Promise}
     */
    isLocationEnabled(): ng.IPromise<any> {
      let deferred = this.$q.defer();

      this.$ionicPlatform
        .ready()
        .then(() => {
          let deviceVersion: number = parseInt(device.version.charAt(0));
          this.$log.debug('Device version first digit : ' + deviceVersion);

          if (ionic.Platform.isAndroid() && deviceVersion >= 6) {
            cordova.plugins.diagnostic.isLocationEnabled(
              (enabled: boolean) => {
                this.$log.debug('Localisation : ' + enabled);
                if (enabled == true) {
                  deferred.resolve();
                }
                deferred.reject();
              },
              (error) => {
                this.$log.debug('The following error occurred : ' + error);
                deferred.reject(error);
              }
            );
          } else {
            deferred.resolve();
          }
        });

      return deferred.promise;
    }

    /**
     * Lance la connexion au périphérique passé en paramètre
     * @param {String} deviceId - Adresse mac ou UUID de la vanne
     * @param {String} [connectionCode] Code de connexion à la vanne
     */
    connect(deviceId: string, connectionCode?: string) {
      let valveSerial: string;

      this.vanne
        .connect(deviceId, connectionCode)
        .then(result => {
          this.$log.debug('Connected: ' + result);
          valveSerial = result.name.substr(7);
          if (result.vanneTimestamp) {
            /* Affichage d'une popup en cas d'écart avec le timestamp de la vanne */
            this.$ionicLoading.hide();
            let baseTime = this.appTime = new Date();
            this.vanneTime = result.vanneTimestamp;

            let clockPopup = this.$ionicPopup.show({
              title: 'Décalage d\'horloge',
              templateUrl: 'app/scanner/clock.popup.html',
              scope: this.$scope,
              buttons: [
                {
                  text: 'Ne rien faire',
                  onTap: (e) => false
                },
                {
                  text: 'Modifier',
                  type: 'button-positive',
                  onTap: (e) => {
                    let dateToSend = new Date();
                    if (this.appTime != baseTime) {
                      dateToSend = this.appTime;
                    }

                    return this.vanne
                      .setTime(this.utils.timestampToSeconds(dateToSend.getTime()))
                      .then(() => {
                        this.appTime = dateToSend;
                        this.vanneTime = dateToSend.getTime();
                      });
                  }
                }
              ]
            });

            return clockPopup.then(response => {
              if (response != false) {
                return this.$ionicPopup.show({
                  title: 'Validation',
                  templateUrl: 'app/scanner/clock.popup.html',
                  scope: this.$scope,
                  buttons: [
                    {
                      text: 'OK',
                      type: 'button-positive'
                    }
                  ]
                });
              }
            });
          }
        })

        .then(result => {
          this.$log.debug(result);
          if (valveSerial == '000000000') {
            this.$ionicPopup
              .alert({
                title: 'Première connexion à la vanne',
                template: `Avant d'aller plus loin, vous devez spécifier le numéro de série et le code de connexion pour cette vanne`
              })
              .then(() => this.$state.go('initVanne'));

          } else {
            this.$state.go('vanne.details', { valveSerial: valveSerial });
          }
        })

        .catch(error => {
          this.$ionicLoading.hide();
          this.$log.error(error);

          if (error == ('NOT_REGISTERED' || 'CODE_NOT_FOUND')) {
            /* Si il n'y a pas de code d'activation disponible, on en demande un */
            return this.$ionicPopup
              .prompt({
                title: 'Code de connexion requis',
                template: 'Veuillez saisir le code de connexion à la vanne',
                inputPlaceholder: 'Code de connexion',
                cancelText: 'Annuler',
                okText: 'Valider'
              })
              .then((code: string) => {
                if (typeof code != 'undefined') {
                  code = code || '0000000000';
                  return this.connect(deviceId, code);
                } else {
                  return this.vanne.disconnect(true);
                }
              });
          } else if (error == this.ERROR_CODES['receive']['auth']) {
            /* La connexion à la vanne a été rejetée, probablement par timeout de la réponse */
            return this.$ionicPopup
              .prompt({
                title: 'Erreur de connexion',
                template: `La vanne semble refuser la connexion. Vous pouvez réessayer avec les paramètres en mémoire
                  ou saisir à nouveau le code de connexion`,
                inputPlaceholder: 'Code de connexion (facultatif)',
                cancelText: 'Arrêter',
                okText: 'Réessayer'
              })
              .then((code: string) => {
                if (code == undefined) {
                  return this.vanne.disconnect(true);
                }

                // if (typeof code != 'undefined') {
                connectionCode = code;
                // }

                return this.connect(deviceId, connectionCode);
              });
          }

          this.vanne.disconnect(true);

          this.$ionicPopup.alert({
            title: 'Erreur lors de la connexion',
            okType: 'button-assertive',
            template: this.utils.getVerboseErrorMessage(error)
          });
        });
    }

    /**
     * Appelée lors de la destruction du controller
     */
    onDestroy() {
      if (this.scanning) {
        this.stopScan();
      }
    }

    /**
     * Affiche un timepicker natif pour paramétrer l'horloge
     * @param {Date} date Date de départ
     */
    showTimePicker(date: Date) {
      let timeOptions = {
        date: date,
        // maxDate: new Date(),
        // allowFutureDates: false, //iOS only
        mode: 'time',
        locale: 'fr_fr'
      };

      this.$cordovaDatePicker
        .show(timeOptions)
        .then((settedDate: Date) => this.onTimeSelect(settedDate));
    }

    /**
     * Appelée lors de la sélection d'une date via le timepicker, récupère les données correspondantes
     * @param {Date} date - Date sélectionnée
     */
    onTimeSelect(date: Date) {
      if (!date) {
        return;
      }

      this.appTime = date;
    }

  }

  angular
    .module('eValve.scanner')
    .controller('ScanController', ScanController);
}
